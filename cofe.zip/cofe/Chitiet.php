<?php
require_once "caphe.php";
$cf = new caphe;

// Đọc mã sản phẩm từ URL: chitiet.php?id=3
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$sp = $cf->ChiTietSanPham($id);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Coffee House - <?= $sp ? htmlspecialchars($sp['ten_san_pham']) : "Không tìm thấy sản phẩm" ?></title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- HEADER (giống các trang khác) -->
  <header>
    <div class="container">
      <div class="header-left">
        <div class="logo">☕ Coffee House</div>
        <nav>
          <ul>
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="danhmuc.php">Danh mục</a></li>
            <li><a href="products.php">Sản phẩm</a></li>
            <li><a href="theodoi_donhang.php">Theo dõi đơn</a></li>
            <li><a href="index.php#about">Giới thiệu</a></li>
            <li><a href="index.php#footer">Liên hệ</a></li>
          </ul>
        </nav>
      </div>

      <div class="header-right">
        <a href="giohang.php">🛒 Giỏ hàng (<?= $cf->TongSoLuongGioHang() ?>)</a>
        <?php if (isset($_SESSION['user'])) { ?>
          <a href="taikhoan.php">👤 <?= htmlspecialchars($_SESSION['user']['ho_ten']) ?></a>
          <a href="dangxuat.php">Đăng xuất</a>
        <?php } else { ?>
          <a href="dangnhap.php">Đăng nhập</a>
          <a href="dangky.php">Đăng ký</a>
        <?php } ?>
      </div>
    </div>
  </header>

  <?php if (!$sp) { ?>

  <!-- TRƯỜNG HỢP MÃ SẢN PHẨM KHÔNG TỒN TẠI -->
  <div class="page-title">
    <h1>Không tìm thấy sản phẩm</h1>
    <p><a href="products.php">← Quay lại danh sách sản phẩm</a></p>
  </div>

  <?php } else { ?>

  <!-- ĐƯỜNG DẪN BREADCRUMB -->
  <div class="breadcrumb">
    <a href="index.php">Trang chủ</a> &nbsp;/&nbsp;
    <a href="products.php">Sản phẩm</a> &nbsp;/&nbsp;
    <?= htmlspecialchars($sp['ten_san_pham']) ?>
  </div>

  <!-- KHỐI CHI TIẾT: ảnh lớn bên trái, thông tin bên phải -->
  <div class="detail-wrapper">
    <div class="detail-img">
      <img src="<?= $sp['hinh_anh'] ?>" alt="<?= htmlspecialchars($sp['ten_san_pham']) ?>">
    </div>
    <div class="detail-info">
      <h1><?= htmlspecialchars($sp['ten_san_pham']) ?></h1>

      <?php if ($sp['ten_danh_muc']) { ?>
      <span class="detail-category">Danh mục: <?= htmlspecialchars($sp['ten_danh_muc']) ?></span>
      <?php } ?>

      <span class="price"><?= $cf->DinhDangGia($sp['gia']) ?></span>

      <p class="detail-mota">
        <?= $sp['mo_ta'] ? nl2br(htmlspecialchars($sp['mo_ta'])) : "Đang cập nhật mô tả cho sản phẩm này." ?>
      </p>

      <!-- MỚI THÊM: Bọc form gửi dữ liệu sang xuly_giohang.php và kích hoạt nút +/- -->
      <form method="post" action="xuly_giohang.php?action=add" class="detail-action">
        <input type="hidden" name="id" value="<?= $sp['id_san_pham'] ?>">
        <div class="detail-qty">
          <button type="button" onclick="var q=document.getElementById('qty'); if(q.value>1) q.value--;">-</button>
          <input type="text" name="soluong" id="qty" value="1" readonly>
          <button type="button" onclick="var q=document.getElementById('qty'); q.value++;">+</button>
        </div>
        <button type="submit" class="btn">Thêm vào giỏ hàng</button>
      </form>
     
    </div>
  </div>

  <!-- SẢN PHẨM LIÊN QUAN: cùng danh mục, trừ sản phẩm đang xem -->
  <?php
  $lienquan = $cf->SanPhamLienQuan($sp['id_danh_muc'], $sp['id_san_pham'], 3);
  if ($lienquan->num_rows > 0) {
  ?>
  <section class="related-section">
    <h2>Sản phẩm liên quan</h2>
    <div class="related-list">
      <?php while ($row = $lienquan->fetch_assoc()) { ?>
      <div class="product-card">
        <a href="chitiet.php?id=<?= $row['id_san_pham'] ?>" style="text-decoration:none; color:inherit;">
          <img src="<?= $row['hinh_anh'] ?>" alt="<?= htmlspecialchars($row['ten_san_pham']) ?>" width="150" height="150">
          <h3><?= htmlspecialchars($row['ten_san_pham']) ?></h3>
        </a>
        <p class="price"><?= $cf->DinhDangGia($row['gia']) ?></p>
      </div>
      <?php } ?>
    </div>
  </section>
  <?php } ?>

  <?php } ?>

  <!-- FOOTER (giống các trang khác) -->
  <footer id="footer">
    <div class="footer-container">
      <div class="footer-col">
        <h3>☕ Coffee House</h3>
        <p>Thương hiệu cà phê chất lượng, mang tới hương vị đậm đà nguyên bản từ những hạt cà phê hảo hạng.</p>
      </div>
      <div class="footer-col">
        <h3>Thông Tin Liên Hệ</h3>
        <p>📍 Địa chỉ: 123 Đường Nguyễn Trãi, Quận 1, TP.HCM</p>
        <p>📞 Điện thoại: 0909 123 456</p>
        <p>✉️ Email: contact@coffeehouse.vn</p>
        <p>⏰ Giờ mở cửa: 07:00 - 22:30 hàng ngày</p>
      </div>
      <div class="footer-col">
        <h3>Liên Kết Nhanh</h3>
        <ul>
          <li><a href="index.php">Trang chủ</a></li>
          <li><a href="danhmuc.php">Danh mục</a></li>
          <li><a href="products.php">Sản phẩm</a></li>
        </ul>
      </div>
    </div>
    <div class="copyright">
      <p>&copy; Coffee House. Tất cả quyền được bảo lưu.</p>
    </div>
  </footer>

</body>
</html>