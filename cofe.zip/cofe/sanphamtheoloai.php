<?php
require_once "caphe.php";
$cf = new caphe;

// Đọc mã danh mục từ URL: sanphamtheoloai.php?dm=2
$dm = isset($_GET['dm']) ? (int)$_GET['dm'] : 0;

// Lấy thông tin danh mục để hiện tên và kiểm tra danh mục có tồn tại không
$danhmuc = $cf->ChiTietDanhMuc($dm);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Coffee House - <?= $danhmuc ? htmlspecialchars($danhmuc['ten_danh_muc']) : "Sản phẩm theo loại" ?></title>
  <link rel="stylesheet" href="style.css?v=4">
</head>
<body class="account-page">

  <!-- HEADER -->
 <header>
    <div class="container">
      <div class="header-left">
        <div class="logo">☕ Coffee House</div>
        <nav>
          <ul>
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="danhmuc.php">Danh mục</a></li>
            <li><a href="products.php">Sản phẩm</a></li>
            <li><a href="theodoi_donhang.php">Theo dõi đơn</a></li>
            <li><a href="index.php#about">Giới thiệu</a></li>
            <li><a href="index.php#footer">Liên hệ</a></li>
          </ul>
        </nav>
      </div>

      <div class="header-right">
        <a href="giohang.php">🛒 Giỏ hàng (<?= $cf->TongSoLuongGioHang() ?>)</a>
        <?php if (isset($_SESSION['user'])) { ?>
          <a href="taikhoan.php">👤 <?= htmlspecialchars($_SESSION['user']['ho_ten']) ?></a>
          <a href="dangxuat.php">Đăng xuất</a>
        <?php } else { ?>
          <a href="dangnhap.php">Đăng nhập</a>
          <a href="dangky.php">Đăng ký</a>
        <?php } ?>
      </div>
    </div>
  </header>
  <?php if (!$danhmuc) { ?>

  <!-- TRƯỜNG HỢP MÃ DANH MỤC KHÔNG TỒN TẠI -->
  <div class="page-title">
    <h1>Không tìm thấy danh mục</h1>
    <p><a href="danhmuc.php">← Quay lại trang danh mục</a></p>
  </div>

  <?php } else { ?>

  <!-- TIÊU ĐỀ: tên danh mục đang xem -->
  <div class="page-title">
    <h1>Sản phẩm: <?= htmlspecialchars($danhmuc['ten_danh_muc']) ?></h1>
  </div>

  <!-- THANH DANH MỤC:-->
  <div class="category-list">
    <?php
    $kqdm = $cf->ListDanhMuc();
    while ($row = $kqdm->fetch_assoc()) {
    ?>
    <a href="sanphamtheoloai.php?dm=<?= $row['id_danh_muc'] ?>"
       class="<?= $dm == $row['id_danh_muc'] ? 'active' : '' ?>">
      <?= htmlspecialchars($row['ten_danh_muc']) ?>
    </a>
    <?php } ?>
  </div>

  <!-- DANH SÁCH SẢN PHẨM THUỘC DANH MỤC (bảng san_pham, lọc theo id_danh_muc) -->
  <section class="product-listing">
    <div class="container">
      <div class="product-list">

        <?php
        $kq = $cf->SanPhamTheoLoai($dm);
        if ($kq->num_rows == 0) {
            echo "<p>Danh mục này chưa có sản phẩm.</p>";
        }
        while ($row = $kq->fetch_assoc()) {
        ?>
        <div class="product-card">
          <!-- MỚI THÊM: Đóng thẻ </a> sau tiêu đề và gắn link thêm giỏ hàng cho nút Mua ngay -->
          <a href="chitiet.php?id=<?= $row['id_san_pham'] ?>" style="text-decoration:none; color:inherit;">
            <img src="<?= $row['hinh_anh'] ?>" alt="<?= htmlspecialchars($row['ten_san_pham']) ?>" width="100" height="100">
            <h3><?= htmlspecialchars($row['ten_san_pham']) ?></h3>
          </a>
          <p class="price"><?= $cf->DinhDangGia($row['gia']) ?></p>
          <a href="xuly_giohang.php?action=add&id=<?= $row['id_san_pham'] ?>" class="btn" style="display:inline-block;">Mua ngay</a>
          <!-- HẾT PHẦN MỚI THÊM -->
        </div>
        <?php } ?>

      </div>
    </div>
  </section>

  <?php } ?>

  <!-- FOOTER -->
  <footer id="footer">
    <div class="footer-container">
      <div class="footer-col">
        <h3>☕ Coffee House</h3>
        <p>Thương hiệu cà phê chất lượng, mang tới hương vị đậm đà nguyên bản từ những hạt cà phê hảo hạng.</p>
      </div>
      <div class="footer-col">
        <h3>Thông Tin Liên Hệ</h3>
        <p>📍 Địa chỉ: 123 Đường Nguyễn Trãi, Quận 1, TP.HCM</p>
        <p>📞 Điện thoại: 0909 123 456</p>
        <p>✉️ Email: contact@coffeehouse.vn</p>
        <p>⏰ Giờ mở cửa: 07:00 - 22:30 hàng ngày</p>
      </div>
      <div class="footer-col">
        <h3>Liên Kết Nhanh</h3>
        <ul>
          <li><a href="index.php">Trang chủ</a></li>
          <li><a href="danhmuc.php">Danh mục</a></li>
          <li><a href="products.php">Sản phẩm</a></li>
        </ul>
      </div>
    </div>
    <div class="copyright">
      <p>&copy; Coffee House. Tất cả quyền được bảo lưu.</p>
    </div>
  </footer>

</body>
</html>
