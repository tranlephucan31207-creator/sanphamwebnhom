<?php
require_once "caphe.php";
$cf = new caphe;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Coffee House - Trang chủ</title>
  <link rel="stylesheet" href="style.css?v=7">
</head>
<body>

  <!-- HEADER -->
  
  <header>
    <div class="container">
      <div class="header-left">
        <div class="logo">☕ Coffee House</div>
        <nav>
          <ul>
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="danhmuc.php">Danh mục</a></li>
            <li><a href="products.php">Sản phẩm</a></li>
            <li><a href="theodoi_donhang.php">Theo dõi đơn</a></li>
            <li><a href="#about">Giới thiệu</a></li>
            <li><a href="#footer">Liên hệ</a></li>
          </ul>
        </nav>
      </div>

      <div class="header-right">
        <a href="giohang.php">🛒 Giỏ hàng (<?= $cf->TongSoLuongGioHang() ?>)</a>
        <?php if (isset($_SESSION['user'])) { ?>
          <a href="taikhoan.php">👤 <?= htmlspecialchars($_SESSION['user']['ho_ten']) ?></a>
          <a href="dangxuat.php">Đăng xuất</a>
        <?php } else { ?>
          <a href="dangnhap.php">Đăng nhập</a>
          <a href="dangky.php">Đăng ký</a>
        <?php } ?>
      </div>
    </div>
  </header>

  <!-- PHẦN GIỚI THIỆU (BANNER) -->
  <section class="banner">
    <div class="container">
      <div class="banner-img">
        <img src="img/caphe.jpg" alt="Ly cà phê Coffee House" width="400" height="300">
      </div>
      <div class="banner-text">
        <h1>Cà phê cho ngày mới</h1>
        <hr>
        <p class="slogan">
          <b>Coffee House mang đến những ly cà phê thơm ngon, đậm vị,
          được pha chế từ hạt cà phê nguyên chất, giúp bạn bắt đầu
          một ngày mới tràn đầy năng lượng.</b>
        <hr>
        </p>

        <a href="products.php" class="btn">Xem sản phẩm</a>
      </div>
    </div>
  </section>

  <!-- SẢN PHẨM NỔI BẬT (dữ liệu lấy từ bảng san_pham, noi_bat = 1) -->
  <section class="featured">
    <div class="container">
      <h2>Sản phẩm nổi bật</h2>
      <div class="product-list">

        <?php
        $kq = $cf->SanPhamNoiBat(0); // Hiển thị tất cả sản phẩm nổi bật (noi_bat = 1)
        if (!$kq || $kq->num_rows == 0) {
            echo "<p>Chưa có sản phẩm nổi bật nào.</p>";
        }
        while ($kq && ($row = $kq->fetch_assoc())) {
        ?>
           <!-- MỚI THÊM: bọc card trong <a> để bấm vào xem chi tiết -->
        <a href="chitiet.php?id=<?= $row['id_san_pham'] ?>" style="text-decoration:none; color:inherit;">
          <div class="product-card">
            <img src="<?= htmlspecialchars($row['hinh_anh']) ?>" alt="<?= htmlspecialchars($row['ten_san_pham']) ?>">
            <h3><?= htmlspecialchars($row['ten_san_pham']) ?></h3>
            <p class="price"><?= $cf->DinhDangGia($row['gia']) ?></p>
          </div>
        </a>
        <?php } ?>

      </div>
    </div>
  </section>

  <!-- GIỚI THIỆU CỬA HÀNG -->
  <section class="about" id="about">
    <div class="container">
      <h2>Về Coffee House</h2>
      <hr>
      <p>
        Coffee House là quán cà phê nhỏ nằm trong lòng thành phố, nơi mang đến
        không gian ấm cúng và những ly cà phê chất lượng với mức giá hợp lý<br>
        Chúng tôi tin rằng một ly cà phê ngon có thể làm cho ngày mới của bạn
        trở nên trọn vẹn hơn. <br>
        Coffee House hi vọng quý khách sẽ có trải nghiệm thật tuyệt vời khi thưởng thức cà phê tại đây!
      </p>
    </div>
  </section>

  <!-- FOOTER -->
  <footer id="footer">
    <div class="footer-container">
      <div class="footer-col">
        <h3>☕ Coffee House</h3>
        <p>Thương hiệu cà phê chất lượng, mang tới hương vị đậm đà nguyên bản từ những hạt cà phê hảo hạng.</p>
      </div>
      <div class="footer-col">
        <h3>Thông Tin Liên Hệ</h3>
        <p>📍 Địa chỉ: 123 Đường Nguyễn Trãi, Quận 1, TP.HCM</p>
        <p>📞 Điện thoại: 0909 123 456</p>
        <p>✉️ Email: contact@coffeehouse.vn</p>
        <p>⏰ Giờ mở cửa: 07:00 - 22:30 hàng ngày</p>
      </div>
      <div class="footer-col">
        <h3>Liên Kết Nhanh</h3>
        <ul>
          <li><a href="index.php">Trang chủ</a></li>
          <li><a href="danhmuc.php">Danh mục</a></li>
          <li><a href="products.php">Sản phẩm</a></li>
          <li><a href="#about">Giới thiệu</a></li>
        </ul>
      </div>
    </div>
    <div class="copyright">
      <p>&copy; Coffee House. Tất cả quyền được bảo lưu.</p>
    </div>
  </footer>

</body>
</html>