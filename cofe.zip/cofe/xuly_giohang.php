<?php
require_once "caphe.php";
$cf = new caphe;

// Khởi tạo mảng giỏ hàng trong Session nếu chưa có
if (!isset($_SESSION['giohang'])) {
    $_SESSION['giohang'] = [];
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    // 1. THÊM SẢN PHẨM VÀO GIỎ (từ nút "Mua ngay" hoặc trang chi tiết)
    case 'add':
        $id = isset($_POST['id']) ? (int)$_POST['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
        $soluong = isset($_POST['soluong']) ? (int)$_POST['soluong'] : 1;
        if ($soluong < 1) $soluong = 1;

        $sp = $cf->ChiTietSanPham($id);
        if ($sp) {
            if (isset($_SESSION['giohang'][$id])) {
                $_SESSION['giohang'][$id]['so_luong'] += $soluong;
            } else {
                $_SESSION['giohang'][$id] = [
                    'id_san_pham'  => $sp['id_san_pham'],
                    'ten_san_pham' => $sp['ten_san_pham'],
                    'hinh_anh'     => $sp['hinh_anh'],
                    'gia'          => $sp['gia'],
                    'so_luong'     => $soluong
                ];
            }
            $_SESSION['thongbao'] = 'Đã thêm "' . $sp['ten_san_pham'] . '" vào giỏ hàng!';
        }
        if (isset($_SESSION['user']['id_nguoi_dung'])) {
            $cf->LuuGioHangNguoiDung((int)$_SESSION['user']['id_nguoi_dung'], $_SESSION['giohang']);
        }
        header("Location: giohang.php");
        exit;

    // 2. CẬP NHẬT SỐ LƯỢNG TRONG GIỎ HÀNG
    case 'update':
        if (isset($_POST['soluong']) && is_array($_POST['soluong'])) {
            foreach ($_POST['soluong'] as $id => $sl) {
                $id = (int)$id;
                $sl = (int)$sl;
                if (isset($_SESSION['giohang'][$id])) {
                    if ($sl <= 0) {
                        unset($_SESSION['giohang'][$id]);
                    } else {
                        $_SESSION['giohang'][$id]['so_luong'] = $sl;
                    }
                }
            }
            if (isset($_SESSION['user']['id_nguoi_dung'])) {
                $cf->LuuGioHangNguoiDung((int)$_SESSION['user']['id_nguoi_dung'], $_SESSION['giohang']);
            }
            $_SESSION['thongbao'] = "Đã cập nhật giỏ hàng!";
        }
        header("Location: giohang.php");
        exit;

    // 3. XÓA 1 SẢN PHẨM KHỎI GIỎ
    case 'delete':
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if (isset($_SESSION['giohang'][$id])) {
            unset($_SESSION['giohang'][$id]);
            if (isset($_SESSION['user']['id_nguoi_dung'])) {
                $cf->LuuGioHangNguoiDung((int)$_SESSION['user']['id_nguoi_dung'], $_SESSION['giohang']);
            }
            $_SESSION['thongbao'] = "Đã xóa sản phẩm khỏi giỏ hàng!";
        }
        header("Location: giohang.php");
        exit;

    // 4. XÓA TOÀN BỘ GIỎ HÀNG
    case 'clear':
        unset($_SESSION['giohang']);
        if (isset($_SESSION['user']['id_nguoi_dung'])) {
            $cf->LuuGioHangNguoiDung((int)$_SESSION['user']['id_nguoi_dung'], []);
        }
        $_SESSION['thongbao'] = "Đã xóa toàn bộ giỏ hàng!";
        header("Location: giohang.php");
        exit;

    // === SỬA ĐỔI: LƯU ĐƠN HÀNG VÀO DATABASE THAY VÌ CHỈ XÓA SESSION ===
    case 'checkout':
        if (!empty($_SESSION['giohang'])) {
            $ten_khach_hang = trim($_POST['ten_khach_hang'] ?? '');
            $so_dien_thoai  = trim($_POST['so_dien_thoai'] ?? '');
            $dia_chi        = trim($_POST['dia_chi'] ?? '');
            $ghi_chu        = trim($_POST['ghi_chu'] ?? '');

            if ($ten_khach_hang === '' || $so_dien_thoai === '' || $dia_chi === '') {
                $_SESSION['thongbao'] = "Vui lòng nhập đầy đủ Họ tên, Số điện thoại và Địa chỉ nhận hàng!";
                header("Location: giohang.php");
                exit;
            }

            $id_nguoi_dung = isset($_SESSION['user']['id_nguoi_dung'])
                             ? (int)$_SESSION['user']['id_nguoi_dung']
                             : null;

            $id_don_hang = $cf->DatHang(
                $id_nguoi_dung,
                $ten_khach_hang,
                $so_dien_thoai,
                $dia_chi,
                $ghi_chu,
                $_SESSION['giohang'],
                'cho_xac_nhan'
            );

            if ($id_don_hang) {
                unset($_SESSION['giohang']);
                if (isset($_SESSION['user']['id_nguoi_dung'])) {
                    $cf->LuuGioHangNguoiDung((int)$_SESSION['user']['id_nguoi_dung'], []);
                }
                if (!isset($_SESSION['don_vua_dat']) || !is_array($_SESSION['don_vua_dat'])) {
                    $_SESSION['don_vua_dat'] = [];
                }
                if (!in_array((int)$id_don_hang, $_SESSION['don_vua_dat'], true)) {
                    $_SESSION['don_vua_dat'][] = (int)$id_don_hang;
                }
                $_SESSION['thongbao'] = "Đặt hàng thành công! Mã đơn của bạn là #" . $id_don_hang . ". Bạn có thể theo dõi tiến trình pha chế ngay bên dưới.";
                header("Location: theodoi_donhang.php?id=" . (int)$id_don_hang);
                exit;
            } else {
                $_SESSION['thongbao'] = "Có lỗi xảy ra khi lưu đơn hàng, vui lòng thử lại!";
            }
        }
        header("Location: giohang.php");
        exit;
    // === HẾT PHẦN SỬA ĐỔI ===

    default:
        header("Location: giohang.php");
        exit;
}
?>
