<?php
require_once "caphe.php";
$cf = new caphe;

// Nếu đã đăng nhập rồi thì chuyển về trang chủ
if (isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

$loi = "";
$email = "";
$thongbao = isset($_SESSION['thongbao_auth']) ? $_SESSION['thongbao_auth'] : "";
unset($_SESSION['thongbao_auth']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $mat_khau = $_POST['mat_khau'] ?? '';

    if ($email === "" || $mat_khau === "") {
        $loi = "Vui lòng nhập đầy đủ Email và Mật khẩu!";
    } else {
        $user = $cf->DangNhap($email, $mat_khau);
        if ($user) {
            $_SESSION['user'] = $user;
            $cf->DongBoGioHangKhiDangNhap((int)$user['id_nguoi_dung']);
            header("Location: index.php");
            exit;
        } else {
            $loi = "Email hoặc mật khẩu không chính xác!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Coffee House - Đăng nhập</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- HEADER (giữ nguyên cấu trúc các trang khác) -->
  <header>
    <div class="container">
      <div class="header-left">
        <div class="logo">☕ Coffee House</div>
        <nav>
          <ul>
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="danhmuc.php">Danh mục</a></li>
            <li><a href="products.php">Sản phẩm</a></li>
            <li><a href="theodoi_donhang.php">Theo dõi đơn</a></li>
            <li><a href="index.php#about">Giới thiệu</a></li>
            <li><a href="index.php#footer">Liên hệ</a></li>
          </ul>
        </nav>
      </div>

      <div class="header-right">
        <a href="giohang.php">🛒 Giỏ hàng (<?= $cf->TongSoLuongGioHang() ?>)</a>
        <?php if (isset($_SESSION['user'])) { ?>
          <a href="taikhoan.php">👤 <?= htmlspecialchars($_SESSION['user']['ho_ten']) ?></a>
          <a href="dangxuat.php">Đăng xuất</a>
        <?php } else { ?>
          <a href="dangnhap.php">Đăng nhập</a>
          <a href="dangky.php">Đăng ký</a>
        <?php } ?>
      </div>
    </div>
  </header>

  <!-- TIÊU ĐỀ -->
  <div class="page-title">
    <h1>Đăng nhập</h1>
  </div>

  <!-- KHUNG FORM ĐĂNG NHẬP -->
  <div class="auth-wrapper">
    <div class="auth-box">
      <?php if ($thongbao !== "") { ?>
        <div class="auth-alert auth-alert-success"><?= htmlspecialchars($thongbao) ?></div>
      <?php } ?>

      <?php if ($loi !== "") { ?>
        <div class="auth-alert auth-alert-error"><?= htmlspecialchars($loi) ?></div>
      <?php } ?>

      <form method="post" action="dangnhap.php">
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" placeholder="Nhập email đã đăng ký..."
                 value="<?= htmlspecialchars($email) ?>" required>
        </div>

        <div class="form-group">
          <label for="mat_khau">Mật khẩu</label>
          <input type="password" id="mat_khau" name="mat_khau" placeholder="Nhập mật khẩu..." required>
        </div>

        <button type="submit" class="btn auth-btn">Đăng nhập</button>
      </form>

      <p class="auth-links">
        Chưa có tài khoản? <a href="dangky.php">Đăng ký tài khoản mới</a>
      </p>
    </div>
  </div>

  <!-- FOOTER (giữ nguyên cấu trúc các trang khác) -->
  <footer id="footer">
    <div class="footer-container">
      <div class="footer-col">
        <h3>☕ Coffee House</h3>
        <p>Thương hiệu cà phê chất lượng, mang tới hương vị đậm đà nguyên bản từ những hạt cà phê hảo hạng.</p>
      </div>
      <div class="footer-col">
        <h3>Thông Tin Liên Hệ</h3>
        <p>📍 Địa chỉ: 123 Đường Nguyễn Trãi, Quận 1, TP.HCM</p>
        <p>📞 Điện thoại: 0909 123 456</p>
        <p>✉️ Email: contact@coffeehouse.vn</p>
        <p>⏰ Giờ mở cửa: 07:00 - 22:30 hàng ngày</p>
      </div>
      <div class="footer-col">
        <h3>Liên Kết Nhanh</h3>
        <ul>
          <li><a href="index.php">Trang chủ</a></li>
          <li><a href="danhmuc.php">Danh mục</a></li>
          <li><a href="products.php">Sản phẩm</a></li>
          <li><a href="giohang.php">Giỏ hàng</a></li>
        </ul>
      </div>
    </div>
    <div class="copyright">
      <p>&copy; Coffee House. Tất cả quyền được bảo lưu.</p>
    </div>
  </footer>

</body>
</html>