<?php
require_once "caphe.php";
$cf = new caphe;

// Yêu cầu đăng nhập trước khi xem trang tài khoản
if (!isset($_SESSION['user']['id_nguoi_dung'])) {
    $_SESSION['thongbao_auth'] = "Vui lòng đăng nhập để xem thông tin tài khoản!";
    header("Location: dangnhap.php");
    exit;
}

$id_user = (int)$_SESSION['user']['id_nguoi_dung'];
$thongbao = "";
$loi = "";

// Xử lý cập nhật hồ sơ hoặc đổi mật khẩu
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $ho_ten = trim($_POST['ho_ten'] ?? '');
        $dien_thoai = trim($_POST['dien_thoai'] ?? '');

        if ($ho_ten === '') {
            $loi = "Họ và tên không được để trống!";
        } elseif ($cf->CapNhatThongTinCaNhan($id_user, $ho_ten, $dien_thoai)) {
            $_SESSION['user']['ho_ten'] = $ho_ten;
            $_SESSION['user']['dien_thoai'] = $dien_thoai;
            $thongbao = "Đã cập nhật thông tin tài khoản thành công!";
        } else {
            $loi = "Có lỗi xảy ra khi cập nhật thông tin, vui lòng thử lại!";
        }
    } elseif ($action === 'change_password') {
        $mat_khau_cu = $_POST['mat_khau_cu'] ?? '';
        $mat_khau_moi = $_POST['mat_khau_moi'] ?? '';
        $nhap_lai = $_POST['nhap_lai_mat_khau'] ?? '';

        if ($mat_khau_cu === '' || $mat_khau_moi === '' || $nhap_lai === '') {
            $loi = "Vui lòng nhập đầy đủ các trường mật khẩu!";
        } elseif (strlen($mat_khau_moi) < 6) {
            $loi = "Mật khẩu mới phải có ít nhất 6 ký tự!";
        } elseif ($mat_khau_moi !== $nhap_lai) {
            $loi = "Mật khẩu mới nhập lại không khớp!";
        } else {
            $ketqua = $cf->DoiMatKhauCaNhan($id_user, $mat_khau_cu, $mat_khau_moi);
            if ($ketqua === true) {
                $thongbao = "Đổi mật khẩu thành công!";
            } else {
                $loi = $ketqua;
            }
        }
    }
}

$taikhoan = $cf->ThongTinTaiKhoan($id_user);
if (!$taikhoan || (isset($taikhoan['trang_thai']) && (int)$taikhoan['trang_thai'] === 0)) {
    unset($_SESSION['user']);
    $_SESSION['thongbao_auth'] = "Tài khoản không tồn tại hoặc đã bị khóa.";
    header("Location: dangnhap.php");
    exit;
}

$ds_don = $cf->ListDonHangCuaKhach($id_user);

function nhanTrangThaiKhach($tt) {
    switch ($tt) {
        case 'cho_xac_nhan': return ['Chờ xác nhận', 'status-warning'];
        case 'dang_pha_che': return ['Đang pha chế', 'status-info'];
        case 'hoan_thanh':   return ['Hoàn thành',   'status-success'];
        case 'da_huy':       return ['Đã hủy',       'status-danger'];
        default:             return [$tt,            'status-secondary'];
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Coffee House - Tài khoản của tôi</title>
  <link rel="stylesheet" href="style.css?v=4">
</head>
<body class="account-page">

  <header>
    <div class="container">
      <div class="header-left">
        <div class="logo">☕ Coffee House</div>
        <nav>
          <ul>
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="danhmuc.php">Danh mục</a></li>
            <li><a href="products.php">Sản phẩm</a></li>
            <li><a href="theodoi_donhang.php">Theo dõi đơn</a></li>
            <li><a href="index.php#footer">Liên hệ</a></li>
          </ul>
        </nav>
      </div>

      <div class="header-right">
        <a href="giohang.php">🛒 Giỏ hàng (<?= $cf->TongSoLuongGioHang() ?>)</a>
        <a href="taikhoan.php" class="active-user-link">👤 <?= htmlspecialchars($taikhoan['ho_ten']) ?></a>
        <a href="dangxuat.php">Đăng xuất</a>
      </div>
    </div>
  </header>

  <div class="page-title">
    <h1>Thông tin tài khoản</h1>
  </div>

  <div class="account-wrapper">
    <?php if ($thongbao !== "") { ?>
      <div class="auth-alert auth-alert-success"><?= htmlspecialchars($thongbao) ?></div>
    <?php } ?>

    <?php if ($loi !== "") { ?>
      <div class="auth-alert auth-alert-error"><?= htmlspecialchars($loi) ?></div>
    <?php } ?>

    <?php
      $chu_cai_dau = mb_strtoupper(mb_substr(trim($taikhoan['ho_ten']), 0, 1, 'UTF-8'), 'UTF-8');
      if ($chu_cai_dau === '') $chu_cai_dau = 'U';
    ?>

    <!-- Banner hồ sơ người dùng -->
    <section class="account-hero">
      <div class="account-hero-left">
        <div class="account-avatar"><?= htmlspecialchars($chu_cai_dau) ?></div>
        <div class="account-hero-meta">
          <div class="account-hero-badges">
            <span class="hero-member-tag">Thành viên #<?= (int)$taikhoan['id_nguoi_dung'] ?></span>
            <span class="hero-status-tag">● Đang hoạt động</span>
          </div>
          <h2><?= htmlspecialchars($taikhoan['ho_ten']) ?></h2>
          <p>✉️ <?= htmlspecialchars($taikhoan['email']) ?> &nbsp;•&nbsp; 📞 <?= htmlspecialchars($taikhoan['dien_thoai'] ?: 'Chưa cập nhật SĐT') ?></p>
        </div>
      </div>
      <div class="account-hero-actions">
        <a href="giohang.php" class="hero-btn-light">🛒 Giỏ hàng (<?= $cf->TongSoLuongGioHang() ?>)</a>
        <a href="theodoi_donhang.php" class="hero-btn-outline">📦 Theo dõi đơn</a>
      </div>
    </section>

    <!-- Thống kê nhanh của tài khoản -->
    <div class="account-stats-grid">
      <div class="account-stat-card">
        <div class="stat-icon-box">🪪</div>
        <div>
          <span>Mã thành viên</span>
          <strong>#<?= (int)$taikhoan['id_nguoi_dung'] ?></strong>
        </div>
      </div>
      <div class="account-stat-card">
        <div class="stat-icon-box">🛍️</div>
        <div>
          <span>Tổng đơn đã đặt</span>
          <strong><?= (int)$taikhoan['tong_don'] ?> đơn</strong>
        </div>
      </div>
      <div class="account-stat-card">
        <div class="stat-icon-box">✅</div>
        <div>
          <span>Đơn hoàn thành</span>
          <strong><?= (int)$taikhoan['don_hoan_thanh'] ?> đơn</strong>
        </div>
      </div>
      <div class="account-stat-card">
        <div class="stat-icon-box">💰</div>
        <div>
          <span>Tổng chi tiêu</span>
          <strong class="price"><?= $cf->DinhDangGia($taikhoan['tong_chi_tieu']) ?></strong>
        </div>
      </div>
    </div>

    <!-- Thông tin chi tiết + Chỉnh sửa -->
    <div class="account-grid-2col">
      <section class="account-card">
        <div class="account-section-title">
          <span class="section-icon">👤</span>
          <h3>Hồ sơ cá nhân</h3>
        </div>

        <div class="account-info-list">
          <div class="account-info-row">
            <span class="info-label">Họ và tên</span>
            <strong class="info-value"><?= htmlspecialchars($taikhoan['ho_ten']) ?></strong>
          </div>
          <div class="account-info-row">
            <span class="info-label">Email đăng nhập</span>
            <strong class="info-value"><?= htmlspecialchars($taikhoan['email']) ?></strong>
          </div>
          <div class="account-info-row">
            <span class="info-label">Số điện thoại</span>
            <strong class="info-value"><?= htmlspecialchars($taikhoan['dien_thoai'] ?: 'Chưa cập nhật') ?></strong>
          </div>
          <div class="account-info-row">
            <span class="info-label">Ngày tham gia</span>
            <strong class="info-value"><?= !empty($taikhoan['ngay_tao']) ? date('d/m/Y H:i', strtotime($taikhoan['ngay_tao'])) : 'Không rõ' ?></strong>
          </div>
          <div class="account-info-row">
            <span class="info-label">Trạng thái</span>
            <span class="order-status-pill status-success">Đang hoạt động</span>
          </div>
        </div>

        <hr class="account-divider">

        <h4>✏️ Cập nhật thông tin</h4>
        <form method="post" action="taikhoan.php">
          <input type="hidden" name="action" value="update_profile">
          <div class="form-group">
            <label for="ho_ten">Họ và tên *</label>
            <input type="text" id="ho_ten" name="ho_ten" required
                   value="<?= htmlspecialchars($taikhoan['ho_ten']) ?>">
          </div>
          <div class="form-group">
            <label for="dien_thoai">Số điện thoại</label>
            <input type="text" id="dien_thoai" name="dien_thoai"
                   placeholder="Nhập số điện thoại liên hệ..."
                   value="<?= htmlspecialchars($taikhoan['dien_thoai'] ?? '') ?>">
          </div>
          <button type="submit" class="btn auth-btn">Lưu thông tin</button>
        </form>
      </section>

      <section class="account-card">
        <div class="account-section-title">
          <span class="section-icon">🔒</span>
          <h3>Bảo mật &amp; Đổi mật khẩu</h3>
        </div>
        <p class="account-hint">Mật khẩu mới cần có ít nhất 6 ký tự để bảo vệ tài khoản của bạn an toàn hơn.</p>
        <form method="post" action="taikhoan.php">
          <input type="hidden" name="action" value="change_password">
          <div class="form-group">
            <label for="mat_khau_cu">Mật khẩu hiện tại *</label>
            <input type="password" id="mat_khau_cu" name="mat_khau_cu" required placeholder="Nhập mật khẩu hiện tại...">
          </div>
          <div class="form-group">
            <label for="mat_khau_moi">Mật khẩu mới *</label>
            <input type="password" id="mat_khau_moi" name="mat_khau_moi" required placeholder="Tối thiểu 6 ký tự...">
          </div>
          <div class="form-group">
            <label for="nhap_lai_mat_khau">Nhập lại mật khẩu mới *</label>
            <input type="password" id="nhap_lai_mat_khau" name="nhap_lai_mat_khau" required placeholder="Nhập lại mật khẩu mới...">
          </div>
          <button type="submit" class="btn auth-btn">Cập nhật mật khẩu</button>
        </form>
      </section>
    </div>

    <!-- Lịch sử đơn hàng của tài khoản -->
    <section class="account-card" style="margin-top: 25px;">
      <div class="account-card-head">
        <h3>Lịch sử đơn hàng của bạn</h3>
        <a href="products.php" class="btn btn-outline">+ Đặt thêm món</a>
      </div>

      <?php if (!$ds_don || $ds_don->num_rows == 0) { ?>
        <div class="cart-empty" style="margin-top: 10px;">
          <p>Bạn chưa đặt đơn hàng nào bằng tài khoản này.</p>
          <a href="products.php" class="btn">Khám phá thực đơn</a>
        </div>
      <?php } else { ?>
        <div class="table-scroll">
          <table class="cart-table">
            <thead>
              <tr>
                <th>Mã đơn</th>
                <th>Thời gian đặt</th>
                <th>Địa chỉ / Hình thức</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Theo dõi</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($don = $ds_don->fetch_assoc()) {
                [$ten_tt, $class_tt] = nhanTrangThaiKhach($don['trang_thai']);
              ?>
                <tr>
                  <td><strong>#<?= (int)$don['id_don_hang'] ?></strong></td>
                  <td><?= date('d/m/Y H:i', strtotime($don['ngay_dat'])) ?></td>
                  <td><?= htmlspecialchars($don['dia_chi']) ?></td>
                  <td class="price"><?= $cf->DinhDangGia($don['tong_tien']) ?></td>
                  <td><span class="order-status-pill <?= $class_tt ?>"><?= htmlspecialchars($ten_tt) ?></span></td>
                  <td>
                    <a href="theodoi_donhang.php?id=<?= (int)$don['id_don_hang'] ?>" class="btn btn-sm-track">
                      Xem tiến trình
                    </a>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      <?php } ?>
    </section>
  </div>

  <footer id="footer">
    <div class="footer-container">
      <div class="footer-col">
        <h3>☕ Coffee House</h3>
        <p>Thương hiệu cà phê chất lượng, mang tới hương vị đậm đà nguyên bản từ những hạt cà phê hảo hạng.</p>
      </div>
      <div class="footer-col">
        <h3>Thông Tin Liên Hệ</h3>
        <p>📍 Địa chỉ: 123 Đường Nguyễn Trãi, Quận 1, TP.HCM</p>
        <p>📞 Điện thoại: 0909 123 456</p>
        <p>✉️ Email: contact@coffeehouse.vn</p>
        <p>⏰ Giờ mở cửa: 07:00 - 22:30 hàng ngày</p>
      </div>
      <div class="footer-col">
        <h3>Liên Kết Nhanh</h3>
        <ul>
          <li><a href="index.php">Trang chủ</a></li>
          <li><a href="danhmuc.php">Danh mục</a></li>
          <li><a href="products.php">Sản phẩm</a></li>
          <li><a href="giohang.php">Giỏ hàng</a></li>
        </ul>
      </div>
    </div>
    <div class="copyright">
      <p>&copy; Coffee House. Tất cả quyền được bảo lưu.</p>
    </div>
  </footer>

</body>
</html>
