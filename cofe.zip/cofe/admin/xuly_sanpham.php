<?php
// === FILE MỚI THÊM: XỬ LÝ NGHIỆP VỤ QUẢN LÝ SẢN PHẨM (ADMIN) ===
require_once "check_admin.php"; // Kiểm tra session & chặn truy cập trái phép
/** @var caphe $cf */
/** @var bool $la_admin */

if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền thao tác sản phẩm.";
    header("Location: dashboard.php");
    exit;
}

/**
 * Hàm hỗ trợ upload ảnh sản phẩm vào thư mục ../img/
 * Trả về mảng ['ok' => true, 'path' => 'img/ten_file.jpg'] hoặc ['ok' => false, 'msg' => 'Lỗi...']
 */
function xuLyUploadAnhSanPham($file_input) {
    if (!isset($file_input) || $file_input['error'] === UPLOAD_ERR_NO_FILE) {
        return ['ok' => true, 'path' => null];
    }

    if ($file_input['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'msg' => 'Có lỗi xảy ra khi tải tệp hình ảnh lên!'];
    }

    // Giới hạn dung lượng tối đa 3MB
    if ($file_input['size'] > 3 * 1024 * 1024) {
        return ['ok' => false, 'msg' => 'Dung lượng hình ảnh không được vượt quá 3MB!'];
    }

    $ext = strtolower(pathinfo($file_input['name'], PATHINFO_EXTENSION));
    $ext_hop_le = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    if (!in_array($ext, $ext_hop_le)) {
        return ['ok' => false, 'msg' => 'Chỉ chấp nhận tệp hình ảnh định dạng JPG, PNG, WEBP hoặc GIF!'];
    }

    $thu_muc_dich = __DIR__ . "/../img/";
    if (!is_dir($thu_muc_dich)) {
        mkdir($thu_muc_dich, 0777, true);
    }

    $ten_file_moi = "sp_" . time() . "_" . mt_rand(100, 999) . "." . $ext;
    $duong_dan_vat_ly = $thu_muc_dich . $ten_file_moi;

    if (move_uploaded_file($file_input['tmp_name'], $duong_dan_vat_ly)) {
        return ['ok' => true, 'path' => "img/" . $ten_file_moi];
    }

    return ['ok' => false, 'msg' => 'Không thể lưu tệp hình ảnh vào thư mục img/!'];
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    // 1. THÊM SẢN PHẨM MỚI
    case 'create':
        $ten_san_pham = trim($_POST['ten_san_pham'] ?? '');
        $id_danh_muc  = isset($_POST['id_danh_muc']) ? (int)$_POST['id_danh_muc'] : 0;
        $gia          = isset($_POST['gia']) ? (float)$_POST['gia'] : 0;
        $noi_bat      = isset($_POST['noi_bat']) ? (int)$_POST['noi_bat'] : 0;
        $mo_ta        = trim($_POST['mo_ta'] ?? '');

        $_SESSION['admin_old_sp'] = [
            'ten_san_pham' => $ten_san_pham,
            'id_danh_muc'  => $id_danh_muc,
            'gia'          => $gia > 0 ? $gia : '',
            'noi_bat'      => (string)$noi_bat,
            'mo_ta'        => $mo_ta
        ];

        if ($ten_san_pham === '' || $id_danh_muc <= 0 || $gia <= 0) {
            $_SESSION['admin_loi_sp'] = "Vui lòng nhập đầy đủ Tên sản phẩm, Danh mục và Giá bán lớn hơn 0!";
            header("Location: sanpham_them.php");
            exit;
        }

        $upload = xuLyUploadAnhSanPham($_FILES['hinh_anh'] ?? null);
        if (!$upload['ok']) {
            $_SESSION['admin_loi_sp'] = $upload['msg'];
            header("Location: sanpham_them.php");
            exit;
        }

        $duong_dan_anh = $upload['path'] ?? "img/caphe.jpg";

        $ket_qua = $cf->ThemSanPham($ten_san_pham, $duong_dan_anh, $gia, $id_danh_muc, $noi_bat, $mo_ta);
        if ($ket_qua === true) {
            unset($_SESSION['admin_old_sp']);
            $_SESSION['admin_thongbao'] = "Đã thêm sản phẩm \"" . $ten_san_pham . "\" vào thực đơn thành công!";
            header("Location: sanpham.php");
        } else {
            $_SESSION['admin_loi_sp'] = $ket_qua;
            header("Location: sanpham_them.php");
        }
        exit;

    // 2. CẬP NHẬT THÔNG TIN SẢN PHẨM
    case 'update':
        $id_san_pham  = isset($_POST['id_san_pham']) ? (int)$_POST['id_san_pham'] : 0;
        $ten_san_pham = trim($_POST['ten_san_pham'] ?? '');
        $id_danh_muc  = isset($_POST['id_danh_muc']) ? (int)$_POST['id_danh_muc'] : 0;
        $gia          = isset($_POST['gia']) ? (float)$_POST['gia'] : 0;
        $noi_bat      = isset($_POST['noi_bat']) ? (int)$_POST['noi_bat'] : 0;
        $mo_ta        = trim($_POST['mo_ta'] ?? '');

        if ($id_san_pham <= 0) {
            header("Location: sanpham.php");
            exit;
        }

        $sp_cu = $cf->ChiTietSanPhamAdmin($id_san_pham);
        if (!$sp_cu) {
            $_SESSION['admin_thongbao'] = "Không tìm thấy sản phẩm #" . $id_san_pham;
            header("Location: sanpham.php");
            exit;
        }

        if ($ten_san_pham === '' || $id_danh_muc <= 0 || $gia <= 0) {
            $_SESSION['admin_loi_sp'] = "Vui lòng nhập đầy đủ Tên sản phẩm, Danh mục và Giá bán lớn hơn 0!";
            header("Location: sanpham_sua.php?id=" . $id_san_pham);
            exit;
        }

        $upload = xuLyUploadAnhSanPham($_FILES['hinh_anh'] ?? null);
        if (!$upload['ok']) {
            $_SESSION['admin_loi_sp'] = $upload['msg'];
            header("Location: sanpham_sua.php?id=" . $id_san_pham);
            exit;
        }

        // Nếu người dùng có upload ảnh mới thì lấy đường dẫn mới, ngược lại giữ nguyên ảnh cũ
        $duong_dan_anh = ($upload['path'] !== null) ? $upload['path'] : $sp_cu['hinh_anh'];

        $ket_qua = $cf->CapNhatSanPham($id_san_pham, $ten_san_pham, $duong_dan_anh, $gia, $id_danh_muc, $noi_bat, $mo_ta);
        if ($ket_qua === true) {
            // Xóa file ảnh upload cũ (chỉ xóa file có tiền tố sp_ do admin upload để tránh xóa ảnh mẫu)
            if ($upload['path'] !== null && !empty($sp_cu['hinh_anh']) && strpos($sp_cu['hinh_anh'], 'img/sp_') === 0) {
                $file_cu = __DIR__ . "/../" . $sp_cu['hinh_anh'];
                if (file_exists($file_cu)) {
                    @unlink($file_cu);
                }
            }
            $_SESSION['admin_thongbao'] = "Đã cập nhật thông tin sản phẩm #" . $id_san_pham . " thành công!";
        } else {
            $_SESSION['admin_loi_sp'] = $ket_qua;
        }
        header("Location: sanpham_sua.php?id=" . $id_san_pham);
        exit;

    // 3. BẬT / TẮT NHANH TRẠNG THÁI NỔI BẬT TRANG CHỦ
    case 'toggle_featured':
        $id     = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $status = isset($_GET['status']) ? (int)$_GET['status'] : 0;

        if ($id > 0 && $cf->DoiTrangThaiNoiBat($id, $status)) {
            $nhan = ($status === 1) ? "đánh dấu nổi bật" : "bỏ nổi bật";
            $_SESSION['admin_thongbao'] = "Đã " . $nhan . " cho sản phẩm #" . $id . "!";
        }
        header("Location: sanpham.php");
        exit;

    // 4. XÓA SẢN PHẨM
    case 'delete':
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id > 0) {
            $sp_can_xoa = $cf->ChiTietSanPhamAdmin($id);
            if ($sp_can_xoa && $cf->XoaSanPham($id)) {
                if (!empty($sp_can_xoa['hinh_anh']) && strpos($sp_can_xoa['hinh_anh'], 'img/sp_') === 0) {
                    $file_anh = __DIR__ . "/../" . $sp_can_xoa['hinh_anh'];
                    if (file_exists($file_anh)) {
                        @unlink($file_anh);
                    }
                }
                $_SESSION['admin_thongbao'] = "Đã xóa sản phẩm #" . $id . " khỏi thực đơn!";
            } else {
                $_SESSION['admin_loi_sp'] = "Không thể xóa sản phẩm #" . $id . "!";
            }
        }
        header("Location: sanpham.php");
        exit;

    default:
        header("Location: sanpham.php");
        exit;
}
?>