<?php
// === FILE MỚI THÊM: XỬ LÝ NGHIỆP VỤ QUẢN LÝ KHÁCH HÀNG ADMIN ===
require_once "check_admin.php"; // Chặn truy cập trái phép
/** @var caphe $cf */
/** @var bool $la_admin */

if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền thực hiện thao tác này.";
    header("Location: index.php");
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    // 1. CẬP NHẬT THÔNG TIN KHÁCH HÀNG
    case 'update':
        $id_nguoi_dung = isset($_POST['id_nguoi_dung']) ? (int)$_POST['id_nguoi_dung'] : 0;
        $ho_ten        = trim($_POST['ho_ten'] ?? '');
        $email         = trim($_POST['email'] ?? '');
        $dien_thoai    = trim($_POST['dien_thoai'] ?? '');
        $trang_thai    = isset($_POST['trang_thai']) ? (int)$_POST['trang_thai'] : 1;
        $mat_khau_moi  = $_POST['mat_khau_moi'] ?? '';

        if ($id_nguoi_dung <= 0) {
            header("Location: khachhang.php");
            exit;
        }

        if ($ho_ten === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['admin_loi_kh'] = "Vui lòng nhập đầy đủ Họ tên và đúng định dạng Email!";
            header("Location: khachhang_chitiet.php?id=" . $id_nguoi_dung);
            exit;
        }

        if ($mat_khau_moi !== '' && strlen($mat_khau_moi) < 6) {
            $_SESSION['admin_loi_kh'] = "Mật khẩu mới phải có ít nhất 6 ký tự!";
            header("Location: khachhang_chitiet.php?id=" . $id_nguoi_dung);
            exit;
        }

        $ket_qua = $cf->CapNhatKhachHang($id_nguoi_dung, $ho_ten, $email, $dien_thoai, $trang_thai, $mat_khau_moi);
        if ($ket_qua === true) {
            $_SESSION['admin_thongbao'] = "Đã cập nhật hồ sơ khách hàng #" . $id_nguoi_dung . " thành công!";
        } else {
            $_SESSION['admin_loi_kh'] = $ket_qua;
        }
        header("Location: khachhang_chitiet.php?id=" . $id_nguoi_dung);
        exit;

    // 2. KHÓA / MỞ KHÓA NHANH TÀI KHOẢN KHÁCH HÀNG
    case 'toggle_status':
        $id     = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $status = isset($_GET['status']) ? (int)$_GET['status'] : 1;

        if ($id > 0 && $cf->DoiTrangThaiKhachHang($id, $status)) {
            $nhan = ($status === 1) ? "mở khóa" : "khóa";
            $_SESSION['admin_thongbao'] = "Đã " . $nhan . " tài khoản khách hàng #" . $id . "!";
        }
        header("Location: khachhang.php");
        exit;

    // 3. XÓA TÀI KHOẢN KHÁCH HÀNG
    case 'delete':
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id > 0 && $cf->XoaKhachHang($id)) {
            $_SESSION['admin_thongbao'] = "Đã xóa tài khoản khách hàng #" . $id . "!";
        }
        header("Location: khachhang.php");
        exit;

    default:
        header("Location: khachhang.php");
        exit;
}
?>
