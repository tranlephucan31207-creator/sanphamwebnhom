<?php
require_once "check_admin.php"; // Chặn truy cập trái phép nếu chưa đăng nhập admin
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền quản lý khách hàng.";
    header("Location: index.php");
    exit;
}

$trang_thai = isset($_GET['trang_thai']) ? trim($_GET['trang_thai']) : '';
$tukhoa     = isset($_GET['tukhoa']) ? trim($_GET['tukhoa']) : '';

$thong_ke = $cf->ThongKeKhachHang();
$ds_khach = $cf->ListKhachHang($trang_thai, $tukhoa);

$thong_bao = isset($_SESSION['admin_thongbao']) ? $_SESSION['admin_thongbao'] : "";
unset($_SESSION['admin_thongbao']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quản lý khách hàng - Coffee House Admin</title>
  <link rel="stylesheet" href="admin_style.css">
</head>
<body>

<div class="admin-layout">
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag role-admin">Quản trị viên</span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
      <!-- MỚI THÊM: MENU QUẢN LÝ SẢN PHẨM -->
      <a href="sanpham.php">☕ Quản lý sản phẩm</a>
      <!-- HẾT PHẦN MỚI THÊM -->
      <a href="khachhang.php">👥 Quản lý khách hàng</a>
      <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <main class="admin-main">
    <header class="admin-topbar">
      <div>
        <h1>Quản lý khách hàng</h1>
        <p>Tra cứu thông tin thành viên, lịch sử mua hàng, chi tiêu và trạng thái tài khoản</p>
      </div>
    </header>

    <?php if ($thong_bao !== "") { ?>
      <div class="adm-alert adm-alert-success"><?= htmlspecialchars($thong_bao) ?></div>
    <?php } ?>

    <section class="kpi-grid">
      <div class="kpi-card">
        <span class="kpi-label">Tổng khách hàng</span>
        <strong class="kpi-value"><?= (int)$thong_ke['tong_khach'] ?></strong>
      </div>
      <div class="kpi-card kpi-success">
        <span class="kpi-label">Đang hoạt động</span>
        <strong class="kpi-value"><?= (int)$thong_ke['dang_hoat_dong'] ?></strong>
      </div>
      <div class="kpi-card kpi-danger">
        <span class="kpi-label">Đang bị khóa</span>
        <strong class="kpi-value"><?= (int)$thong_ke['bi_khoa'] ?></strong>
      </div>
      <div class="kpi-card kpi-info">
        <span class="kpi-label">Khách đã từng đặt món</span>
        <strong class="kpi-value"><?= (int)$thong_ke['da_dat_hang'] ?></strong>
      </div>
    </section>

    <section class="filter-bar">
      <div class="status-tabs">
        <a href="khachhang.php" class="<?= $trang_thai === '' ? 'active' : '' ?>">Tất cả khách hàng</a>
        <a href="khachhang.php?trang_thai=1" class="<?= $trang_thai === '1' ? 'active' : '' ?>">Đang hoạt động</a>
        <a href="khachhang.php?trang_thai=0" class="<?= $trang_thai === '0' ? 'active' : '' ?>">Bị khóa</a>
      </div>

      <form method="get" action="khachhang.php" class="adm-search-form">
        <?php if ($trang_thai !== '') { ?>
          <input type="hidden" name="trang_thai" value="<?= htmlspecialchars($trang_thai) ?>">
        <?php } ?>
        <input type="text" name="tukhoa" placeholder="Tìm mã KH (#3), họ tên, email, SĐT..."
               value="<?= htmlspecialchars($tukhoa) ?>">
        <button type="submit" class="adm-btn adm-btn-dark">Tìm</button>
      </form>
    </section>

    <section class="adm-card">
      <div class="table-responsive">
        <table class="adm-table">
          <thead>
            <tr>
              <th>Mã KH</th>
              <th>Họ tên khách hàng</th>
              <th>Liên hệ</th>
              <th>Ngày đăng ký</th>
              <th>Số đơn</th>
              <th>Tổng chi tiêu</th>
              <th>Trạng thái</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($ds_khach->num_rows == 0) { ?>
              <tr>
                <td colspan="8" class="text-center">Chưa có khách hàng nào phù hợp.</td>
              </tr>
            <?php } else {
              while ($kh = $ds_khach->fetch_assoc()) {
                $hoat_dong = ((int)$kh['trang_thai'] === 1);
            ?>
              <tr>
                <td><strong>#<?= $kh['id_nguoi_dung'] ?></strong></td>
                <td>
                  <strong><?= htmlspecialchars($kh['ho_ten']) ?></strong>
                </td>
                <td>
                  ✉️ <?= htmlspecialchars($kh['email']) ?><br>
                  <small class="text-muted">📞 <?= htmlspecialchars($kh['dien_thoai'] ?: 'Chưa cập nhật') ?></small>
                </td>
                <td><?= date('d/m/Y H:i', strtotime($kh['ngay_tao'])) ?></td>
                <td><strong><?= (int)$kh['tong_don'] ?></strong> đơn</td>
                <td class="text-price"><?= $cf->DinhDangGia($kh['tong_chi_tieu']) ?></td>
                <td>
                  <?php if ($hoat_dong) { ?>
                    <span class="adm-badge badge-success">Hoạt động</span>
                  <?php } else { ?>
                    <span class="adm-badge badge-danger">Đã khóa</span>
                  <?php } ?>
                </td>
                <td class="action-cell">
                  <a href="khachhang_chitiet.php?id=<?= $kh['id_nguoi_dung'] ?>"
                     class="adm-btn adm-btn-sm adm-btn-info">Chi tiết / Sửa</a>

                  <?php if ($hoat_dong) { ?>
                    <a href="xuly_khachhang.php?action=toggle_status&id=<?= $kh['id_nguoi_dung'] ?>&status=0"
                       class="adm-btn adm-btn-sm adm-btn-warning"
                       onclick="return confirm('Khóa tài khoản khách hàng <?= htmlspecialchars($kh['ho_ten']) ?>?');">Khóa</a>
                  <?php } else { ?>
                    <a href="xuly_khachhang.php?action=toggle_status&id=<?= $kh['id_nguoi_dung'] ?>&status=1"
                       class="adm-btn adm-btn-sm adm-btn-success"
                       onclick="return confirm('Mở khóa tài khoản khách hàng <?= htmlspecialchars($kh['ho_ten']) ?>?');">Mở khóa</a>
                  <?php } ?>

                  <a href="xuly_khachhang.php?action=delete&id=<?= $kh['id_nguoi_dung'] ?>"
                     class="adm-btn adm-btn-sm adm-btn-danger"
                     onclick="return confirm('Xóa vĩnh viễn tài khoản khách hàng #<?= $kh['id_nguoi_dung'] ?>? (Các đơn hàng cũ vẫn được lưu lại)');">Xóa</a>
                </td>
              </tr>
            <?php } } ?>
          </tbody>
        </table>
      </div>
    </section>
  </main>
</div>

</body>
</html>
