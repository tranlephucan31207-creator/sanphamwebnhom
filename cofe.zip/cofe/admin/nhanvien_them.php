<?php
// === FILE MỚI THÊM: TRANG THÊM NHÂN VIÊN / QUẢN TRỊ VIÊN MỚI ===
require_once "check_admin.php"; // Kiểm tra session & chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền thêm nhân viên.";
    header("Location: index.php");
    exit;
}

$loi = isset($_SESSION['admin_loi_nv']) ? $_SESSION['admin_loi_nv'] : "";
unset($_SESSION['admin_loi_nv']);

$du_lieu_cu = isset($_SESSION['admin_old_nv']) ? $_SESSION['admin_old_nv'] : [];
unset($_SESSION['admin_old_nv']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Thêm nhân viên mới - Coffee House Admin</title>
  <link rel="stylesheet" href="admin_style.css">
</head>
<body>

<div class="admin-layout">
  <!-- SIDEBAR -->
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag role-admin">Quản trị viên</span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
      <!-- MỚI THÊM: MENU QUẢN LÝ SẢN PHẨM -->
      <a href="sanpham.php">☕ Quản lý sản phẩm</a>
      <!-- HẾT PHẦN MỚI THÊM -->
      <a href="khachhang.php">👥 Quản lý khách hàng</a>
      <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <!-- NỘI DUNG CHÍNH -->
  <main class="admin-main">
    <header class="admin-topbar">
      <div>
        <h1>Thêm nhân viên mới</h1>
        <p><a href="nhanvien.php">← Quay lại danh sách nhân viên</a></p>
      </div>
    </header>

    <?php if ($loi !== "") { ?>
      <div class="adm-alert adm-alert-danger"><?= htmlspecialchars($loi) ?></div>
    <?php } ?>

    <section class="adm-card staff-form-wrapper">
      <h3>Thông tin tài khoản nhân sự</h3>

      <div class="role-guide-box">
        <strong>Phân quyền chức vụ trong hệ thống:</strong>
        <ul>
          <li><strong>Thu ngân (thu_ngan):</strong> Quản lý đơn hàng, cập nhật trạng thái pha chế, in hóa đơn và tạo đơn POS tại quầy.</li>
          <li><strong>Quản trị viên (admin):</strong> Toàn quyền như Thu ngân, cộng thêm quyền xóa đơn hàng, quản lý khách hàng và quản lý nhân viên.</li>
        </ul>
      </div>

      <form method="post" action="xuly_nhanvien.php?action=create">
        <div class="form-grid-2col">
          <div class="adm-form-group">
            <label for="ho_ten">Họ và tên nhân viên *</label>
            <input type="text" id="ho_ten" name="ho_ten"
                   value="<?= htmlspecialchars($du_lieu_cu['ho_ten'] ?? '') ?>"
                   placeholder="Ví dụ: Nguyễn Văn An" required>
          </div>

          <div class="adm-form-group">
            <label for="dien_thoai">Số điện thoại</label>
            <input type="text" id="dien_thoai" name="dien_thoai"
                   value="<?= htmlspecialchars($du_lieu_cu['dien_thoai'] ?? '') ?>"
                   placeholder="Ví dụ: 0909123456">
          </div>
        </div>

        <div class="form-grid-2col">
          <div class="adm-form-group">
            <label for="email">Email đăng nhập hệ thống *</label>
            <input type="email" id="email" name="email"
                   value="<?= htmlspecialchars($du_lieu_cu['email'] ?? '') ?>"
                   placeholder="nhanvien@coffeehouse.vn" required>
          </div>

          <div class="adm-form-group">
            <label for="mat_khau">Mật khẩu khởi tạo *</label>
            <input type="password" id="mat_khau" name="mat_khau"
                   placeholder="Tối thiểu 6 ký tự..." required>
          </div>
        </div>

        <div class="form-grid-2col">
          <div class="adm-form-group">
            <label for="vai_tro">Vai trò / Chức vụ *</label>
            <select id="vai_tro" name="vai_tro" class="adm-select-full">
              <option value="thu_ngan" <?= ($du_lieu_cu['vai_tro'] ?? '') === 'thu_ngan' ? 'selected' : '' ?>>🧾 Thu ngân (Nhân viên quầy)</option>
              <option value="admin" <?= ($du_lieu_cu['vai_tro'] ?? '') === 'admin' ? 'selected' : '' ?>>👑 Quản trị viên (Admin)</option>
            </select>
          </div>

          <div class="adm-form-group">
            <label for="trang_thai">Trạng thái tài khoản</label>
            <select id="trang_thai" name="trang_thai" class="adm-select-full">
              <option value="1" <?= ($du_lieu_cu['trang_thai'] ?? '1') === '1' ? 'selected' : '' ?>>🟢 Đang hoạt động (Cho phép đăng nhập)</option>
              <option value="0" <?= ($du_lieu_cu['trang_thai'] ?? '') === '0' ? 'selected' : '' ?>>🔴 Tạm khóa (Chưa kích hoạt)</option>
            </select>
          </div>
        </div>

        <div class="form-actions-row">
          <button type="submit" class="adm-btn adm-btn-primary">Tạo tài khoản nhân viên</button>
          <a href="nhanvien.php" class="adm-btn adm-btn-dark">Hủy bỏ</a>
        </div>
      </form>
    </section>
  </main>
</div>

</body>
</html>
