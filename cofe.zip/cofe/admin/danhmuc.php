<?php
// === FILE MỚI THÊM: TRANG QUẢN LÝ DANH MỤC SẢN PHẨM (KHU VỰC ADMIN) ===
require_once "check_admin.php"; // Kiểm tra session & chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

// Chặn Thu ngân hoặc người không có quyền Admin truy cập trái phép
if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền quản lý danh mục.";
    header("Location: dashboard.php");
    exit;
}

$tukhoa = isset($_GET['tukhoa']) ? trim($_GET['tukhoa']) : '';

// Nếu bấm nút "Sửa" trên bảng (?edit=id) thì lấy thông tin danh mục đó đổ lên form
$id_sua = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$dm_dang_sua = ($id_sua > 0) ? $cf->ChiTietDanhMuc($id_sua) : null;

$thong_ke = $cf->ThongKeDanhMucAdmin();
$ds_dm    = $cf->ListDanhMucAdmin($tukhoa);

$thong_bao = isset($_SESSION['admin_thongbao']) ? $_SESSION['admin_thongbao'] : "";
unset($_SESSION['admin_thongbao']);

$loi = isset($_SESSION['admin_loi_dm']) ? $_SESSION['admin_loi_dm'] : "";
unset($_SESSION['admin_loi_dm']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quản lý danh mục - Coffee House Admin</title>
  <link rel="stylesheet" href="admin_style.css">
</head>
<body>

<div class="admin-layout">
  <!-- SIDEBAR RIÊNG CỦA KHU VỰC QUẢN TRỊ -->
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag role-admin">Quản trị viên</span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
      <!-- MỚI THÊM: MENU QUẢN LÝ SẢN PHẨM -->
      <a href="sanpham.php">☕ Quản lý sản phẩm</a>
      <!-- HẾT PHẦN MỚI THÊM -->
      <a href="khachhang.php">👥 Quản lý khách hàng</a>
      <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <!-- NỘI DUNG CHÍNH -->
  <main class="admin-main">
    <header class="admin-topbar">
      <div>
        <h1>Quản lý danh mục sản phẩm</h1>
        <p>Thêm mới, chỉnh sửa tên nhóm đồ uống / bánh và kiểm soát số lượng món theo từng danh mục</p>
      </div>
    </header>

    <?php if ($thong_bao !== "") { ?>
      <div class="adm-alert adm-alert-success"><?= htmlspecialchars($thong_bao) ?></div>
    <?php } ?>

    <?php if ($loi !== "") { ?>
      <div class="adm-alert adm-alert-danger"><?= htmlspecialchars($loi) ?></div>
    <?php } ?>

    <!-- THẺ THỐNG KÊ KPI DANH MỤC -->
    <section class="kpi-grid">
      <div class="kpi-card">
        <span class="kpi-label">Tổng số danh mục</span>
        <strong class="kpi-value"><?= (int)$thong_ke['tong_danh_muc'] ?></strong>
      </div>
      <div class="kpi-card kpi-success">
        <span class="kpi-label">Danh mục đang có món</span>
        <strong class="kpi-value"><?= (int)$thong_ke['dm_co_mon'] ?></strong>
      </div>
      <div class="kpi-card kpi-warning">
        <span class="kpi-label">Danh mục trống (chưa có món)</span>
        <strong class="kpi-value"><?= (int)$thong_ke['dm_trong'] ?></strong>
      </div>
      <div class="kpi-card kpi-info">
        <span class="kpi-label">Tổng sản phẩm thuộc danh mục</span>
        <strong class="kpi-value"><?= (int)$thong_ke['tong_san_pham'] ?> món</strong>
      </div>
    </section>

    <!-- BỐ CỤC 2 CỘT: FORM THÊM / SỬA BÊN TRÁI + DANH SÁCH BÊN PHẢI -->
    <div class="category-admin-grid">
      <!-- CỘT TRÁI: BIỂU MẪU THÊM MỚI HOẶC CẬP NHẬT DANH MỤC -->
      <section class="adm-card">
        <?php if ($dm_dang_sua) { ?>
          <h3>✏️ Chỉnh sửa danh mục #<?= $dm_dang_sua['id_danh_muc'] ?></h3>
          <form method="post" action="xuly_danhmuc.php?action=update">
            <input type="hidden" name="id_danh_muc" value="<?= $dm_dang_sua['id_danh_muc'] ?>">

            <div class="adm-form-group">
              <label for="ten_danh_muc">Tên danh mục *</label>
              <input type="text" id="ten_danh_muc" name="ten_danh_muc" maxlength="50"
                     value="<?= htmlspecialchars($dm_dang_sua['ten_danh_muc']) ?>" required>
            </div>

            <div class="form-actions-row">
              <button type="submit" class="adm-btn adm-btn-primary">Lưu cập nhật</button>
              <a href="danhmuc.php" class="adm-btn adm-btn-dark">Hủy sửa</a>
            </div>
          </form>
        <?php } else { ?>
          <h3>➕ Thêm danh mục mới</h3>
          <form method="post" action="xuly_danhmuc.php?action=create">
            <div class="adm-form-group">
              <label for="ten_danh_muc">Tên danh mục *</label>
              <input type="text" id="ten_danh_muc" name="ten_danh_muc" maxlength="50"
                     placeholder="Ví dụ: Trà sữa, Đá xay, Cà phê máy..." required>
            </div>

            <button type="submit" class="adm-btn adm-btn-primary adm-btn-block">Thêm danh mục</button>
          </form>
        <?php } ?>

        <div class="cat-note-box">
          <strong>Lưu ý quản trị:</strong>
          <ul>
            <li>Tên danh mục tối đa 50 ký tự và không được trùng với danh mục đã có.</li>
            <li>Chỉ có thể xóa danh mục khi danh mục đó chưa có sản phẩm nào (số món = 0).</li>
          </ul>
        </div>
      </section>

      <!-- CỘT PHẢI: TÌM KIẾM & BẢNG DANH SÁCH DANH MỤC -->
      <section class="adm-card">
        <div class="dash-card-head">
          <h3>Danh sách danh mục hiện có</h3>
          <form method="get" action="danhmuc.php" class="adm-search-form">
            <input type="text" name="tukhoa" placeholder="Tìm mã (#1) hoặc tên danh mục..."
                   value="<?= htmlspecialchars($tukhoa) ?>">
            <button type="submit" class="adm-btn adm-btn-dark">Tìm</button>
            <?php if ($tukhoa !== '') { ?>
              <a href="danhmuc.php" class="adm-btn adm-btn-info">Tất cả</a>
            <?php } ?>
          </form>
        </div>

        <div class="table-responsive">
          <table class="adm-table">
            <thead>
              <tr>
                <th>Mã DM</th>
                <th>Tên danh mục</th>
                <th>Số lượng món</th>
                <th>Xem trên web</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($ds_dm->num_rows == 0) { ?>
                <tr>
                  <td colspan="5" class="text-center">Không tìm thấy danh mục nào phù hợp.</td>
                </tr>
              <?php } else {
                while ($dm = $ds_dm->fetch_assoc()) {
                  $so_sp = (int)$dm['so_sp'];
              ?>
                <tr class="<?= ($id_sua === (int)$dm['id_danh_muc']) ? 'row-editing' : '' ?>">
                  <td><strong>#<?= $dm['id_danh_muc'] ?></strong></td>
                  <td><strong><?= htmlspecialchars($dm['ten_danh_muc']) ?></strong></td>
                  <td>
                    <?php if ($so_sp > 0) { ?>
                      <span class="adm-badge badge-info"><?= $so_sp ?> sản phẩm</span>
                    <?php } else { ?>
                      <span class="adm-badge badge-secondary">0 sản phẩm</span>
                    <?php } ?>
                  </td>
                  <td>
                    <a href="../sanphamtheoloai.php?dm=<?= $dm['id_danh_muc'] ?>" target="_blank">
                      Mở trang loại ↗
                    </a>
                  </td>
                  <td class="action-cell">
                    <a href="danhmuc.php?edit=<?= $dm['id_danh_muc'] ?>"
                       class="adm-btn adm-btn-sm adm-btn-info">Sửa</a>

                    <?php if ($so_sp === 0) { ?>
                      <a href="xuly_danhmuc.php?action=delete&id=<?= $dm['id_danh_muc'] ?>"
                         class="adm-btn adm-btn-sm adm-btn-danger"
                         onclick="return confirm('Xóa vĩnh viễn danh mục #<?= $dm['id_danh_muc'] ?> (<?= htmlspecialchars($dm['ten_danh_muc']) ?>)?');">Xóa</a>
                    <?php } else { ?>
                      <span class="adm-btn adm-btn-sm adm-btn-disabled"
                            title="Không thể xóa vì danh mục đang chứa <?= $so_sp ?> sản phẩm">Đang có món</span>
                    <?php } ?>
                  </td>
                </tr>
              <?php } } ?>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  </main>
</div>

</body>
</html>