<?php
// === FILE MỚI THÊM: TRANG DANH SÁCH QUẢN LÝ NHÂN VIÊN ADMIN ===
require_once "check_admin.php"; // Kiểm tra session & chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

// Chỉ Quản trị viên (Admin) mới được phép vào trang quản lý nhân viên
if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền quản lý nhân viên.";
    header("Location: index.php");
    exit;
}

$vai_tro    = isset($_GET['vai_tro']) ? trim($_GET['vai_tro']) : '';
$trang_thai = isset($_GET['trang_thai']) ? trim($_GET['trang_thai']) : '';
$tukhoa     = isset($_GET['tukhoa']) ? trim($_GET['tukhoa']) : '';

$thong_ke = $cf->ThongKeNhanVien();
$ds_nv    = $cf->ListNhanVien($vai_tro, $trang_thai, $tukhoa);

$thong_bao = isset($_SESSION['admin_thongbao']) ? $_SESSION['admin_thongbao'] : "";
unset($_SESSION['admin_thongbao']);

$loi = isset($_SESSION['admin_loi_nv']) ? $_SESSION['admin_loi_nv'] : "";
unset($_SESSION['admin_loi_nv']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quản lý nhân viên - Coffee House Admin</title>
  <link rel="stylesheet" href="admin_style.css">
</head>
<body>

<div class="admin-layout">
  <!-- SIDEBAR RIÊNG CỦA KHU VỰC QUẢN TRỊ -->
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag role-admin">Quản trị viên</span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
      <!-- MỚI THÊM: MENU QUẢN LÝ SẢN PHẨM -->
      <a href="sanpham.php">☕ Quản lý sản phẩm</a>
      <!-- HẾT PHẦN MỚI THÊM -->
      <a href="khachhang.php">👥 Quản lý khách hàng</a>
      <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <!-- NỘI DUNG CHÍNH -->
  <main class="admin-main">
    <header class="admin-topbar">
      <div>
        <h1>Quản lý nhân viên</h1>
        <p>Thêm tài khoản nội bộ, phân quyền Quản trị viên / Thu ngân và kiểm soát trạng thái làm việc</p>
      </div>
      <a href="nhanvien_them.php" class="adm-btn adm-btn-primary">+ Thêm nhân viên mới</a>
    </header>

    <?php if ($thong_bao !== "") { ?>
      <div class="adm-alert adm-alert-success"><?= htmlspecialchars($thong_bao) ?></div>
    <?php } ?>

    <?php if ($loi !== "") { ?>
      <div class="adm-alert adm-alert-danger"><?= htmlspecialchars($loi) ?></div>
    <?php } ?>

    <!-- THẺ THỐNG KÊ KPI NHÂN VIÊN -->
    <section class="kpi-grid">
      <div class="kpi-card">
        <span class="kpi-label">Tổng nhân sự nội bộ</span>
        <strong class="kpi-value"><?= (int)$thong_ke['tong_nv'] ?></strong>
      </div>
      <div class="kpi-card kpi-warning">
        <span class="kpi-label">Quản trị viên (Admin)</span>
        <strong class="kpi-value"><?= (int)$thong_ke['so_admin'] ?></strong>
      </div>
      <div class="kpi-card kpi-info">
        <span class="kpi-label">Nhân viên Thu ngân</span>
        <strong class="kpi-value"><?= (int)$thong_ke['so_thu_ngan'] ?></strong>
      </div>
      <div class="kpi-card kpi-success">
        <span class="kpi-label">Đang hoạt động / Bị khóa</span>
        <strong class="kpi-value"><?= (int)$thong_ke['dang_hoat_dong'] ?> / <?= (int)$thong_ke['bi_khoa'] ?></strong>
      </div>
    </section>

    <!-- THANH LỌC VAI TRÒ, TRẠNG THÁI & TÌM KIẾM -->
    <section class="filter-bar">
      <div class="status-tabs">
        <a href="nhanvien.php" class="<?= ($vai_tro === '' && $trang_thai === '') ? 'active' : '' ?>">Tất cả</a>
        <a href="nhanvien.php?vai_tro=admin" class="<?= $vai_tro === 'admin' ? 'active' : '' ?>">Quản trị viên</a>
        <a href="nhanvien.php?vai_tro=thu_ngan" class="<?= $vai_tro === 'thu_ngan' ? 'active' : '' ?>">Thu ngân</a>
        <a href="nhanvien.php?trang_thai=1" class="<?= $trang_thai === '1' ? 'active' : '' ?>">Đang làm việc</a>
        <a href="nhanvien.php?trang_thai=0" class="<?= $trang_thai === '0' ? 'active' : '' ?>">Đã khóa</a>
      </div>

      <form method="get" action="nhanvien.php" class="adm-search-form">
        <?php if ($vai_tro !== '') { ?>
          <input type="hidden" name="vai_tro" value="<?= htmlspecialchars($vai_tro) ?>">
        <?php } ?>
        <?php if ($trang_thai !== '') { ?>
          <input type="hidden" name="trang_thai" value="<?= htmlspecialchars($trang_thai) ?>">
        <?php } ?>
        <input type="text" name="tukhoa" placeholder="Tìm mã NV (#1), họ tên, email, SĐT..."
               value="<?= htmlspecialchars($tukhoa) ?>">
        <button type="submit" class="adm-btn adm-btn-dark">Tìm</button>
      </form>
    </section>

    <!-- BẢNG DANH SÁCH NHÂN VIÊN -->
    <section class="adm-card">
      <div class="table-responsive">
        <table class="adm-table">
          <thead>
            <tr>
              <th>Mã NV</th>
              <th>Họ tên nhân viên</th>
              <th>Thông tin liên hệ</th>
              <th>Vai trò / Quyền hạn</th>
              <th>Ngày tạo</th>
              <th>Trạng thái</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($ds_nv->num_rows == 0) { ?>
              <tr>
                <td colspan="7" class="text-center">Chưa có nhân viên nào phù hợp.</td>
              </tr>
            <?php } else {
              while ($nv = $ds_nv->fetch_assoc()) {
                $hoat_dong   = ((int)$nv['trang_thai'] === 1);
                $la_ban_than = ((int)$nv['id_nguoi_dung'] === (int)$admin_hien_tai['id_nguoi_dung']);
            ?>
              <tr>
                <td><strong>#<?= $nv['id_nguoi_dung'] ?></strong></td>
                <td>
                  <strong><?= htmlspecialchars($nv['ho_ten']) ?></strong>
                  <?php if ($la_ban_than) { ?>
                    <span class="self-tag">Bạn</span>
                  <?php } ?>
                </td>
                <td>
                  ✉️ <?= htmlspecialchars($nv['email']) ?><br>
                  <small class="text-muted">📞 <?= htmlspecialchars($nv['dien_thoai'] ?: 'Chưa cập nhật') ?></small>
                </td>
                <td>
                  <?php if ($nv['vai_tro'] === 'admin') { ?>
                    <span class="adm-badge badge-role-admin">👑 Quản trị viên</span>
                  <?php } else { ?>
                    <span class="adm-badge badge-role-cashier">🧾 Thu ngân</span>
                  <?php } ?>
                </td>
                <td><?= date('d/m/Y H:i', strtotime($nv['ngay_tao'])) ?></td>
                <td>
                  <?php if ($hoat_dong) { ?>
                    <span class="adm-badge badge-success">Hoạt động</span>
                  <?php } else { ?>
                    <span class="adm-badge badge-danger">Đã khóa</span>
                  <?php } ?>
                </td>
                <td class="action-cell">
                  <a href="nhanvien_chitiet.php?id=<?= $nv['id_nguoi_dung'] ?>"
                     class="adm-btn adm-btn-sm adm-btn-info">Sửa / Phân quyền</a>

                  <?php if (!$la_ban_than) { ?>
                    <?php if ($hoat_dong) { ?>
                      <a href="xuly_nhanvien.php?action=toggle_status&id=<?= $nv['id_nguoi_dung'] ?>&status=0"
                         class="adm-btn adm-btn-sm adm-btn-warning"
                         onclick="return confirm('Khóa tài khoản nhân viên <?= htmlspecialchars($nv['ho_ten']) ?>?');">Khóa</a>
                    <?php } else { ?>
                      <a href="xuly_nhanvien.php?action=toggle_status&id=<?= $nv['id_nguoi_dung'] ?>&status=1"
                         class="adm-btn adm-btn-sm adm-btn-success"
                         onclick="return confirm('Mở khóa tài khoản nhân viên <?= htmlspecialchars($nv['ho_ten']) ?>?');">Mở khóa</a>
                    <?php } ?>

                    <a href="xuly_nhanvien.php?action=delete&id=<?= $nv['id_nguoi_dung'] ?>"
                       class="adm-btn adm-btn-sm adm-btn-danger"
                       onclick="return confirm('Xóa vĩnh viễn tài khoản nhân viên #<?= $nv['id_nguoi_dung'] ?> (<?= htmlspecialchars($nv['ho_ten']) ?>)?');">Xóa</a>
                  <?php } ?>
                </td>
              </tr>
            <?php } } ?>
          </tbody>
        </table>
      </div>
    </section>
  </main>
</div>

</body>
</html>
