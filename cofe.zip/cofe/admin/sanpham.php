<?php
// === FILE MỚI THÊM: TRANG DANH SÁCH QUẢN LÝ SẢN PHẨM (KHU VỰC ADMIN) ===
require_once "check_admin.php"; // Kiểm tra session & chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

// Chặn Thu ngân hoặc người không có quyền Admin truy cập trái phép
if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền quản lý sản phẩm.";
    header("Location: dashboard.php");
    exit;
}

$id_dm   = isset($_GET['dm']) ? (int)$_GET['dm'] : 0;
$noi_bat = isset($_GET['noi_bat']) ? trim($_GET['noi_bat']) : '';
$tukhoa  = isset($_GET['tukhoa']) ? trim($_GET['tukhoa']) : '';

$thong_ke = $cf->ThongKeSanPhamAdmin();
$ds_dm    = $cf->ListDanhMuc();
$ds_sp    = $cf->ListSanPhamAdmin($id_dm, $noi_bat, $tukhoa);

$thong_bao = isset($_SESSION['admin_thongbao']) ? $_SESSION['admin_thongbao'] : "";
unset($_SESSION['admin_thongbao']);

$loi = isset($_SESSION['admin_loi_sp']) ? $_SESSION['admin_loi_sp'] : "";
unset($_SESSION['admin_loi_sp']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quản lý sản phẩm - Coffee House Admin</title>
  <link rel="stylesheet" href="admin_style.css?v=2">
</head>
<body>

<div class="admin-layout">
  <!-- SIDEBAR RIÊNG CỦA KHU VỰC QUẢN TRỊ -->
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag role-admin">Quản trị viên</span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
      <a href="sanpham.php" class="active">☕ Quản lý sản phẩm</a>
      <a href="khachhang.php">👥 Quản lý khách hàng</a>
      <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <!-- NỘI DUNG CHÍNH -->
  <main class="admin-main">
    <header class="admin-topbar">
      <div>
        <h1>Quản lý sản phẩm</h1>
        <p>Thêm món mới, cập nhật giá bán, hình ảnh, mô tả và thiết lập sản phẩm nổi bật trang chủ</p>
      </div>
      <a href="sanpham_them.php" class="adm-btn adm-btn-primary">+ Thêm sản phẩm mới</a>
    </header>

    <?php if ($thong_bao !== "") { ?>
      <div class="adm-alert adm-alert-success"><?= htmlspecialchars($thong_bao) ?></div>
    <?php } ?>

    <?php if ($loi !== "") { ?>
      <div class="adm-alert adm-alert-danger"><?= htmlspecialchars($loi) ?></div>
    <?php } ?>

    <!-- THẺ THỐNG KÊ KPI SẢN PHẨM -->
    <section class="kpi-grid">
      <div class="kpi-card">
        <span class="kpi-label">Tổng số món trong thực đơn</span>
        <strong class="kpi-value"><?= (int)$thong_ke['tong_sp'] ?> món</strong>
      </div>
      <div class="kpi-card kpi-warning">
        <span class="kpi-label">Sản phẩm nổi bật (Trang chủ)</span>
        <strong class="kpi-value"><?= (int)$thong_ke['sp_noi_bat'] ?> món</strong>
      </div>
      <div class="kpi-card kpi-info">
        <span class="kpi-label">Giá bán trung bình</span>
        <strong class="kpi-value"><?= $cf->DinhDangGia($thong_ke['gia_trung_binh']) ?></strong>
      </div>
      <div class="kpi-card kpi-success">
        <span class="kpi-label">Khoảng giá thực đơn</span>
        <strong class="kpi-value" style="font-size: 18px;">
          <?= $cf->DinhDangGia($thong_ke['gia_thap_nhat']) ?> - <?= $cf->DinhDangGia($thong_ke['gia_cao_nhat']) ?>
        </strong>
      </div>
    </section>

    <!-- THANH LỌC DANH MỤC, TRẠNG THÁI NỔI BẬT & TÌM KIẾM -->
    <section class="filter-bar">
      <div class="status-tabs">
        <a href="sanpham.php" class="<?= ($id_dm === 0 && $noi_bat === '') ? 'active' : '' ?>">Tất cả món</a>
        <a href="sanpham.php?noi_bat=1" class="<?= $noi_bat === '1' ? 'active' : '' ?>">⭐ Nổi bật</a>
        <?php while ($dm = $ds_dm->fetch_assoc()) { ?>
          <a href="sanpham.php?dm=<?= $dm['id_danh_muc'] ?>"
             class="<?= $id_dm === (int)$dm['id_danh_muc'] ? 'active' : '' ?>">
            <?= htmlspecialchars($dm['ten_danh_muc']) ?>
          </a>
        <?php } ?>
      </div>

      <form method="get" action="sanpham.php" class="adm-search-form">
        <?php if ($id_dm > 0) { ?>
          <input type="hidden" name="dm" value="<?= $id_dm ?>">
        <?php } ?>
        <?php if ($noi_bat !== '') { ?>
          <input type="hidden" name="noi_bat" value="<?= htmlspecialchars($noi_bat) ?>">
        <?php } ?>
        <input type="text" name="tukhoa" placeholder="Tìm mã SP (#1), tên món..."
               value="<?= htmlspecialchars($tukhoa) ?>">
        <button type="submit" class="adm-btn adm-btn-dark">Tìm</button>
      </form>
    </section>

    <!-- BẢNG DANH SÁCH SẢN PHẨM -->
    <section class="adm-card">
      <div class="table-responsive">
        <table class="adm-table">
          <thead>
            <tr>
              <th>Mã SP</th>
              <th>Hình ảnh</th>
              <th>Tên sản phẩm</th>
              <th>Danh mục</th>
              <th>Giá bán</th>
              <th>Nổi bật</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($ds_sp->num_rows == 0) { ?>
              <tr>
                <td colspan="7" class="text-center">Không tìm thấy sản phẩm nào phù hợp.</td>
              </tr>
            <?php } else {
              while ($sp = $ds_sp->fetch_assoc()) {
                $la_noi_bat = ((int)$sp['noi_bat'] === 1);
                $duong_dan_anh = !empty($sp['hinh_anh']) ? "../" . $sp['hinh_anh'] : "../img/caphe.jpg";
            ?>
              <tr>
                <td><strong>#<?= $sp['id_san_pham'] ?></strong></td>
                <td>
                  <img src="<?= htmlspecialchars($duong_dan_anh) ?>"
                       alt="<?= htmlspecialchars($sp['ten_san_pham']) ?>"
                       class="admin-prod-thumb">
                </td>
                <td>
                  <strong><?= htmlspecialchars($sp['ten_san_pham']) ?></strong>
                  <?php if (!empty($sp['mo_ta'])) { ?>
                    <br><small class="text-muted"><?= htmlspecialchars(mb_strimwidth($sp['mo_ta'], 0, 65, "...")) ?></small>
                  <?php } ?>
                </td>
                <td>
                  <span class="adm-badge badge-secondary">
                    <?= htmlspecialchars($sp['ten_danh_muc'] ?: 'Chưa phân loại') ?>
                  </span>
                </td>
                <td class="text-price"><?= $cf->DinhDangGia($sp['gia']) ?></td>
                <td>
                  <?php if ($la_noi_bat) { ?>
                    <a href="xuly_sanpham.php?action=toggle_featured&id=<?= $sp['id_san_pham'] ?>&status=0"
                       class="adm-badge badge-warning" title="Bấm để tắt nổi bật">⭐ Nổi bật</a>
                  <?php } else { ?>
                    <a href="xuly_sanpham.php?action=toggle_featured&id=<?= $sp['id_san_pham'] ?>&status=1"
                       class="adm-badge badge-secondary" title="Bấm để bật nổi bật">Món thường</a>
                  <?php } ?>
                </td>
                <td class="action-cell">
                  <a href="../chitiet.php?id=<?= $sp['id_san_pham'] ?>" target="_blank"
                     class="adm-btn adm-btn-sm adm-btn-dark" title="Xem trên trang khách">Xem</a>
                  <a href="sanpham_sua.php?id=<?= $sp['id_san_pham'] ?>"
                     class="adm-btn adm-btn-sm adm-btn-info">Sửa</a>
                  <a href="xuly_sanpham.php?action=delete&id=<?= $sp['id_san_pham'] ?>"
                     class="adm-btn adm-btn-sm adm-btn-danger"
                     onclick="return confirm('Xóa vĩnh viễn sản phẩm #<?= $sp['id_san_pham'] ?> (<?= htmlspecialchars($sp['ten_san_pham']) ?>)?');">Xóa</a>
                </td>
              </tr>
            <?php } } ?>
          </tbody>
        </table>
      </div>
    </section>
  </main>
</div>

</body>
</html>