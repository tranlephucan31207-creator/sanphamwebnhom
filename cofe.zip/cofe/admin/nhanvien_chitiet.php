<?php
// === FILE MỚI THÊM: TRANG SỬA THÔNG TIN & PHÂN QUYỀN NHÂN VIÊN ADMIN ===
require_once "check_admin.php"; // Kiểm tra session & chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền chỉnh sửa nhân viên.";
    header("Location: index.php");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$nv = $cf->ChiTietNhanVien($id);

if (!$nv) {
    $_SESSION['admin_thongbao'] = "Không tìm thấy nhân viên #" . $id;
    header("Location: nhanvien.php");
    exit;
}

$la_ban_than = ((int)$nv['id_nguoi_dung'] === (int)$admin_hien_tai['id_nguoi_dung']);

$thong_bao = isset($_SESSION['admin_thongbao']) ? $_SESSION['admin_thongbao'] : "";
unset($_SESSION['admin_thongbao']);

$loi = isset($_SESSION['admin_loi_nv']) ? $_SESSION['admin_loi_nv'] : "";
unset($_SESSION['admin_loi_nv']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hồ sơ nhân viên #<?= $nv['id_nguoi_dung'] ?> - Coffee House Admin</title>
  <link rel="stylesheet" href="admin_style.css">
</head>
<body>

<div class="admin-layout">
  <!-- SIDEBAR -->
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag role-admin">Quản trị viên</span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
      <!-- MỚI THÊM: MENU QUẢN LÝ SẢN PHẨM -->
      <a href="sanpham.php">☕ Quản lý sản phẩm</a>
      <!-- HẾT PHẦN MỚI THÊM -->
      <a href="khachhang.php">👥 Quản lý khách hàng</a>
      <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <!-- NỘI DUNG CHÍNH -->
  <main class="admin-main">
    <header class="admin-topbar">
      <div>
        <h1>
          Hồ sơ nhân viên #<?= $nv['id_nguoi_dung'] ?>
          <?php if ($la_ban_than) { ?><span class="self-tag">Tài khoản của bạn</span><?php } ?>
        </h1>
        <p><a href="nhanvien.php">← Quay lại danh sách nhân viên</a></p>
      </div>
    </header>

    <?php if ($thong_bao !== "") { ?>
      <div class="adm-alert adm-alert-success"><?= htmlspecialchars($thong_bao) ?></div>
    <?php } ?>

    <?php if ($loi !== "") { ?>
      <div class="adm-alert adm-alert-danger"><?= htmlspecialchars($loi) ?></div>
    <?php } ?>

    <section class="adm-card staff-form-wrapper">
      <h3>Cập nhật thông tin & phân quyền nhân viên</h3>
      <p class="text-muted" style="margin-top: -8px; margin-bottom: 18px;">
        Ngày tạo tài khoản: <strong><?= date('d/m/Y H:i', strtotime($nv['ngay_tao'])) ?></strong>
      </p>

      <form method="post" action="xuly_nhanvien.php?action=update">
        <input type="hidden" name="id_nguoi_dung" value="<?= $nv['id_nguoi_dung'] ?>">

        <div class="form-grid-2col">
          <div class="adm-form-group">
            <label for="ho_ten">Họ và tên nhân viên *</label>
            <input type="text" id="ho_ten" name="ho_ten"
                   value="<?= htmlspecialchars($nv['ho_ten']) ?>" required>
          </div>

          <div class="adm-form-group">
            <label for="dien_thoai">Số điện thoại</label>
            <input type="text" id="dien_thoai" name="dien_thoai"
                   value="<?= htmlspecialchars($nv['dien_thoai']) ?>" placeholder="Nhập số điện thoại...">
          </div>
        </div>

        <div class="form-grid-2col">
          <div class="adm-form-group">
            <label for="email">Email đăng nhập *</label>
            <input type="email" id="email" name="email"
                   value="<?= htmlspecialchars($nv['email']) ?>" required>
          </div>

          <div class="adm-form-group">
            <label for="mat_khau_moi">Đặt lại mật khẩu mới (để trống nếu giữ nguyên)</label>
            <input type="password" id="mat_khau_moi" name="mat_khau_moi"
                   placeholder="Nhập mật khẩu mới (tối thiểu 6 ký tự)...">
          </div>
        </div>

        <div class="form-grid-2col">
          <div class="adm-form-group">
            <label for="vai_tro">Vai trò / Quyền hạn</label>
            <select id="vai_tro" name="vai_tro" class="adm-select-full">
              <option value="admin" <?= $nv['vai_tro'] === 'admin' ? 'selected' : '' ?>>👑 Quản trị viên (Admin)</option>
              <option value="thu_ngan" <?= $nv['vai_tro'] === 'thu_ngan' ? 'selected' : '' ?>>🧾 Thu ngân (Nhân viên quầy)</option>
            </select>
          </div>

          <div class="adm-form-group">
            <label for="trang_thai">Trạng thái làm việc</label>
            <select id="trang_thai" name="trang_thai" class="adm-select-full">
              <option value="1" <?= (int)$nv['trang_thai'] === 1 ? 'selected' : '' ?>>🟢 Đang hoạt động (Cho phép đăng nhập)</option>
              <option value="0" <?= (int)$nv['trang_thai'] === 0 ? 'selected' : '' ?>>🔴 Khóa tài khoản (Ngừng truy cập)</option>
            </select>
          </div>
        </div>

        <div class="form-actions-row">
          <button type="submit" class="adm-btn adm-btn-primary">Lưu thay đổi</button>
          <a href="nhanvien.php" class="adm-btn adm-btn-dark">Quay lại</a>
        </div>
      </form>
    </section>
  </main>
</div>

</body>
</html>
