<?php
require_once "check_admin.php"; // Chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

$ds_sp = $cf->ListTatCaSanPham();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tạo đơn tại quầy - Coffee House POS</title>
  <link rel="stylesheet" href="admin_style.css">
</head>
<body>

<div class="admin-layout">
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag <?= $la_admin ? 'role-admin' : 'role-cashier' ?>">
          <?= $la_admin ? 'Quản trị viên' : 'Thu ngân' ?>
        </span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <?php if ($la_admin) { ?>
        <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
        <!-- MỚI THÊM: MENU QUẢN LÝ SẢN PHẨM -->
        <a href="sanpham.php">☕ Quản lý sản phẩm</a>
        <!-- HẾT PHẦN MỚI THÊM -->
        <a href="khachhang.php">👥 Quản lý khách hàng</a>
        <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <?php } ?>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <main class="admin-main">
    <header class="admin-topbar">
      <div>
        <h1>Tạo đơn hàng tại quầy (POS)</h1>
        <p>Chọn nhanh số lượng món và tạo hóa đơn cho khách uống tại quán / mang đi</p>
      </div>
      <a href="index.php" class="adm-btn adm-btn-dark">← Danh sách đơn</a>
    </header>

    <form method="post" action="xuly_donhang.php?action=create_pos">
      <div class="detail-grid">
        <!-- DANH SÁCH MÓN CHỌN SỐ LƯỢNG -->
        <section class="adm-card">
          <h3>Chọn món từ thực đơn</h3>
          <table class="adm-table">
            <thead>
              <tr>
                <th>Tên món</th>
                <th>Danh mục</th>
                <th>Đơn giá</th>
                <th>Số lượng đặt</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($sp = $ds_sp->fetch_assoc()) { ?>
              <tr>
                <td><strong><?= htmlspecialchars($sp['ten_san_pham']) ?></strong></td>
                <td><small class="text-muted"><?= htmlspecialchars($sp['ten_danh_muc'] ?? '') ?></small></td>
                <td class="text-price"><?= $cf->DinhDangGia($sp['gia']) ?></td>
                <td>
                  <input type="number" name="soluong[<?= $sp['id_san_pham'] ?>]"
                         value="0" min="0" max="50" class="pos-qty-input">
                </td>
              </tr>
              <?php } ?>
            </tbody>
          </table>
        </section>

        <!-- THÔNG TIN KHÁCH / BÀN -->
        <section class="adm-card">
          <h3>Thông tin hóa đơn</h3>
          <div class="adm-form-group">
            <label for="ten_khach_hang">Tên khách / Thẻ rung *</label>
            <input type="text" id="ten_khach_hang" name="ten_khach_hang"
                   value="Khách lẻ tại quầy" required>
          </div>

          <div class="adm-form-group">
            <label for="so_dien_thoai">Số điện thoại</label>
            <input type="text" id="so_dien_thoai" name="so_dien_thoai"
                   value="Tại quầy" required>
          </div>

          <div class="adm-form-group">
            <label for="dia_chi">Vị trí bàn / Mang đi *</label>
            <input type="text" id="dia_chi" name="dia_chi"
                   placeholder="Ví dụ: Bàn 03 hoặc Mang đi" value="Dùng tại quán" required>
          </div>

          <div class="adm-form-group">
            <label for="ghi_chu">Ghi chú pha chế</label>
            <input type="text" id="ghi_chu" name="ghi_chu" placeholder="Ít đường, nhiều sữa...">
          </div>

          <div class="adm-form-group">
            <label for="trang_thai">Trạng thái khởi tạo</label>
            <select id="trang_thai" name="trang_thai" class="adm-select-full">
              <option value="dang_pha_che">Đang pha chế (Đã thu tiền tại quầy)</option>
              <option value="hoan_thanh">Hoàn thành ngay</option>
              <option value="cho_xac_nhan">Chờ xác nhận</option>
            </select>
          </div>

          <button type="submit" class="adm-btn adm-btn-primary adm-btn-block">Tạo đơn & Xuất bill</button>
        </section>
      </div>
    </form>
  </main>
</div>

</body>
</html>
