<?php
require_once "check_admin.php"; // Chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền quản lý khách hàng.";
    header("Location: index.php");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$kh = $cf->ChiTietKhachHang($id);

if (!$kh) {
    $_SESSION['admin_thongbao'] = "Không tìm thấy khách hàng #" . $id;
    header("Location: khachhang.php");
    exit;
}

$ds_don = $cf->ListDonHangCuaKhach($id);

$thong_bao = isset($_SESSION['admin_thongbao']) ? $_SESSION['admin_thongbao'] : "";
unset($_SESSION['admin_thongbao']);

$loi = isset($_SESSION['admin_loi_kh']) ? $_SESSION['admin_loi_kh'] : "";
unset($_SESSION['admin_loi_kh']);

function nhanTrangThaiDon($tt) {
    switch ($tt) {
        case 'cho_xac_nhan': return ['Chờ xác nhận', 'badge-warning'];
        case 'dang_pha_che': return ['Đang pha chế', 'badge-info'];
        case 'hoan_thanh':   return ['Hoàn thành',   'badge-success'];
        case 'da_huy':       return ['Đã hủy',       'badge-danger'];
        default:             return [$tt,            'badge-secondary'];
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hồ sơ khách hàng #<?= $kh['id_nguoi_dung'] ?> - Coffee House Admin</title>
  <link rel="stylesheet" href="admin_style.css">
</head>
<body>

<div class="admin-layout">
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag role-admin">Quản trị viên</span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
      <!-- MỚI THÊM: MENU QUẢN LÝ SẢN PHẨM -->
      <a href="sanpham.php">☕ Quản lý sản phẩm</a>
      <!-- HẾT PHẦN MỚI THÊM -->
      <a href="khachhang.php">👥 Quản lý khách hàng</a>
      <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <main class="admin-main">
    <header class="admin-topbar">
      <div>
        <h1>Hồ sơ khách hàng #<?= $kh['id_nguoi_dung'] ?></h1>
        <p><a href="khachhang.php">← Quay lại danh sách khách hàng</a></p>
      </div>
    </header>

    <?php if ($thong_bao !== "") { ?>
      <div class="adm-alert adm-alert-success"><?= htmlspecialchars($thong_bao) ?></div>
    <?php } ?>

    <?php if ($loi !== "") { ?>
      <div class="adm-alert adm-alert-danger"><?= htmlspecialchars($loi) ?></div>
    <?php } ?>

    <section class="kpi-grid">
      <div class="kpi-card">
        <span class="kpi-label">Ngày tham gia</span>
        <strong class="kpi-value" style="font-size: 18px;"><?= date('d/m/Y', strtotime($kh['ngay_tao'])) ?></strong>
      </div>
      <div class="kpi-card kpi-info">
        <span class="kpi-label">Tổng số đơn đã đặt</span>
        <strong class="kpi-value"><?= (int)$kh['tong_don'] ?> đơn</strong>
      </div>
      <div class="kpi-card kpi-warning">
        <span class="kpi-label">Đơn hoàn thành</span>
        <strong class="kpi-value"><?= (int)$kh['don_hoan_thanh'] ?> đơn</strong>
      </div>
      <div class="kpi-card kpi-success">
        <span class="kpi-label">Tổng chi tiêu tích lũy</span>
        <strong class="kpi-value"><?= $cf->DinhDangGia($kh['tong_chi_tieu']) ?></strong>
      </div>
    </section>

    <div class="customer-detail-grid">
      <section class="adm-card">
        <h3>Cập nhật thông tin tài khoản</h3>
        <form method="post" action="xuly_khachhang.php?action=update">
          <input type="hidden" name="id_nguoi_dung" value="<?= $kh['id_nguoi_dung'] ?>">

          <div class="adm-form-group">
            <label for="ho_ten">Họ và tên *</label>
            <input type="text" id="ho_ten" name="ho_ten"
                   value="<?= htmlspecialchars($kh['ho_ten']) ?>" required>
          </div>

          <div class="adm-form-group">
            <label for="email">Địa chỉ Email *</label>
            <input type="email" id="email" name="email"
                   value="<?= htmlspecialchars($kh['email']) ?>" required>
          </div>

          <div class="adm-form-group">
            <label for="dien_thoai">Số điện thoại</label>
            <input type="text" id="dien_thoai" name="dien_thoai"
                   value="<?= htmlspecialchars($kh['dien_thoai']) ?>" placeholder="Nhập số điện thoại...">
          </div>

          <div class="adm-form-group">
            <label for="trang_thai">Trạng thái tài khoản</label>
            <select id="trang_thai" name="trang_thai" class="adm-select-full">
              <option value="1" <?= (int)$kh['trang_thai'] === 1 ? 'selected' : '' ?>>🟢 Đang hoạt động (Cho phép đăng nhập)</option>
              <option value="0" <?= (int)$kh['trang_thai'] === 0 ? 'selected' : '' ?>>🔴 Khóa tài khoản (Chặn đăng nhập)</option>
            </select>
          </div>

          <div class="adm-form-group">
            <label for="mat_khau_moi">Đặt lại mật khẩu mới (để trống nếu không đổi)</label>
            <input type="password" id="mat_khau_moi" name="mat_khau_moi"
                   placeholder="Nhập mật khẩu mới (tối thiểu 6 ký tự)...">
          </div>

          <button type="submit" class="adm-btn adm-btn-primary adm-btn-block">Lưu thay đổi</button>
        </form>
      </section>

      <section class="adm-card">
        <h3>Lịch sử đơn hàng của khách</h3>
        <div class="table-responsive">
          <table class="adm-table">
            <thead>
              <tr>
                <th>Mã đơn</th>
                <th>Ngày đặt</th>
                <th>Địa chỉ nhận</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Xem</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($ds_don->num_rows == 0) { ?>
                <tr>
                  <td colspan="6" class="text-center">Khách hàng này chưa có đơn hàng nào.</td>
                </tr>
              <?php } else {
                while ($don = $ds_don->fetch_assoc()) {
                  [$ten_tt, $class_tt] = nhanTrangThaiDon($don['trang_thai']);
              ?>
                <tr>
                  <td><strong>#<?= $don['id_don_hang'] ?></strong></td>
                  <td><?= date('d/m/Y H:i', strtotime($don['ngay_dat'])) ?></td>
                  <td><?= htmlspecialchars($don['dia_chi']) ?></td>
                  <td class="text-price"><?= $cf->DinhDangGia($don['tong_tien']) ?></td>
                  <td><span class="adm-badge <?= $class_tt ?>"><?= $ten_tt ?></span></td>
                  <td>
                    <a href="donhang_chitiet.php?id=<?= $don['id_don_hang'] ?>" class="adm-btn adm-btn-sm adm-btn-info">Chi tiết</a>
                  </td>
                </tr>
              <?php } } ?>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  </main>
</div>

</body>
</html>
