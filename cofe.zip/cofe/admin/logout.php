<?php
// === FILE MỚI THÊM: ĐĂNG XUẤT QUẢN TRỊ / THU NGÂN ===
require_once __DIR__ . "/../caphe.php";

if (isset($_SESSION['admin'])) {
    unset($_SESSION['admin']);
}

header("Location: login.php");
exit;
?>
