<?php
// === FILE: XỬ LÝ NGHIỆP VỤ ĐƠN HÀNG ADMIN / THU NGÂN ===
require_once "check_admin.php"; // Chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    // 1. CẬP NHẬT TRẠNG THÁI ĐƠN HÀNG
    case 'update_status':
        $id_don_hang = isset($_POST['id_don_hang']) ? (int)$_POST['id_don_hang'] : 0;
        $trang_thai  = trim($_POST['trang_thai'] ?? '');
        $redirect    = trim($_POST['redirect'] ?? '');

        if ($id_don_hang > 0 && $cf->CapNhatTrangThaiDonHang($id_don_hang, $trang_thai)) {
            $_SESSION['admin_thongbao'] = "Đã cập nhật trạng thái cho đơn hàng #" . $id_don_hang . "!";
        } else {
            $_SESSION['admin_thongbao'] = "Cập nhật trạng thái thất bại!";
        }

        if ($redirect === 'detail') {
            header("Location: donhang_chitiet.php?id=" . $id_don_hang);
        } else {
            header("Location: index.php");
        }
        exit;

    // 2. XÓA ĐƠN HÀNG (CHỈ QUYỀN ADMIN)
    case 'delete':
        if (!$la_admin) {
            $_SESSION['admin_thongbao'] = "Thu ngân không có quyền xóa đơn hàng!";
            header("Location: index.php");
            exit;
        }

        $id_don_hang = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id_don_hang > 0 && $cf->XoaDonHang($id_don_hang)) {
            $_SESSION['admin_thongbao'] = "Đã xóa đơn hàng #" . $id_don_hang . "!";
        } else {
            $_SESSION['admin_thongbao'] = "Xóa đơn hàng #" . $id_don_hang . " thất bại!";
        }
        header("Location: index.php");
        exit;

    // 3. TẠO ĐƠN HÀNG TRỰC TIẾP TẠI QUẦY (POS)
    case 'create_pos':
        $ten_khach_hang = trim($_POST['ten_khach_hang'] ?? 'Khách lẻ');
        $so_dien_thoai  = trim($_POST['so_dien_thoai'] ?? 'Tại quầy');
        $dia_chi        = trim($_POST['dia_chi'] ?? 'Dùng tại quán');
        $ghi_chu        = trim($_POST['ghi_chu'] ?? '');
        $trang_thai     = trim($_POST['trang_thai'] ?? 'dang_pha_che');
        $soluong_arr    = isset($_POST['soluong']) && is_array($_POST['soluong']) ? $_POST['soluong'] : [];

        $giohang_pos = [];
        foreach ($soluong_arr as $id_sp => $sl) {
            $id_sp = (int)$id_sp;
            $sl    = (int)$sl;
            if ($sl > 0) {
                $sp = $cf->ChiTietSanPham($id_sp);
                if ($sp) {
                    $giohang_pos[$id_sp] = [
                        'id_san_pham'  => $sp['id_san_pham'],
                        'ten_san_pham' => $sp['ten_san_pham'],
                        'gia'          => $sp['gia'],
                        'so_luong'     => $sl
                    ];
                }
            }
        }

        if (empty($giohang_pos)) {
            $_SESSION['admin_thongbao'] = "Vui lòng chọn ít nhất 1 món có số lượng lớn hơn 0!";
            header("Location: taodon.php");
            exit;
        }

        // Tạo đơn tại quầy cho khách vãng lai (id_nguoi_dung = null)
        $id_don_moi = $cf->DatHang(
            null,
            $ten_khach_hang,
            $so_dien_thoai,
            $dia_chi,
            $ghi_chu,
            $giohang_pos,
            $trang_thai
        );

        if ($id_don_moi) {
            $_SESSION['admin_thongbao'] = "Tạo đơn tại quầy #" . $id_don_moi . " thành công!";
            header("Location: donhang_chitiet.php?id=" . $id_don_moi);
        } else {
            $_SESSION['admin_thongbao'] = "Lỗi khi tạo đơn hàng tại quầy!";
            header("Location: taodon.php");
        }
        exit;

    default:
        header("Location: index.php");
        exit;
}
?>