<?php
// === FILE MỚI THÊM: TRANG TỔNG QUAN (DASHBOARD) KHU VỰC QUẢN TRỊ ===
require_once "check_admin.php"; // Kiểm tra session & chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

$tq          = $cf->ThongKeTongQuanDashboard();
$ds_7_ngay   = $cf->DoanhThu7NgayGanNhat();
$top_mon     = $cf->TopSanPhamBanChay(5);
$don_moi     = $cf->DonHangMoiNhat(6);

// Tìm giá trị doanh thu ngày cao nhất trong 7 ngày để tính tỷ lệ chiều cao cột biểu đồ
$max_doanh_thu_ngay = 0;
foreach ($ds_7_ngay as $ngay_item) {
    if ($ngay_item['doanh_thu'] > $max_doanh_thu_ngay) {
        $max_doanh_thu_ngay = $ngay_item['doanh_thu'];
    }
}

$tong_don = max(1, (int)$tq['tong_don']); // Tránh chia cho 0 khi tính %
$pt_cho_xn     = round(((int)$tq['cho_xac_nhan'] / $tong_don) * 100);
$pt_dang_pha   = round(((int)$tq['dang_pha_che'] / $tong_don) * 100);
$pt_hoan_thanh = round(((int)$tq['hoan_thanh']   / $tong_don) * 100);
$pt_da_huy     = round(((int)$tq['da_huy']       / $tong_don) * 100);

function nhanTrangThaiDash($tt) {
    switch ($tt) {
        case 'cho_xac_nhan': return ['Chờ xác nhận', 'badge-warning'];
        case 'dang_pha_che': return ['Đang pha chế', 'badge-info'];
        case 'hoan_thanh':   return ['Hoàn thành',   'badge-success'];
        case 'da_huy':       return ['Đã hủy',       'badge-danger'];
        default:             return [$tt,            'badge-secondary'];
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Trang tổng quan (Dashboard) - Coffee House Admin</title>
  <link rel="stylesheet" href="admin_style.css">
</head>
<body>

<div class="admin-layout">
  <!-- SIDEBAR RIÊNG CỦA KHU VỰC QUẢN TRỊ -->
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag <?= $la_admin ? 'role-admin' : 'role-cashier' ?>">
          <?= $la_admin ? 'Quản trị viên' : 'Thu ngân' ?>
        </span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <?php if ($la_admin) { ?>
        <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
        <!-- MỚI THÊM: MENU QUẢN LÝ SẢN PHẨM -->
        <a href="sanpham.php">☕ Quản lý sản phẩm</a>
        <!-- HẾT PHẦN MỚI THÊM -->
        <a href="khachhang.php">👥 Quản lý khách hàng</a>
        <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <?php } ?>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <!-- NỘI DUNG CHÍNH DASHBOARD -->
  <main class="admin-main">
    <header class="admin-topbar">
      <div>
        <h1>Trang tổng quan hệ thống</h1>
        <p>Xin chào <strong><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></strong> — Tổng hợp tình hình kinh doanh & vận hành quán</p>
      </div>
      <div class="dash-quick-actions">
        <a href="taodon.php" class="adm-btn adm-btn-primary">+ Tạo đơn tại quầy</a>
        <a href="index.php?trang_thai=cho_xac_nhan" class="adm-btn adm-btn-dark">
          Đơn chờ xử lý (<?= (int)$tq['cho_xac_nhan'] ?>)
        </a>
      </div>
    </header>

    <!-- HÀNG 1: 4 THẺ KPI CHÍNH -->
    <section class="kpi-grid">
      <div class="kpi-card kpi-success">
        <span class="kpi-label">Tổng doanh thu (Hoàn thành)</span>
        <strong class="kpi-value"><?= $cf->DinhDangGia($tq['tong_doanh_thu']) ?></strong>
        <small class="kpi-sub">Hôm nay: <strong><?= $cf->DinhDangGia($tq['doanh_thu_hom_nay']) ?></strong></small>
      </div>

      <div class="kpi-card kpi-warning">
        <span class="kpi-label">Tổng đơn hàng</span>
        <strong class="kpi-value"><?= (int)$tq['tong_don'] ?> đơn</strong>
        <small class="kpi-sub">Chờ xác nhận: <strong><?= (int)$tq['cho_xac_nhan'] ?></strong> | Đang pha: <strong><?= (int)$tq['dang_pha_che'] ?></strong></small>
      </div>

      <div class="kpi-card kpi-info">
        <span class="kpi-label">Khách hàng thành viên</span>
        <strong class="kpi-value"><?= (int)$tq['tong_khach_hang'] ?></strong>
        <small class="kpi-sub">Nhân sự nội bộ: <strong><?= (int)$tq['tong_nhan_vien'] ?></strong> tài khoản</small>
      </div>

      <div class="kpi-card">
        <span class="kpi-label">Thực đơn phục vụ</span>
        <strong class="kpi-value"><?= (int)$tq['tong_san_pham'] ?> món</strong>
        <small class="kpi-sub">Thuộc <strong><?= (int)$tq['tong_danh_muc'] ?></strong> danh mục đồ uống & bánh</small>
      </div>
    </section>

    <!-- HÀNG 2: BIỂU ĐỒ DOANH THU 7 NGÀY & TỶ LỆ TRẠNG THÁI ĐƠN -->
    <div class="dash-grid-2col">
      <!-- Biểu đồ doanh thu 7 ngày gần nhất -->
      <section class="adm-card">
        <div class="dash-card-head">
          <h3>📈 Doanh thu 7 ngày gần nhất</h3>
          <span class="text-muted">Tính trên các đơn hoàn thành</span>
        </div>

        <div class="bar-chart-box">
          <?php foreach ($ds_7_ngay as $item) {
            $chieu_cao = ($max_doanh_thu_ngay > 0)
                         ? max(6, round(($item['doanh_thu'] / $max_doanh_thu_ngay) * 160))
                         : 6;
          ?>
            <div class="bar-col">
              <span class="bar-amount">
                <?= $item['doanh_thu'] > 0 ? number_format($item['doanh_thu'] / 1000, 0) . 'k' : '0' ?>
              </span>
              <div class="bar-track">
                <div class="bar-fill <?= $item['doanh_thu'] > 0 ? 'has-value' : '' ?>"
                     style="height: <?= $chieu_cao ?>px;"
                     title="<?= $item['ngay_hien_thi'] ?>: <?= $cf->DinhDangGia($item['doanh_thu']) ?> (<?= $item['so_don'] ?> đơn)">
                </div>
              </div>
              <span class="bar-date"><?= $item['ngay_hien_thi'] ?></span>
            </div>
          <?php } ?>
        </div>
      </section>

      <!-- Phân bổ trạng thái đơn hàng -->
      <section class="adm-card">
        <div class="dash-card-head">
          <h3>🧾 Tỷ lệ trạng thái đơn hàng</h3>
          <span class="text-muted">Tổng <?= (int)$tq['tong_don'] ?> đơn</span>
        </div>

        <div class="status-progress-list">
          <div class="progress-item">
            <div class="progress-label">
              <span>🟡 Chờ xác nhận</span>
              <strong><?= (int)$tq['cho_xac_nhan'] ?> đơn (<?= $pt_cho_xn ?>%)</strong>
            </div>
            <div class="progress-bar-bg">
              <div class="progress-bar-fill fill-warning" style="width: <?= $pt_cho_xn ?>%;"></div>
            </div>
          </div>

          <div class="progress-item">
            <div class="progress-label">
              <span>🔵 Đang pha chế</span>
              <strong><?= (int)$tq['dang_pha_che'] ?> đơn (<?= $pt_dang_pha ?>%)</strong>
            </div>
            <div class="progress-bar-bg">
              <div class="progress-bar-fill fill-info" style="width: <?= $pt_dang_pha ?>%;"></div>
            </div>
          </div>

          <div class="progress-item">
            <div class="progress-label">
              <span>🟢 Hoàn thành</span>
              <strong><?= (int)$tq['hoan_thanh'] ?> đơn (<?= $pt_hoan_thanh ?>%)</strong>
            </div>
            <div class="progress-bar-bg">
              <div class="progress-bar-fill fill-success" style="width: <?= $pt_hoan_thanh ?>%;"></div>
            </div>
          </div>

          <div class="progress-item">
            <div class="progress-label">
              <span>🔴 Đã hủy</span>
              <strong><?= (int)$tq['da_huy'] ?> đơn (<?= $pt_da_huy ?>%)</strong>
            </div>
            <div class="progress-bar-bg">
              <div class="progress-bar-fill fill-danger" style="width: <?= $pt_da_huy ?>%;"></div>
            </div>
          </div>
        </div>
      </section>
    </div>

    <!-- HÀNG 3: TOP MÓN BÁN CHẠY & ĐƠN HÀNG MỚI NHẤT -->
    <div class="dash-grid-2col">
      <!-- Top 5 món bán chạy -->
      <section class="adm-card">
        <div class="dash-card-head">
          <h3>🏆 Top món được đặt nhiều nhất</h3>
          <span class="text-muted">Không tính đơn đã hủy</span>
        </div>

        <div class="table-responsive">
          <table class="adm-table">
            <thead>
              <tr>
                <th>Hạng</th>
                <th>Tên món</th>
                <th>Đã bán</th>
                <th>Doanh số</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($top_mon->num_rows == 0) { ?>
                <tr>
                  <td colspan="4" class="text-center">Chưa có dữ liệu bán hàng.</td>
                </tr>
              <?php } else {
                $hang = 1;
                while ($m = $top_mon->fetch_assoc()) {
              ?>
                <tr>
                  <td><span class="rank-pill rank-<?= $hang ?>">#<?= $hang++ ?></span></td>
                  <td><strong><?= htmlspecialchars($m['ten_san_pham']) ?></strong></td>
                  <td><strong><?= (int)$m['tong_ly'] ?></strong> ly/phần</td>
                  <td class="text-price"><?= $cf->DinhDangGia($m['tong_tien_mon']) ?></td>
                </tr>
              <?php } } ?>
            </tbody>
          </table>
        </div>
      </section>

      <!-- Danh sách đơn hàng mới nhất -->
      <section class="adm-card">
        <div class="dash-card-head">
          <h3>🕒 Đơn hàng mới nhất</h3>
          <a href="index.php">Xem tất cả →</a>
        </div>

        <div class="table-responsive">
          <table class="adm-table">
            <thead>
              <tr>
                <th>Mã</th>
                <th>Khách hàng</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Xem</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($don_moi->num_rows == 0) { ?>
                <tr>
                  <td colspan="5" class="text-center">Chưa có đơn hàng nào.</td>
                </tr>
              <?php } else {
                while ($d = $don_moi->fetch_assoc()) {
                  [$ten_tt, $class_tt] = nhanTrangThaiDash($d['trang_thai']);
              ?>
                <tr>
                  <td><strong>#<?= $d['id_don_hang'] ?></strong></td>
                  <td>
                    <strong><?= htmlspecialchars($d['ten_khach_hang']) ?></strong><br>
                    <small class="text-muted"><?= date('d/m H:i', strtotime($d['ngay_dat'])) ?></small>
                  </td>
                  <td class="text-price"><?= $cf->DinhDangGia($d['tong_tien']) ?></td>
                  <td><span class="adm-badge <?= $class_tt ?>"><?= $ten_tt ?></span></td>
                  <td>
                    <a href="donhang_chitiet.php?id=<?= $d['id_don_hang'] ?>" class="adm-btn adm-btn-sm adm-btn-info">Chi tiết</a>
                  </td>
                </tr>
              <?php } } ?>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  </main>
</div>

</body>
</html>