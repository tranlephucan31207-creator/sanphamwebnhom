<?php
// === FILE MỚI THÊM: TRANG CHỈNH SỬA SẢN PHẨM (KHU VỰC ADMIN) ===
require_once "check_admin.php"; // Kiểm tra session & chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền sửa sản phẩm.";
    header("Location: dashboard.php");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$sp = $cf->ChiTietSanPhamAdmin($id);

if (!$sp) {
    $_SESSION['admin_thongbao'] = "Không tìm thấy sản phẩm #" . $id;
    header("Location: sanpham.php");
    exit;
}

$ds_dm = $cf->ListDanhMuc();

$thong_bao = isset($_SESSION['admin_thongbao']) ? $_SESSION['admin_thongbao'] : "";
unset($_SESSION['admin_thongbao']);

$loi = isset($_SESSION['admin_loi_sp']) ? $_SESSION['admin_loi_sp'] : "";
unset($_SESSION['admin_loi_sp']);

$anh_hien_tai = !empty($sp['hinh_anh']) ? "../" . $sp['hinh_anh'] : "../img/caphe.jpg";
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sửa sản phẩm #<?= $sp['id_san_pham'] ?> - Coffee House Admin</title>
  <link rel="stylesheet" href="admin_style.css?v=2">
</head>
<body>

<div class="admin-layout">
  <!-- SIDEBAR -->
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag role-admin">Quản trị viên</span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
      <a href="sanpham.php" class="active">☕ Quản lý sản phẩm</a>
      <a href="khachhang.php">👥 Quản lý khách hàng</a>
      <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <!-- NỘI DUNG CHÍNH -->
  <main class="admin-main">
    <header class="admin-topbar">
      <div>
        <h1>Chỉnh sửa sản phẩm #<?= $sp['id_san_pham'] ?></h1>
        <p><a href="sanpham.php">← Quay lại danh sách sản phẩm</a></p>
      </div>
    </header>

    <?php if ($thong_bao !== "") { ?>
      <div class="adm-alert adm-alert-success"><?= htmlspecialchars($thong_bao) ?></div>
    <?php } ?>

    <?php if ($loi !== "") { ?>
      <div class="adm-alert adm-alert-danger"><?= htmlspecialchars($loi) ?></div>
    <?php } ?>

    <section class="adm-card staff-form-wrapper">
      <h3>Cập nhật thông tin sản phẩm</h3>

      <form method="post" action="xuly_sanpham.php?action=update" enctype="multipart/form-data">
        <input type="hidden" name="id_san_pham" value="<?= $sp['id_san_pham'] ?>">

        <div class="form-grid-2col">
          <div class="adm-form-group">
            <label for="ten_san_pham">Tên sản phẩm *</label>
            <input type="text" id="ten_san_pham" name="ten_san_pham" maxlength="100"
                   value="<?= htmlspecialchars($sp['ten_san_pham']) ?>" required>
          </div>

          <div class="adm-form-group">
            <label for="id_danh_muc">Danh mục *</label>
            <select id="id_danh_muc" name="id_danh_muc" class="adm-select-full" required>
              <option value="">-- Chọn danh mục --</option>
              <?php while ($dm = $ds_dm->fetch_assoc()) { ?>
                <option value="<?= $dm['id_danh_muc'] ?>"
                        <?= ((int)$sp['id_danh_muc'] === (int)$dm['id_danh_muc']) ? 'selected' : '' ?>>
                  <?= htmlspecialchars($dm['ten_danh_muc']) ?>
                </option>
              <?php } ?>
            </select>
          </div>
        </div>

        <div class="form-grid-2col">
          <div class="adm-form-group">
            <label for="gia">Giá bán (VNĐ) *</label>
            <input type="number" id="gia" name="gia" min="1000" step="500"
                   value="<?= (int)$sp['gia'] ?>" required>
          </div>

          <div class="adm-form-group">
            <label for="noi_bat">Hiển thị nổi bật trên Trang chủ</label>
            <select id="noi_bat" name="noi_bat" class="adm-select-full">
              <option value="0" <?= (int)$sp['noi_bat'] === 0 ? 'selected' : '' ?>>Món thường (Chỉ hiện trong thực đơn)</option>
              <option value="1" <?= (int)$sp['noi_bat'] === 1 ? 'selected' : '' ?>>⭐ Sản phẩm nổi bật (Ưu tiên trang chủ)</option>
            </select>
          </div>
        </div>

        <div class="adm-form-group">
          <label>Hình ảnh hiện tại & Đổi ảnh mới (để trống nếu giữ nguyên ảnh cũ)</label>
          <div class="prod-preview-box">
            <img src="<?= htmlspecialchars($anh_hien_tai) ?>" alt="Ảnh hiện tại" class="prod-preview-img">
            <div>
              <div class="text-muted" style="margin-bottom: 6px;">
                Đường dẫn lưu trong CSDL: <code><?= htmlspecialchars($sp['hinh_anh'] ?: 'Chưa có') ?></code>
              </div>
              <input type="file" id="hinh_anh" name="hinh_anh" accept="image/jpeg,image/png,image/webp,image/gif" class="adm-file-input">
            </div>
          </div>
        </div>

        <div class="adm-form-group">
          <label for="mo_ta">Mô tả hương vị / thành phần</label>
          <textarea id="mo_ta" name="mo_ta" rows="4" class="adm-textarea"><?= htmlspecialchars($sp['mo_ta'] ?? '') ?></textarea>
        </div>

        <div class="form-actions-row">
          <button type="submit" class="adm-btn adm-btn-primary">Lưu thay đổi</button>
          <a href="sanpham.php" class="adm-btn adm-btn-dark">Quay lại</a>
        </div>
      </form>
    </section>
  </main>
</div>

</body>
</html>