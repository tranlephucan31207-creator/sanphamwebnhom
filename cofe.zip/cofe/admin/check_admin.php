<?php
// === FILE KIỂM TRA SESSION & PHÂN QUYỀN TRUY CẬP KHU VỰC QUẢN TRỊ ===
require_once "../caphe.php";
$cf = new caphe();

// 1. Chặn truy cập trái phép nếu chưa đăng nhập khu vực quản trị
if (!isset($_SESSION['admin']) || empty($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

// 2. Đối chiếu lại trạng thái & vai trò mới nhất từ Database
// (Chặn ngay lập tức nếu nhân viên vừa bị Admin khóa tài khoản hoặc thu hồi quyền)
$thong_tin_moi = $cf->KiemTraPhienAdmin((int)$_SESSION['admin']['id_nguoi_dung']);
if (!$thong_tin_moi || (int)$thong_tin_moi['trang_thai'] !== 1) {
    unset($_SESSION['admin']);
    header("Location: login.php");
    exit;
}

$_SESSION['admin']['ho_ten']  = $thong_tin_moi['ho_ten'];
$_SESSION['admin']['email']   = $thong_tin_moi['email'];
$_SESSION['admin']['vai_tro'] = $thong_tin_moi['vai_tro'];

$admin_hien_tai = $_SESSION['admin'];
$la_admin = ($admin_hien_tai['vai_tro'] === 'admin');

// === MỚI THÊM: Hàm chặn truy cập trái phép đối với các trang chỉ dành riêng cho Admin ===
function yeuCauQuyenAdmin($thong_bao = "Truy cập bị từ chối! Bạn không có quyền Quản trị viên (Admin).") {
    global $la_admin;
    if (!$la_admin) {
        $_SESSION['admin_thongbao'] = $thong_bao;
        header("Location: dashboard.php");
        exit;
    }
}
// === HẾT PHẦN MỚI THÊM ===
?>