<?php
require_once "check_admin.php"; // Chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

$trang_thai = isset($_GET['trang_thai']) ? trim($_GET['trang_thai']) : '';
$tukhoa     = isset($_GET['tukhoa']) ? trim($_GET['tukhoa']) : '';

$thong_ke = $cf->ThongKeDonHang();
$ds_don   = $cf->ListDonHang($trang_thai, $tukhoa);

$thong_bao = isset($_SESSION['admin_thongbao']) ? $_SESSION['admin_thongbao'] : "";
unset($_SESSION['admin_thongbao']);

// Hàm hỗ trợ hiển thị nhãn & màu trạng thái
function nhanTrangThai($tt) {
    switch ($tt) {
        case 'cho_xac_nhan': return ['Chờ xác nhận', 'badge-warning'];
        case 'dang_pha_che': return ['Đang pha chế', 'badge-info'];
        case 'hoan_thanh':   return ['Hoàn thành',   'badge-success'];
        case 'da_huy':       return ['Đã hủy',       'badge-danger'];
        default:             return [$tt,            'badge-secondary'];
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quản lý đơn hàng - Coffee House Admin</title>
  <link rel="stylesheet" href="admin_style.css">
</head>
<body>

<div class="admin-layout">
  <!-- SIDEBAR RIÊNG CỦA KHU VỰC QUẢN TRỊ -->
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag <?= $la_admin ? 'role-admin' : 'role-cashier' ?>">
          <?= $la_admin ? 'Quản trị viên' : 'Thu ngân' ?>
        </span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <?php if ($la_admin) { ?>
        <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
        <!-- MỚI THÊM: MENU QUẢN LÝ SẢN PHẨM -->
        <a href="sanpham.php">☕ Quản lý sản phẩm</a>
        <!-- HẾT PHẦN MỚI THÊM -->
        <a href="khachhang.php">👥 Quản lý khách hàng</a>
        <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <?php } ?>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <!-- NỘI DUNG CHÍNH -->
  <main class="admin-main">
    <header class="admin-topbar">
      <div>
        <h1>Quản lý đơn hàng</h1>
        <p>Theo dõi, tiếp nhận, cập nhật pha chế và thanh toán đơn hàng</p>
      </div>
      <a href="taodon.php" class="adm-btn adm-btn-primary">+ Tạo đơn tại quầy</a>
    </header>

    <?php if ($thong_bao !== "") { ?>
      <div class="adm-alert adm-alert-success"><?= htmlspecialchars($thong_bao) ?></div>
    <?php } ?>

    <!-- THẺ THỐNG KÊ KPI -->
    <section class="kpi-grid">
      <div class="kpi-card">
        <span class="kpi-label">Tổng đơn hàng</span>
        <strong class="kpi-value"><?= (int)$thong_ke['tong_don'] ?></strong>
      </div>
      <div class="kpi-card kpi-warning">
        <span class="kpi-label">Chờ xác nhận</span>
        <strong class="kpi-value"><?= (int)$thong_ke['cho_xac_nhan'] ?></strong>
      </div>
      <div class="kpi-card kpi-info">
        <span class="kpi-label">Đang pha chế</span>
        <strong class="kpi-value"><?= (int)$thong_ke['dang_pha_che'] ?></strong>
      </div>
      <div class="kpi-card kpi-success">
        <span class="kpi-label">Doanh thu hoàn thành</span>
        <strong class="kpi-value"><?= $cf->DinhDangGia($thong_ke['doanh_thu']) ?></strong>
      </div>
    </section>

    <!-- THANH BỘ LỌC TRẠNG THÁI & TÌM KIẾM -->
    <section class="filter-bar">
      <div class="status-tabs">
        <a href="index.php" class="<?= $trang_thai === '' ? 'active' : '' ?>">Tất cả</a>
        <a href="index.php?trang_thai=cho_xac_nhan" class="<?= $trang_thai === 'cho_xac_nhan' ? 'active' : '' ?>">Chờ xác nhận</a>
        <a href="index.php?trang_thai=dang_pha_che" class="<?= $trang_thai === 'dang_pha_che' ? 'active' : '' ?>">Đang pha chế</a>
        <a href="index.php?trang_thai=hoan_thanh"   class="<?= $trang_thai === 'hoan_thanh'   ? 'active' : '' ?>">Hoàn thành</a>
        <a href="index.php?trang_thai=da_huy"       class="<?= $trang_thai === 'da_huy'       ? 'active' : '' ?>">Đã hủy</a>
      </div>

      <form method="get" action="index.php" class="adm-search-form">
        <?php if ($trang_thai !== '') { ?>
          <input type="hidden" name="trang_thai" value="<?= htmlspecialchars($trang_thai) ?>">
        <?php } ?>
        <input type="text" name="tukhoa" placeholder="Tìm mã đơn (#12), tên khách, SĐT..."
               value="<?= htmlspecialchars($tukhoa) ?>">
        <button type="submit" class="adm-btn adm-btn-dark">Tìm</button>
      </form>
    </section>

    <!-- BẢNG DANH SÁCH ĐƠN HÀNG -->
    <section class="adm-card">
      <div class="table-responsive">
        <table class="adm-table">
          <thead>
            <tr>
              <th>Mã đơn</th>
              <th>Khách hàng</th>
              <th>Địa chỉ / Hình thức</th>
              <th>Thời gian đặt</th>
              <th>Tổng tiền</th>
              <th>Trạng thái</th>
              <th>Cập nhật nhanh</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($ds_don->num_rows == 0) { ?>
              <tr>
                <td colspan="8" class="text-center">Chưa có đơn hàng nào phù hợp.</td>
              </tr>
            <?php } else {
              while ($row = $ds_don->fetch_assoc()) {
                [$ten_tt, $class_tt] = nhanTrangThai($row['trang_thai']);
            ?>
              <tr>
                <td><strong>#<?= $row['id_don_hang'] ?></strong></td>
                <td>
                  <strong><?= htmlspecialchars($row['ten_khach_hang']) ?></strong><br>
                  <small class="text-muted">📞 <?= htmlspecialchars($row['so_dien_thoai']) ?></small>
                </td>
                <td><?= htmlspecialchars($row['dia_chi']) ?></td>
                <td><?= date('d/m/Y H:i', strtotime($row['ngay_dat'])) ?></td>
                <td class="text-price"><?= $cf->DinhDangGia($row['tong_tien']) ?></td>
                <td><span class="adm-badge <?= $class_tt ?>"><?= $ten_tt ?></span></td>
                <td>
                  <form method="post" action="xuly_donhang.php?action=update_status" class="inline-status-form">
                    <input type="hidden" name="id_don_hang" value="<?= $row['id_don_hang'] ?>">
                    <select name="trang_thai" onchange="this.form.submit()">
                      <option value="cho_xac_nhan" <?= $row['trang_thai']=='cho_xac_nhan'?'selected':'' ?>>Chờ xác nhận</option>
                      <option value="dang_pha_che" <?= $row['trang_thai']=='dang_pha_che'?'selected':'' ?>>Đang pha chế</option>
                      <option value="hoan_thanh"   <?= $row['trang_thai']=='hoan_thanh'  ?'selected':'' ?>>Hoàn thành</option>
                      <option value="da_huy"       <?= $row['trang_thai']=='da_huy'      ?'selected':'' ?>>Đã hủy</option>
                    </select>
                  </form>
                </td>
                <td class="action-cell">
                  <a href="donhang_chitiet.php?id=<?= $row['id_don_hang'] ?>" class="adm-btn adm-btn-sm adm-btn-info">Chi tiết</a>
                  <?php if ($la_admin) { ?>
                    <a href="xuly_donhang.php?action=delete&id=<?= $row['id_don_hang'] ?>"
                       class="adm-btn adm-btn-sm adm-btn-danger"
                       onclick="return confirm('Xóa vĩnh viễn đơn hàng #<?= $row['id_don_hang'] ?>?');">Xóa</a>
                  <?php } ?>
                </td>
              </tr>
            <?php } } ?>
          </tbody>
        </table>
      </div>
    </section>
  </main>
</div>

</body>
</html>
