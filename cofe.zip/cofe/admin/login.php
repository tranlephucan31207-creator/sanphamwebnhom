<?php
require_once __DIR__ . "/../caphe.php";
$cf = new caphe;

// Nếu đã đăng nhập admin/thu ngân rồi thì chuyển thẳng vào Trang tổng quan (Dashboard)
if (isset($_SESSION['admin']) && in_array($_SESSION['admin']['vai_tro'], ['admin', 'thu_ngan'])) {
    header("Location: dashboard.php");
    exit;
}

$loi = isset($_SESSION['admin_loi']) ? $_SESSION['admin_loi'] : "";
unset($_SESSION['admin_loi']);
$email = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $mat_khau = $_POST['mat_khau'] ?? '';

    if ($email === "" || $mat_khau === "") {
        $loi = "Vui lòng nhập đầy đủ Email và Mật khẩu nhân viên!";
    } else {
        $admin = $cf->DangNhapAdmin($email, $mat_khau);
        if ($admin) {
            $_SESSION['admin'] = $admin;
            header("Location: dashboard.php");
            exit;
        } else {
            $loi = "Tài khoản không tồn tại, sai mật khẩu hoặc không có quyền Quản trị / Thu ngân!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Đăng nhập Quản trị / Thu ngân - Coffee House</title>
  <link rel="stylesheet" href="admin_style.css">
</head>
<body class="admin-login-body">

  <div class="admin-login-card">
    <div class="admin-login-header">
      <div class="brand-badge">☕ COFFEE HOUSE POS</div>
      <h1>Cổng Quản Trị & Thu Ngân</h1>
      <p>Đăng nhập để quản lý đơn hàng và vận hành quầy</p>
    </div>

    <?php if ($loi !== "") { ?>
      <div class="adm-alert adm-alert-danger"><?= htmlspecialchars($loi) ?></div>
    <?php } ?>

    <form method="post" action="login.php">
      <div class="adm-form-group">
        <label for="email">Email nhân viên</label>
        <input type="email" id="email" name="email" placeholder="admin@coffeehouse.vn"
               value="<?= htmlspecialchars($email) ?>" required>
      </div>

      <div class="adm-form-group">
        <label for="mat_khau">Mật khẩu</label>
        <input type="password" id="mat_khau" name="mat_khau" placeholder="Nhập mật khẩu..." required>
      </div>

      <button type="submit" class="adm-btn adm-btn-primary adm-btn-block">Đăng nhập hệ thống</button>
    </form>

    <div class="admin-login-footer">
      <a href="../index.php">← Quay về trang bán hàng công khai</a>
    </div>
  </div>

</body>
</html>
