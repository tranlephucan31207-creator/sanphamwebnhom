<?php
// === FILE MỚI THÊM: XỬ LÝ NGHIỆP VỤ QUẢN LÝ DANH MỤC (ADMIN) ===
require_once "check_admin.php"; // Kiểm tra session & chặn truy cập trái phép
/** @var caphe $cf */
/** @var bool $la_admin */

if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền thao tác danh mục.";
    header("Location: dashboard.php");
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    // 1. THÊM DANH MỤC MỚI
    case 'create':
        $ten_danh_muc = trim($_POST['ten_danh_muc'] ?? '');

        if ($ten_danh_muc === '') {
            $_SESSION['admin_loi_dm'] = "Vui lòng nhập tên danh mục!";
            header("Location: danhmuc.php");
            exit;
        }

        if (mb_strlen($ten_danh_muc, 'UTF-8') > 50) {
            $_SESSION['admin_loi_dm'] = "Tên danh mục không được vượt quá 50 ký tự!";
            header("Location: danhmuc.php");
            exit;
        }

        $ket_qua = $cf->ThemDanhMuc($ten_danh_muc);
        if ($ket_qua === true) {
            $_SESSION['admin_thongbao'] = "Đã thêm danh mục \"" . $ten_danh_muc . "\" thành công!";
        } else {
            $_SESSION['admin_loi_dm'] = $ket_qua;
        }
        header("Location: danhmuc.php");
        exit;

    // 2. CẬP NHẬT TÊN DANH MỤC
    case 'update':
        $id_danh_muc  = isset($_POST['id_danh_muc']) ? (int)$_POST['id_danh_muc'] : 0;
        $ten_danh_muc = trim($_POST['ten_danh_muc'] ?? '');

        if ($id_danh_muc <= 0) {
            header("Location: danhmuc.php");
            exit;
        }

        if ($ten_danh_muc === '') {
            $_SESSION['admin_loi_dm'] = "Tên danh mục không được để trống!";
            header("Location: danhmuc.php?edit=" . $id_danh_muc);
            exit;
        }

        if (mb_strlen($ten_danh_muc, 'UTF-8') > 50) {
            $_SESSION['admin_loi_dm'] = "Tên danh mục không được vượt quá 50 ký tự!";
            header("Location: danhmuc.php?edit=" . $id_danh_muc);
            exit;
        }

        $ket_qua = $cf->CapNhatDanhMuc($id_danh_muc, $ten_danh_muc);
        if ($ket_qua === true) {
            $_SESSION['admin_thongbao'] = "Đã cập nhật danh mục #" . $id_danh_muc . " thành \"" . $ten_danh_muc . "\"!";
            header("Location: danhmuc.php");
        } else {
            $_SESSION['admin_loi_dm'] = $ket_qua;
            header("Location: danhmuc.php?edit=" . $id_danh_muc);
        }
        exit;

    // 3. XÓA DANH MỤC (CHỈ XÓA ĐƯỢC KHI KHÔNG CÒN SẢN PHẨM NÀO THUỘC DANH MỤC)
    case 'delete':
        $id_danh_muc = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id_danh_muc > 0) {
            $ket_qua = $cf->XoaDanhMuc($id_danh_muc);
            if ($ket_qua === true) {
                $_SESSION['admin_thongbao'] = "Đã xóa danh mục #" . $id_danh_muc . " thành công!";
            } else {
                $_SESSION['admin_loi_dm'] = $ket_qua;
            }
        }
        header("Location: danhmuc.php");
        exit;

    default:
        header("Location: danhmuc.php");
        exit;
}
?>