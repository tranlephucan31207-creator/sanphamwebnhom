<?php
require_once "check_admin.php"; // Chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$don = $cf->ChiTietDonHang($id);

if (!$don) {
    $_SESSION['admin_thongbao'] = "Không tìm thấy đơn hàng #" . $id;
    header("Location: index.php");
    exit;
}

$ds_mon = $cf->ListSanPhamTrongDon($id);
$thong_bao = isset($_SESSION['admin_thongbao']) ? $_SESSION['admin_thongbao'] : "";
unset($_SESSION['admin_thongbao']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Chi tiết đơn hàng #<?= $don['id_don_hang'] ?> - Coffee House</title>
  <link rel="stylesheet" href="admin_style.css">
</head>
<body>

<div class="admin-layout">
  <!-- SIDEBAR -->
  <aside class="admin-sidebar no-print">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag <?= $la_admin ? 'role-admin' : 'role-cashier' ?>">
          <?= $la_admin ? 'Quản trị viên' : 'Thu ngân' ?>
        </span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <?php if ($la_admin) { ?>
        <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
        <!-- MỚI THÊM: MENU QUẢN LÝ SẢN PHẨM -->
        <a href="sanpham.php">☕ Quản lý sản phẩm</a>
        <!-- HẾT PHẦN MỚI THÊM -->
        <a href="khachhang.php">👥 Quản lý khách hàng</a>
        <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <?php } ?>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <!-- NỘI DUNG CHI TIẾT ĐƠN HÀNG -->
  <main class="admin-main">
    <header class="admin-topbar no-print">
      <div>
        <h1>Chi tiết đơn hàng #<?= $don['id_don_hang'] ?></h1>
        <p><a href="index.php">← Quay lại danh sách đơn hàng</a></p>
      </div>
      <button type="button" onclick="window.print()" class="adm-btn adm-btn-dark">🖨️ In hóa đơn</button>
    </header>

    <?php if ($thong_bao !== "") { ?>
      <div class="adm-alert adm-alert-success no-print"><?= htmlspecialchars($thong_bao) ?></div>
    <?php } ?>

    <div class="detail-grid">
      <!-- KHỐI HÓA ĐƠN CHI TIẾT -->
      <section class="adm-card invoice-box">
        <div class="invoice-header">
          <h2>☕ COFFEE HOUSE</h2>
          <p>123 Đường Nguyễn Trãi, Quận 1, TP.HCM | ĐT: 0909 123 456</p>
          <hr>
          <h3>HÓA ĐƠN BÁN HÀNG #<?= $don['id_don_hang'] ?></h3>
        </div>

        <div class="invoice-meta">
          <p><strong>Khách hàng:</strong> <?= htmlspecialchars($don['ten_khach_hang']) ?></p>
          <p><strong>Số điện thoại:</strong> <?= htmlspecialchars($don['so_dien_thoai']) ?></p>
          <p><strong>Địa chỉ / Bàn:</strong> <?= htmlspecialchars($don['dia_chi']) ?></p>
          <p><strong>Thời gian đặt:</strong> <?= date('d/m/Y H:i:s', strtotime($don['ngay_dat'])) ?></p>
          <?php if (!empty($don['ghi_chu'])) { ?>
            <p><strong>Ghi chú:</strong> <em><?= htmlspecialchars($don['ghi_chu']) ?></em></p>
          <?php } ?>
        </div>

        <table class="adm-table">
          <thead>
            <tr>
              <th>STT</th>
              <th>Tên món</th>
              <th>Đơn giá</th>
              <th>SL</th>
              <th>Thành tiền</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $stt = 1;
            while ($mon = $ds_mon->fetch_assoc()) {
              $thanh_tien = $mon['don_gia'] * $mon['so_luong'];
            ?>
            <tr>
              <td><?= $stt++ ?></td>
              <td><strong><?= htmlspecialchars($mon['ten_san_pham']) ?></strong></td>
              <td><?= $cf->DinhDangGia($mon['don_gia']) ?></td>
              <td><?= (int)$mon['so_luong'] ?></td>
              <td class="text-price"><?= $cf->DinhDangGia($thanh_tien) ?></td>
            </tr>
            <?php } ?>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="4" style="text-align: right;"><strong>TỔNG THANH TOÁN:</strong></td>
              <td class="text-price" style="font-size: 18px;"><?= $cf->DinhDangGia($don['tong_tien']) ?></td>
            </tr>
          </tfoot>
        </table>
      </section>

      <!-- KHỐI XỬ LÝ TRẠNG THÁI CỦA THU NGÂN -->
      <section class="adm-card no-print">
        <h3>Xử lý trạng thái đơn</h3>
        <form method="post" action="xuly_donhang.php?action=update_status">
          <input type="hidden" name="id_don_hang" value="<?= $don['id_don_hang'] ?>">
          <input type="hidden" name="redirect" value="detail">

          <div class="adm-form-group">
            <label for="trang_thai">Trạng thái hiện tại</label>
            <select id="trang_thai" name="trang_thai" class="adm-select-full">
              <option value="cho_xac_nhan" <?= $don['trang_thai']=='cho_xac_nhan'?'selected':'' ?>>🟡 Chờ xác nhận</option>
              <option value="dang_pha_che" <?= $don['trang_thai']=='dang_pha_che'?'selected':'' ?>>🔵 Đang pha chế</option>
              <option value="hoan_thanh"   <?= $don['trang_thai']=='hoan_thanh'  ?'selected':'' ?>>🟢 Hoàn thành (Đã thu tiền)</option>
              <option value="da_huy"       <?= $don['trang_thai']=='da_huy'      ?'selected':'' ?>>🔴 Đã hủy</option>
            </select>
          </div>

          <button type="submit" class="adm-btn adm-btn-primary adm-btn-block">Lưu trạng thái</button>
        </form>
      </section>
    </div>
  </main>
</div>

</body>
</html>
