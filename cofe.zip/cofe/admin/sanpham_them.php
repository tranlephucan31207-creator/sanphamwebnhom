<?php
// === FILE MỚI THÊM: TRANG THÊM SẢN PHẨM MỚI (KHU VỰC ADMIN) ===
require_once "check_admin.php"; // Kiểm tra session & chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền thêm sản phẩm.";
    header("Location: dashboard.php");
    exit;
}

$ds_dm = $cf->ListDanhMuc();

$loi = isset($_SESSION['admin_loi_sp']) ? $_SESSION['admin_loi_sp'] : "";
unset($_SESSION['admin_loi_sp']);

$du_lieu_cu = isset($_SESSION['admin_old_sp']) ? $_SESSION['admin_old_sp'] : [];
unset($_SESSION['admin_old_sp']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Thêm sản phẩm mới - Coffee House Admin</title>
  <link rel="stylesheet" href="admin_style.css">
</head>
<body>

<div class="admin-layout">
  <!-- SIDEBAR -->
  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <span class="brand-icon">☕</span>
      <div>
        <strong>Coffee House</strong>
        <small>Admin & Thu ngân</small>
      </div>
    </div>

    <div class="sidebar-user">
      <div class="user-avatar">👤</div>
      <div>
        <div class="user-name"><?= htmlspecialchars($admin_hien_tai['ho_ten']) ?></div>
        <span class="role-tag role-admin">Quản trị viên</span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <a href="dashboard.php">📊 Trang tổng quan</a>
      <a href="index.php">📋 Quản lý đơn hàng</a>
      <a href="taodon.php">🧾 Tạo đơn tại quầy</a>
      <a href="danhmuc.php">🗂️ Quản lý danh mục</a>
      <a href="sanpham.php" class="active">☕ Quản lý sản phẩm</a>
      <a href="khachhang.php">👥 Quản lý khách hàng</a>
      <a href="nhanvien.php">🧑‍💼 Quản lý nhân viên</a>
      <a href="../index.php" target="_blank">🌐 Xem trang khách hàng</a>
      <a href="logout.php" class="nav-logout">🚪 Đăng xuất</a>
    </nav>
  </aside>

  <!-- NỘI DUNG CHÍNH -->
  <main class="admin-main">
    <header class="admin-topbar">
      <div>
        <h1>Thêm sản phẩm mới</h1>
        <p><a href="sanpham.php">← Quay lại danh sách sản phẩm</a></p>
      </div>
    </header>

    <?php if ($loi !== "") { ?>
      <div class="adm-alert adm-alert-danger"><?= htmlspecialchars($loi) ?></div>
    <?php } ?>

    <section class="adm-card staff-form-wrapper">
      <h3>Thông tin món đồ uống / bánh</h3>

      <form method="post" action="xuly_sanpham.php?action=create" enctype="multipart/form-data">
        <div class="form-grid-2col">
          <div class="adm-form-group">
            <label for="ten_san_pham">Tên sản phẩm *</label>
            <input type="text" id="ten_san_pham" name="ten_san_pham" maxlength="100"
                   value="<?= htmlspecialchars($du_lieu_cu['ten_san_pham'] ?? '') ?>"
                   placeholder="Ví dụ: Cà phê muối, Trà vải hạt sen..." required>
          </div>

          <div class="adm-form-group">
            <label for="id_danh_muc">Danh mục *</label>
            <select id="id_danh_muc" name="id_danh_muc" class="adm-select-full" required>
              <option value="">-- Chọn danh mục --</option>
              <?php while ($dm = $ds_dm->fetch_assoc()) { ?>
                <option value="<?= $dm['id_danh_muc'] ?>"
                        <?= ((int)($du_lieu_cu['id_danh_muc'] ?? 0) === (int)$dm['id_danh_muc']) ? 'selected' : '' ?>>
                  <?= htmlspecialchars($dm['ten_danh_muc']) ?>
                </option>
              <?php } ?>
            </select>
          </div>
        </div>

        <div class="form-grid-2col">
          <div class="adm-form-group">
            <label for="gia">Giá bán (VNĐ) *</label>
            <input type="number" id="gia" name="gia" min="1000" step="500"
                   value="<?= htmlspecialchars($du_lieu_cu['gia'] ?? '') ?>"
                   placeholder="Ví dụ: 35000" required>
          </div>

          <div class="adm-form-group">
            <label for="noi_bat">Hiển thị nổi bật trên Trang chủ</label>
            <select id="noi_bat" name="noi_bat" class="adm-select-full">
              <option value="0" <?= ($du_lieu_cu['noi_bat'] ?? '0') === '0' ? 'selected' : '' ?>>Món thường (Chỉ hiện trong thực đơn)</option>
              <option value="1" <?= ($du_lieu_cu['noi_bat'] ?? '') === '1' ? 'selected' : '' ?>>⭐ Sản phẩm nổi bật (Ưu tiên trang chủ)</option>
            </select>
          </div>
        </div>

        <div class="adm-form-group">
          <label for="hinh_anh">Hình ảnh sản phẩm (JPG, PNG, WEBP — tối đa 3MB)</label>
          <input type="file" id="hinh_anh" name="hinh_anh" accept="image/jpeg,image/png,image/webp,image/gif" class="adm-file-input">
          <small class="text-muted">Nếu chưa chọn ảnh, hệ thống sẽ gán ảnh mặc định <code>img/caphe.jpg</code>.</small>
        </div>

        <div class="adm-form-group">
          <label for="mo_ta">Mô tả hương vị / thành phần</label>
          <textarea id="mo_ta" name="mo_ta" rows="4" class="adm-textarea"
                    placeholder="Mô tả ngắn gọn về hương vị, nguyên liệu của món..."><?= htmlspecialchars($du_lieu_cu['mo_ta'] ?? '') ?></textarea>
        </div>

        <div class="form-actions-row">
          <button type="submit" class="adm-btn adm-btn-primary">Lưu sản phẩm mới</button>
          <a href="sanpham.php" class="adm-btn adm-btn-dark">Hủy bỏ</a>
        </div>
      </form>
    </section>
  </main>
</div>

</body>
</html>