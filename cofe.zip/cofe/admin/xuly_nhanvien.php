<?php
// === FILE MỚI THÊM: XỬ LÝ NGHIỆP VỤ QUẢN LÝ NHÂN VIÊN ADMIN ===
require_once "check_admin.php"; // Kiểm tra session & chặn truy cập trái phép
/** @var caphe $cf */
/** @var array $admin_hien_tai */
/** @var bool $la_admin */

if (!$la_admin) {
    $_SESSION['admin_thongbao'] = "Truy cập bị từ chối! Chỉ Quản trị viên (Admin) mới có quyền thực hiện thao tác này.";
    header("Location: index.php");
    exit;
}

$action = isset($_GET['action']) ? $_GET['action'] : '';
$id_dang_dang_nhap = (int)$admin_hien_tai['id_nguoi_dung'];

switch ($action) {
    // 1. THÊM NHÂN VIÊN MỚI
    case 'create':
        $ho_ten     = trim($_POST['ho_ten'] ?? '');
        $email      = trim($_POST['email'] ?? '');
        $dien_thoai = trim($_POST['dien_thoai'] ?? '');
        $mat_khau   = $_POST['mat_khau'] ?? '';
        $vai_tro    = trim($_POST['vai_tro'] ?? 'thu_ngan');
        $trang_thai = isset($_POST['trang_thai']) ? (int)$_POST['trang_thai'] : 1;

        $_SESSION['admin_old_nv'] = [
            'ho_ten'     => $ho_ten,
            'email'      => $email,
            'dien_thoai' => $dien_thoai,
            'vai_tro'    => $vai_tro,
            'trang_thai' => (string)$trang_thai
        ];

        if ($ho_ten === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['admin_loi_nv'] = "Vui lòng nhập đầy đủ Họ tên và đúng định dạng Email!";
            header("Location: nhanvien_them.php");
            exit;
        }

        if (strlen($mat_khau) < 6) {
            $_SESSION['admin_loi_nv'] = "Mật khẩu khởi tạo phải có ít nhất 6 ký tự!";
            header("Location: nhanvien_them.php");
            exit;
        }

        $ket_qua = $cf->ThemNhanVien($ho_ten, $email, $dien_thoai, $mat_khau, $vai_tro, $trang_thai);
        if ($ket_qua === true) {
            unset($_SESSION['admin_old_nv']);
            $_SESSION['admin_thongbao'] = "Đã tạo tài khoản nhân viên \"" . $ho_ten . "\" thành công!";
            header("Location: nhanvien.php");
        } else {
            $_SESSION['admin_loi_nv'] = $ket_qua;
            header("Location: nhanvien_them.php");
        }
        exit;

    // 2. CẬP NHẬT HỒ SƠ & PHÂN QUYỀN NHÂN VIÊN
    case 'update':
        $id_nguoi_dung = isset($_POST['id_nguoi_dung']) ? (int)$_POST['id_nguoi_dung'] : 0;
        $ho_ten        = trim($_POST['ho_ten'] ?? '');
        $email         = trim($_POST['email'] ?? '');
        $dien_thoai    = trim($_POST['dien_thoai'] ?? '');
        $vai_tro       = trim($_POST['vai_tro'] ?? 'thu_ngan');
        $trang_thai    = isset($_POST['trang_thai']) ? (int)$_POST['trang_thai'] : 1;
        $mat_khau_moi  = $_POST['mat_khau_moi'] ?? '';

        if ($id_nguoi_dung <= 0) {
            header("Location: nhanvien.php");
            exit;
        }

        $nv_hien_tai = $cf->ChiTietNhanVien($id_nguoi_dung);
        if (!$nv_hien_tai) {
            $_SESSION['admin_thongbao'] = "Không tìm thấy nhân viên #" . $id_nguoi_dung;
            header("Location: nhanvien.php");
            exit;
        }

        // Chặn Admin tự khóa hoặc tự hạ quyền chính mình
        if ($id_nguoi_dung === $id_dang_dang_nhap) {
            if ($trang_thai === 0) {
                $_SESSION['admin_loi_nv'] = "Bạn không thể tự khóa tài khoản Quản trị viên đang đăng nhập!";
                header("Location: nhanvien_chitiet.php?id=" . $id_nguoi_dung);
                exit;
            }
            if ($vai_tro !== 'admin') {
                $_SESSION['admin_loi_nv'] = "Bạn không thể tự hạ quyền tài khoản Quản trị viên đang đăng nhập!";
                header("Location: nhanvien_chitiet.php?id=" . $id_nguoi_dung);
                exit;
            }
        }

        // Bảo vệ không khóa hoặc hạ quyền Quản trị viên hoạt động cuối cùng
        if ($nv_hien_tai['vai_tro'] === 'admin' && (int)$nv_hien_tai['trang_thai'] === 1) {
            if (($vai_tro !== 'admin' || $trang_thai === 0) && $cf->DemSoAdminHoatDong() <= 1) {
                $_SESSION['admin_loi_nv'] = "Hệ thống phải có ít nhất 1 Quản trị viên (Admin) đang hoạt động!";
                header("Location: nhanvien_chitiet.php?id=" . $id_nguoi_dung);
                exit;
            }
        }

        if ($ho_ten === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['admin_loi_nv'] = "Vui lòng nhập đầy đủ Họ tên và đúng định dạng Email!";
            header("Location: nhanvien_chitiet.php?id=" . $id_nguoi_dung);
            exit;
        }

        if ($mat_khau_moi !== '' && strlen($mat_khau_moi) < 6) {
            $_SESSION['admin_loi_nv'] = "Mật khẩu mới phải có ít nhất 6 ký tự!";
            header("Location: nhanvien_chitiet.php?id=" . $id_nguoi_dung);
            exit;
        }

        $ket_qua = $cf->CapNhatNhanVien($id_nguoi_dung, $ho_ten, $email, $dien_thoai, $vai_tro, $trang_thai, $mat_khau_moi);
        if ($ket_qua === true) {
            $_SESSION['admin_thongbao'] = "Đã cập nhật hồ sơ nhân viên #" . $id_nguoi_dung . " thành công!";
        } else {
            $_SESSION['admin_loi_nv'] = $ket_qua;
        }
        header("Location: nhanvien_chitiet.php?id=" . $id_nguoi_dung);
        exit;

    // 3. KHÓA / MỞ KHÓA NHANH TÀI KHOẢN NHÂN VIÊN
    case 'toggle_status':
        $id     = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $status = isset($_GET['status']) ? (int)$_GET['status'] : 1;

        if ($id === $id_dang_dang_nhap) {
            $_SESSION['admin_loi_nv'] = "Bạn không thể tự khóa tài khoản đang đăng nhập!";
            header("Location: nhanvien.php");
            exit;
        }

        $nv_muc_tieu = $cf->ChiTietNhanVien($id);
        if ($nv_muc_tieu && $nv_muc_tieu['vai_tro'] === 'admin' && $status === 0 && $cf->DemSoAdminHoatDong() <= 1) {
            $_SESSION['admin_loi_nv'] = "Không thể khóa Quản trị viên (Admin) hoạt động cuối cùng!";
            header("Location: nhanvien.php");
            exit;
        }

        if ($id > 0 && $cf->DoiTrangThaiNhanVien($id, $status)) {
            $nhan = ($status === 1) ? "mở khóa" : "khóa";
            $_SESSION['admin_thongbao'] = "Đã " . $nhan . " tài khoản nhân viên #" . $id . "!";
        }
        header("Location: nhanvien.php");
        exit;

    // 4. XÓA TÀI KHOẢN NHÂN VIÊN
    case 'delete':
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

        if ($id === $id_dang_dang_nhap) {
            $_SESSION['admin_loi_nv'] = "Bạn không thể tự xóa tài khoản đang đăng nhập!";
            header("Location: nhanvien.php");
            exit;
        }

        $nv_muc_tieu = $cf->ChiTietNhanVien($id);
        if ($nv_muc_tieu && $nv_muc_tieu['vai_tro'] === 'admin' && (int)$nv_muc_tieu['trang_thai'] === 1 && $cf->DemSoAdminHoatDong() <= 1) {
            $_SESSION['admin_loi_nv'] = "Không thể xóa Quản trị viên (Admin) hoạt động cuối cùng!";
            header("Location: nhanvien.php");
            exit;
        }

        if ($id > 0 && $cf->XoaNhanVien($id)) {
            $_SESSION['admin_thongbao'] = "Đã xóa tài khoản nhân viên #" . $id . "!";
        }
        header("Location: nhanvien.php");
        exit;

    default:
        header("Location: nhanvien.php");
        exit;
}
?>
