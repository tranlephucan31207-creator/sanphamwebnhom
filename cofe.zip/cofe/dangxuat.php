<?php
require_once "caphe.php";
$cf = new caphe;

// Lưu lại giỏ hàng vào tài khoản trước khi đăng xuất để lần sau đăng nhập có lại
if (isset($_SESSION['user']['id_nguoi_dung'])) {
    $gio_hien_tai = isset($_SESSION['giohang']) && is_array($_SESSION['giohang']) ? $_SESSION['giohang'] : [];
    $cf->LuuGioHangNguoiDung((int)$_SESSION['user']['id_nguoi_dung'], $gio_hien_tai);
    unset($_SESSION['user']);
}

// Xóa giỏ hàng và phiên theo dõi đơn tạm khỏi Session khi đăng xuất
unset($_SESSION['giohang']);
unset($_SESSION['don_vua_dat']);

header("Location: index.php");
exit;
?>