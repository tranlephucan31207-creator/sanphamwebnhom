<?php
require_once "caphe.php";
$cf = new caphe;

$giohang = isset($_SESSION['giohang']) ? $_SESSION['giohang'] : [];
$thongbao = isset($_SESSION['thongbao']) ? $_SESSION['thongbao'] : "";
unset($_SESSION['thongbao']); // Hiển thị 1 lần rồi xóa
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Coffee House - Giỏ hàng</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- HEADER (giữ nguyên cấu trúc các trang khác) -->
  <header>
    <div class="container">
      <div class="header-left">
        <div class="logo">☕ Coffee House</div>
        <nav>
          <ul>
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="danhmuc.php">Danh mục</a></li>
            <li><a href="products.php">Sản phẩm</a></li>
            <li><a href="theodoi_donhang.php">Theo dõi đơn</a></li>
            <li><a href="index.php#about">Giới thiệu</a></li>
            <li><a href="index.php#footer">Liên hệ</a></li>
          </ul>
        </nav>
      </div>

      <div class="header-right">
        <a href="giohang.php">🛒 Giỏ hàng (<?= $cf->TongSoLuongGioHang() ?>)</a>
        <?php if (isset($_SESSION['user'])) { ?>
          <a href="taikhoan.php">👤 <?= htmlspecialchars($_SESSION['user']['ho_ten']) ?></a>
          <a href="dangxuat.php">Đăng xuất</a>
        <?php } else { ?>
          <a href="dangnhap.php">Đăng nhập</a>
          <a href="dangky.php">Đăng ký</a>
        <?php } ?>
      </div>
    </div>
  </header>

  <!-- TIÊU ĐỀ -->
  <div class="page-title">
    <h1>Giỏ hàng của bạn</h1>
  </div>

  <div class="cart-wrapper">
    <?php if ($thongbao != "") { ?>
      <div class="cart-alert"><?= htmlspecialchars($thongbao) ?></div>
    <?php } ?>

    <?php if (empty($giohang)) { ?>
      <!-- TRƯỜNG HỢP GIỎ HÀNG TRỐNG -->
      <div class="cart-empty">
        <p>Giỏ hàng của bạn hiện đang trống.</p>
        <a href="products.php" class="btn">Tiếp tục chọn món</a>
      </div>
    <?php } else { ?>
      <!-- DANH SÁCH SẢN PHẨM TRONG GIỎ -->
      <form method="post" action="xuly_giohang.php?action=update">
        <table class="cart-table">
          <thead>
            <tr>
              <th>Hình ảnh</th>
              <th>Tên sản phẩm</th>
              <th>Đơn giá</th>
              <th>Số lượng</th>
              <th>Thành tiền</th>
              <th>Xóa</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $tongtien = 0;
            foreach ($giohang as $item) {
                $thanhtien = $item['gia'] * $item['so_luong'];
                $tongtien += $thanhtien;
            ?>
            <tr>
              <td>
                <img src="<?= htmlspecialchars($item['hinh_anh']) ?>" alt="<?= htmlspecialchars($item['ten_san_pham']) ?>">
              </td>
              <td>
                <a href="chitiet.php?id=<?= $item['id_san_pham'] ?>">
                  <strong><?= htmlspecialchars($item['ten_san_pham']) ?></strong>
                </a>
              </td>
              <td class="price"><?= $cf->DinhDangGia($item['gia']) ?></td>
              <td>
                <input type="number"
                       name="soluong[<?= $item['id_san_pham'] ?>]"
                       value="<?= $item['so_luong'] ?>"
                       min="1"
                       class="cart-qty-input">
              </td>
              <td class="price"><?= $cf->DinhDangGia($thanhtien) ?></td>
              <td>
                <a href="xuly_giohang.php?action=delete&id=<?= $item['id_san_pham'] ?>"
                   class="cart-remove"
                   title="Xóa sản phẩm">✕</a>
              </td>
            </tr>
            <?php } ?>
          </tbody>
        </table>

        <!-- HÀNG NÚT THAO TÁC -->
        <div class="cart-actions">
          <div>
            <a href="products.php" class="btn btn-outline">← Tiếp tục mua hàng</a>
            <a href="xuly_giohang.php?action=clear"
               class="btn btn-danger"
               onclick="return confirm('Bạn có chắc muốn xóa toàn bộ giỏ hàng?');">Xóa giỏ hàng</a>
          </div>
          <button type="submit" class="btn">Cập nhật số lượng</button>
        </div>
      </form>

      <!-- === SỬA ĐỔI: KHỐI TỔNG TIỀN & FORM THÔNG TIN ĐẶT HÀNG LƯU VÀO CSDL === -->
      <div class="cart-summary" style="text-align: left;">
        <h3 style="margin-top: 0; color: #4B3621;">Thông tin nhận hàng</h3>
        <form method="post" action="xuly_giohang.php?action=checkout">
          <div class="form-group">
            <label for="ten_khach_hang">Họ tên người nhận *</label>
            <input type="text" id="ten_khach_hang" name="ten_khach_hang" required
                   placeholder="Nhập họ tên khách hàng..."
                   value="<?= isset($_SESSION['user']) ? htmlspecialchars($_SESSION['user']['ho_ten']) : '' ?>">
          </div>

          <div class="form-group">
            <label for="so_dien_thoai">Số điện thoại liên hệ *</label>
            <input type="text" id="so_dien_thoai" name="so_dien_thoai" required
                   placeholder="Nhập số điện thoại..."
                   value="<?= isset($_SESSION['user']) ? htmlspecialchars($_SESSION['user']['dien_thoai']) : '' ?>">
          </div>

          <div class="form-group">
            <label for="dia_chi">Địa chỉ giao hàng / Hình thức dùng *</label>
            <input type="text" id="dia_chi" name="dia_chi" required
                   placeholder="Ví dụ: Số 12 Nguyễn Trãi, Q.1 hoặc Dùng tại quán - Bàn 05">
          </div>

          <div class="form-group">
            <label for="ghi_chu">Ghi chú món (tùy chọn)</label>
            <input type="text" id="ghi_chu" name="ghi_chu"
                   placeholder="Ví dụ: Ít đá, ít đường, giao giờ hành chính...">
          </div>

          <div style="text-align: right; margin-top: 20px; border-top: 1px solid #D8C3A5; padding-top: 15px;">
            <p>Tổng thanh toán: <span class="price"><?= $cf->DinhDangGia($tongtien) ?></span></p>
            <button type="submit" class="btn" style="border: none; cursor: pointer; font-family: inherit; font-size: 16px;">
              Xác nhận đặt hàng
            </button>
          </div>
        </form>
      </div>
      <!-- === HẾT PHẦN SỬA ĐỔI === -->
    <?php } ?>
  </div>

  <!-- FOOTER (giữ nguyên cấu trúc các trang khác) -->
  <footer id="footer">
    <div class="footer-container">
      <div class="footer-col">
        <h3>☕ Coffee House</h3>
        <p>Thương hiệu cà phê chất lượng, mang tới hương vị đậm đà nguyên bản từ những hạt cà phê hảo hạng.</p>
      </div>
      <div class="footer-col">
        <h3>Thông Tin Liên Hệ</h3>
        <p>📍 Địa chỉ: 123 Đường Nguyễn Trãi, Quận 1, TP.HCM</p>
        <p>📞 Điện thoại: 0909 123 456</p>
        <p>✉️ Email: contact@coffeehouse.vn</p>
        <p>⏰ Giờ mở cửa: 07:00 - 22:30 hàng ngày</p>
      </div>
      <div class="footer-col">
        <h3>Liên Kết Nhanh</h3>
        <ul>
          <li><a href="index.php">Trang chủ</a></li>
          <li><a href="danhmuc.php">Danh mục</a></li>
          <li><a href="products.php">Sản phẩm</a></li>
          <li><a href="giohang.php">Giỏ hàng</a></li>
        </ul>
      </div>
    </div>
    <div class="copyright">
      <p>&copy; Coffee House. Tất cả quyền được bảo lưu.</p>
    </div>
  </footer>

</body>
</html>
