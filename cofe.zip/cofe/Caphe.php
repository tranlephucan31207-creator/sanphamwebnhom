<?php
// === MỚI THÊM: Khởi động session cho chức năng giỏ hàng & quản trị ===
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// === HẾT PHẦN MỚI THÊM ===
class caphe {
   public $host = "localhost";
   public $user = "root";
   public $pass = "";
   public $dbname = "coffe";      
   private $db;

   
   function __construct() {
      $this->db = new mysqli($this->host, $this->user, $this->pass, $this->dbname);
      $this->db->set_charset("utf8");
   }

   // Lấy toàn bộ danh mục -> đổ lên .category-list
   function ListDanhMuc() {
      $sql = "SELECT id_danh_muc, ten_danh_muc FROM danh_muc";
      $kq = $this->db->query($sql);
      return $kq;
   }

   // Lấy các sản phẩm nổi bật (noi_bat = 1) -> đổ lên trang chủ
   // Nếu $sosp <= 0 thì lấy toàn bộ sản phẩm nổi bật, ưu tiên sản phẩm mới nhất trước
   function SanPhamNoiBat($sosp = 0) {
      $sosp = (int)$sosp;
      $sql = "SELECT id_san_pham, ten_san_pham, hinh_anh, gia
              FROM san_pham
              WHERE noi_bat = 1
              ORDER BY id_san_pham DESC";
      if ($sosp > 0) {
         $sql .= " LIMIT 0, $sosp";
      }
      $kq = $this->db->query($sql);
      return $kq;
   }

   // Lấy danh sách sản phẩm cho trang products.php
   function ListSanPham($idDM = 0, $tukhoa = "") {    # khai báo với tham số mặc định 
       $idDM = (int)$idDM;                                // ép về số nguyên 
      $tukhoa = $this->db->real_escape_string($tukhoa);  // chống lỗi/chèn mã SQL từ ô tìm kiếm

      $sql = "SELECT id_san_pham, ten_san_pham, hinh_anh, gia
              FROM san_pham
              WHERE 1=1";
      if ($idDM > 0)       $sql .= " AND id_danh_muc = $idDM";
      if ($tukhoa != "")   $sql .= " AND ten_san_pham LIKE '%$tukhoa%'";
      $sql .= " ORDER BY id_san_pham ASC";# id tăng dần 

      $kq = $this->db->query($sql);
      return $kq;
   }


   // =====  TRANG DANH MỤC =====
   function ListDanhMucKemSoLuong() {
      $sql = "SELECT dm.id_danh_muc, dm.ten_danh_muc, COUNT(sp.id_san_pham) AS so_sp FROM danh_muc dm
              LEFT JOIN san_pham sp ON sp.id_danh_muc = dm.id_danh_muc
              GROUP BY dm.id_danh_muc, dm.ten_danh_muc
              ORDER BY dm.id_danh_muc ASC";# tăng dần 
      $kq = $this->db->query($sql);
      return $kq;
   }

   // =====  SẢN PHẨM THEO LOẠI =====
   function ChiTietDanhMuc($idDM) {
      $idDM = (int)$idDM;
      $sql = "SELECT id_danh_muc, ten_danh_muc FROM danh_muc WHERE id_danh_muc = $idDM";
      $kq = $this->db->query($sql);
      return $kq->fetch_assoc();# cần đúng 1 danh mục theo mã số 
   }

   // Lấy tất cả sản phẩm thuộc 1 danh mục
   function SanPhamTheoLoai($idDM) {
      $idDM = (int)$idDM;
      $sql = "SELECT id_san_pham, ten_san_pham, hinh_anh, gia FROM san_pham WHERE id_danh_muc = $idDM ORDER BY id_san_pham ASC";
      $kq = $this->db->query($sql);
      return $kq;
   }

   // ====== MỚI THÊM: phục vụ chức năng Chi tiết sản phẩm ======
   // Lấy đầy đủ thông tin 1 sản phẩm theo id, kèm tên danh mục (JOIN sang danh_muc)
   function ChiTietSanPham($idSP) {
      $idSP = (int)$idSP;
      $sql = "SELECT sp.id_san_pham, sp.ten_san_pham, sp.hinh_anh, sp.gia,
                     sp.mo_ta, sp.id_danh_muc, dm.ten_danh_muc
              FROM san_pham sp
              LEFT JOIN danh_muc dm ON dm.id_danh_muc = sp.id_danh_muc
              WHERE sp.id_san_pham = $idSP";
      $kq = $this->db->query($sql);
      return $kq->fetch_assoc();
   }
 
   // Lấy vài sản phẩm "liên quan" (cùng danh mục, trừ sản phẩm đang xem) -> gợi ý cuối trang chi tiết
   function SanPhamLienQuan($idDM, $idSPHienTai, $soluong = 3) {
      $idDM = (int)$idDM;
      $idSPHienTai = (int)$idSPHienTai;
      $soluong = (int)$soluong;
      $sql = "SELECT id_san_pham, ten_san_pham, hinh_anh, gia
              FROM san_pham
              WHERE id_danh_muc = $idDM AND id_san_pham != $idSPHienTai
              ORDER BY id_san_pham ASC
              LIMIT 0, $soluong";
      $kq = $this->db->query($sql);
      return $kq;
   }
   // ====== HẾT PHẦN MỚI THÊM ======
   
   // === MỚI THÊM: Đếm tổng số lượng sản phẩm đang có trong giỏ hàng ===
   function TongSoLuongGioHang() {
      if (!isset($_SESSION['giohang']) || empty($_SESSION['giohang'])) {
         return 0;
      }
      $tong = 0;
      foreach ($_SESSION['giohang'] as $item) {
         $tong += $item['so_luong'];
      }
      return $tong;
   }
   // === HẾT PHẦN MỚI THÊM ===

   // Định dạng giá: 25000.00 -> 25.000đ
   function DinhDangGia($gia) {
      return number_format($gia, 0, ",", ".") . "đ";
   }

   // === MỚI THÊM: Chức năng Đăng ký & Đăng nhập ===
   function DangKy($ho_ten, $email, $dien_thoai, $mat_khau) {
      // 1. Kiểm tra email đã tồn tại chưa
      $stmt = $this->db->prepare("SELECT id_nguoi_dung FROM nguoi_dung WHERE email = ?");
      $stmt->bind_param("s", $email);
      $stmt->execute();
      $stmt->store_result();
      if ($stmt->num_rows > 0) {
         $stmt->close();
         return "Email này đã được đăng ký. Vui lòng sử dụng email khác!";
      }
      $stmt->close();

      // 2. Mã hóa mật khẩu và lưu vào bảng nguoi_dung
      $mat_khau_ma_hoa = password_hash($mat_khau, PASSWORD_DEFAULT);
      $stmt = $this->db->prepare("INSERT INTO nguoi_dung (ho_ten, email, dien_thoai, mat_khau) VALUES (?, ?, ?, ?)");
      $stmt->bind_param("ssss", $ho_ten, $email, $dien_thoai, $mat_khau_ma_hoa);
      $ok = $stmt->execute();
      $stmt->close();

      return $ok ? true : "Có lỗi xảy ra khi đăng ký, vui lòng thử lại!";
   }

   // Kiểm tra thêm cột trang_thai = 1 để chặn tài khoản khách bị Admin khóa
   function DangNhap($email, $mat_khau) {
      $stmt = $this->db->prepare("SELECT id_nguoi_dung, ho_ten, email, dien_thoai, mat_khau, trang_thai FROM nguoi_dung WHERE email = ?");
      $stmt->bind_param("s", $email);
      $stmt->execute();
      $kq = $stmt->get_result();
      $user = $kq->fetch_assoc();
      $stmt->close();

      if ($user && password_verify($mat_khau, $user['mat_khau'])) {
         // Nếu tài khoản đã bị Admin khóa (trang_thai = 0) thì không cho đăng nhập
         if (isset($user['trang_thai']) && (int)$user['trang_thai'] === 0) {
            return false;
         }
         unset($user['mat_khau']); // Không lưu chuỗi mật khẩu vào Session
         return $user;
      }
      return false;
   }

   // =========================================================================
   // === QUẢN LÝ ĐƠN HÀNG & XÁC THỰC ADMIN / THU NGÂN ===
   // =========================================================================

   // 1. Lưu đơn hàng mới từ Giỏ hàng hoặc Quầy thu ngân vào Database
   function DatHang($id_nguoi_dung, $ten_khach_hang, $so_dien_thoai, $dia_chi, $ghi_chu, $giohang, $trang_thai = 'cho_xac_nhan') {
      if (empty($giohang)) {
         return false;
      }

      $tong_tien = 0;
      foreach ($giohang as $item) {
         $tong_tien += $item['gia'] * $item['so_luong'];
      }

      $this->db->begin_transaction();
      try {
         // Thêm vào bảng don_hang
         $stmt = $this->db->prepare(
            "INSERT INTO don_hang (id_nguoi_dung, ten_khach_hang, so_dien_thoai, dia_chi, ghi_chu, tong_tien, trang_thai)
             VALUES (?, ?, ?, ?, ?, ?, ?)"
         );
         $stmt->bind_param("issssds", $id_nguoi_dung, $ten_khach_hang, $so_dien_thoai, $dia_chi, $ghi_chu, $tong_tien, $trang_thai);
         $stmt->execute();
         $id_don_hang = $this->db->insert_id;
         $stmt->close();

         // Thêm từng món vào bảng chi_tiet_don_hang
         $stmt_ct = $this->db->prepare(
            "INSERT INTO chi_tiet_don_hang (id_don_hang, id_san_pham, ten_san_pham, so_luong, don_gia)
             VALUES (?, ?, ?, ?, ?)"
         );
         foreach ($giohang as $item) {
            $id_sp  = (int)$item['id_san_pham'];
            $ten_sp = $item['ten_san_pham'];
            $sl     = (int)$item['so_luong'];
            $gia    = (float)$item['gia'];
            $stmt_ct->bind_param("iisid", $id_don_hang, $id_sp, $ten_sp, $sl, $gia);
            $stmt_ct->execute();
         }
         $stmt_ct->close();

         $this->db->commit();
         return $id_don_hang;
      } catch (Throwable $e) {
         $this->db->rollback();
         return false;
      }
   }

   // === SỬA ĐỔI: Đăng nhập dành riêng cho Admin & Thu ngân (kiểm tra thêm trang_thai = 1) ===
   function DangNhapAdmin($email, $mat_khau) {
      $stmt = $this->db->prepare(
         "SELECT id_nguoi_dung, ho_ten, email, dien_thoai, mat_khau, vai_tro, trang_thai
          FROM nguoi_dung
          WHERE email = ? AND vai_tro IN ('admin', 'thu_ngan')"
      );
      $stmt->bind_param("s", $email);
      $stmt->execute();
      $kq = $stmt->get_result();
      $admin = $kq->fetch_assoc();
      $stmt->close();

      if ($admin && password_verify($mat_khau, $admin['mat_khau'])) {
         // Chặn đăng nhập nếu tài khoản nhân viên đã bị Admin khóa
         if (isset($admin['trang_thai']) && (int)$admin['trang_thai'] === 0) {
            return false;
         }
         unset($admin['mat_khau']);
         return $admin;
      }
      return false;
   }

   // === MỚI THÊM: Kiểm tra lại phiên làm việc của Admin/Nhân viên theo thời gian thực ===
   function KiemTraPhienAdmin($id_nguoi_dung) {
      $id_nguoi_dung = (int)$id_nguoi_dung;
      $stmt = $this->db->prepare(
         "SELECT id_nguoi_dung, ho_ten, email, vai_tro, trang_thai
          FROM nguoi_dung
          WHERE id_nguoi_dung = ? AND vai_tro IN ('admin', 'thu_ngan')"
      );
      $stmt->bind_param("i", $id_nguoi_dung);
      $stmt->execute();
      $kq = $stmt->get_result();
      $row = $kq->fetch_assoc();
      $stmt->close();
      return $row;
   }
   // === HẾT PHẦN SỬA ĐỔI ===

   // 3. Thống kê nhanh số lượng đơn theo trạng thái và doanh thu hoàn thành
   function ThongKeDonHang() {
      $sql = "SELECT
                COUNT(*) AS tong_don,
                SUM(CASE WHEN trang_thai = 'cho_xac_nhan' THEN 1 ELSE 0 END) AS cho_xac_nhan,
                SUM(CASE WHEN trang_thai = 'dang_pha_che' THEN 1 ELSE 0 END) AS dang_pha_che,
                SUM(CASE WHEN trang_thai = 'hoan_thanh'   THEN 1 ELSE 0 END) AS hoan_thanh,
                SUM(CASE WHEN trang_thai = 'da_huy'       THEN 1 ELSE 0 END) AS da_huy,
                COALESCE(SUM(CASE WHEN trang_thai = 'hoan_thanh' THEN tong_tien ELSE 0 END), 0) AS doanh_thu
              FROM don_hang";
      $kq = $this->db->query($sql);
      return $kq->fetch_assoc();
   }

   // 4. Lấy danh sách đơn hàng (có lọc theo trạng thái và tìm kiếm mã đơn / tên / SĐT)
   function ListDonHang($trang_thai = "", $tukhoa = "") {
      $ds_trang_thai_hop_le = ['cho_xac_nhan', 'dang_pha_che', 'hoan_thanh', 'da_huy'];
      $tukhoa_safe = $this->db->real_escape_string(trim($tukhoa));

      $sql = "SELECT dh.*, nd.email AS email_tai_khoan
              FROM don_hang dh
              LEFT JOIN nguoi_dung nd ON nd.id_nguoi_dung = dh.id_nguoi_dung
              WHERE 1=1";

      if (in_array($trang_thai, $ds_trang_thai_hop_le)) {
         $sql .= " AND dh.trang_thai = '$trang_thai'";
      }

      if ($tukhoa_safe !== "") {
         $id_tim = (int)str_replace('#', '', $tukhoa_safe);
         $sql .= " AND (dh.id_don_hang = $id_tim
                        OR dh.ten_khach_hang LIKE '%$tukhoa_safe%'
                        OR dh.so_dien_thoai LIKE '%$tukhoa_safe%')";
      }

      $sql .= " ORDER BY dh.ngay_dat DESC, dh.id_don_hang DESC";
      return $this->db->query($sql);
   }

   // 5. Lấy thông tin 1 đơn hàng cụ thể
   function ChiTietDonHang($id_don_hang) {
      $id_don_hang = (int)$id_don_hang;
      $sql = "SELECT dh.*, nd.email AS email_tai_khoan
              FROM don_hang dh
              LEFT JOIN nguoi_dung nd ON nd.id_nguoi_dung = dh.id_nguoi_dung
              WHERE dh.id_don_hang = $id_don_hang";
      $kq = $this->db->query($sql);
      return $kq->fetch_assoc();
   }

   // 6. Lấy danh sách các món nằm trong 1 đơn hàng
   function ListSanPhamTrongDon($id_don_hang) {
      $id_don_hang = (int)$id_don_hang;
      $sql = "SELECT ct.*, sp.hinh_anh
              FROM chi_tiet_don_hang ct
              LEFT JOIN san_pham sp ON sp.id_san_pham = ct.id_san_pham
              WHERE ct.id_don_hang = $id_don_hang
              ORDER BY ct.id_ctdh ASC";
      return $this->db->query($sql);
   }

   // 7. Cập nhật trạng thái đơn hàng
   function CapNhatTrangThaiDonHang($id_don_hang, $trang_thai) {
      $ds_hop_le = ['cho_xac_nhan', 'dang_pha_che', 'hoan_thanh', 'da_huy'];
      if (!in_array($trang_thai, $ds_hop_le)) {
         return false;
      }
      $stmt = $this->db->prepare("UPDATE don_hang SET trang_thai = ? WHERE id_don_hang = ?");
      $stmt->bind_param("si", $trang_thai, $id_don_hang);
      $ok = $stmt->execute();
      $stmt->close();
      return $ok;
   }

   // 8. Xóa đơn hàng (chỉ dành cho Admin)
   function XoaDonHang($id_don_hang) {
      $stmt = $this->db->prepare("DELETE FROM don_hang WHERE id_don_hang = ?");
      $stmt->bind_param("i", $id_don_hang);
      $ok = $stmt->execute();
      $stmt->close();
      return $ok;
   }

   // 9. Lấy toàn bộ menu sản phẩm phục vụ Thu ngân tạo đơn tại quầy
   function ListTatCaSanPham() {
      $sql = "SELECT sp.id_san_pham, sp.ten_san_pham, sp.gia, sp.hinh_anh, dm.ten_danh_muc
              FROM san_pham sp
              LEFT JOIN danh_muc dm ON dm.id_danh_muc = sp.id_danh_muc
              ORDER BY dm.id_danh_muc ASC, sp.ten_san_pham ASC";
      return $this->db->query($sql);
   }
   // =========================================================================
   // === HẾT PHẦN QUẢN LÝ ĐƠN HÀNG ===
   // =========================================================================

   // =========================================================================
   // === CHỨC NĂNG QUẢN LÝ KHÁCH HÀNG ADMIN ===
   // =========================================================================

   // 1. Thống kê tổng quan khách hàng
   function ThongKeKhachHang() {
      $sql = "SELECT
                COUNT(DISTINCT nd.id_nguoi_dung) AS tong_khach,
                COUNT(DISTINCT CASE WHEN nd.trang_thai = 1 THEN nd.id_nguoi_dung END) AS dang_hoat_dong,
                COUNT(DISTINCT CASE WHEN nd.trang_thai = 0 THEN nd.id_nguoi_dung END) AS bi_khoa,
                COUNT(DISTINCT dh.id_nguoi_dung) AS da_dat_hang
              FROM nguoi_dung nd
              LEFT JOIN don_hang dh ON dh.id_nguoi_dung = nd.id_nguoi_dung
              WHERE nd.vai_tro = 'khach_hang'";
      $kq = $this->db->query($sql);
      return $kq->fetch_assoc();
   }

   // 2. Lấy danh sách khách hàng (có lọc trạng thái và tìm kiếm theo mã / tên / email / SĐT)
   function ListKhachHang($trang_thai = "", $tukhoa = "") {
      $tukhoa_safe = $this->db->real_escape_string(trim($tukhoa));

      $sql = "SELECT nd.id_nguoi_dung, nd.ho_ten, nd.email, nd.dien_thoai,
                     nd.trang_thai, nd.ngay_tao,
                     COUNT(dh.id_don_hang) AS tong_don,
                     COALESCE(SUM(CASE WHEN dh.trang_thai = 'hoan_thanh' THEN dh.tong_tien ELSE 0 END), 0) AS tong_chi_tieu
              FROM nguoi_dung nd
              LEFT JOIN don_hang dh ON dh.id_nguoi_dung = nd.id_nguoi_dung
              WHERE nd.vai_tro = 'khach_hang'";

      if ($trang_thai === '1' || $trang_thai === '0') {
         $tt = (int)$trang_thai;
         $sql .= " AND nd.trang_thai = $tt";
      }

      if ($tukhoa_safe !== "") {
         $id_tim = (int)str_replace('#', '', $tukhoa_safe);
         $sql .= " AND (nd.id_nguoi_dung = $id_tim
                        OR nd.ho_ten LIKE '%$tukhoa_safe%'
                        OR nd.email LIKE '%$tukhoa_safe%'
                        OR nd.dien_thoai LIKE '%$tukhoa_safe%')";
      }

      $sql .= " GROUP BY nd.id_nguoi_dung, nd.ho_ten, nd.email, nd.dien_thoai, nd.trang_thai, nd.ngay_tao
                ORDER BY nd.id_nguoi_dung DESC";
      return $this->db->query($sql);
   }

   // 3. Lấy thông tin chi tiết 1 khách hàng kèm thống kê mua hàng
   function ChiTietKhachHang($id_khach_hang) {
      $id_khach_hang = (int)$id_khach_hang;
      $sql = "SELECT nd.id_nguoi_dung, nd.ho_ten, nd.email, nd.dien_thoai,
                     nd.trang_thai, nd.ngay_tao,
                     COUNT(dh.id_don_hang) AS tong_don,
                     SUM(CASE WHEN dh.trang_thai = 'hoan_thanh' THEN 1 ELSE 0 END) AS don_hoan_thanh,
                     COALESCE(SUM(CASE WHEN dh.trang_thai = 'hoan_thanh' THEN dh.tong_tien ELSE 0 END), 0) AS tong_chi_tieu
              FROM nguoi_dung nd
              LEFT JOIN don_hang dh ON dh.id_nguoi_dung = nd.id_nguoi_dung
              WHERE nd.id_nguoi_dung = $id_khach_hang AND nd.vai_tro = 'khach_hang'
              GROUP BY nd.id_nguoi_dung, nd.ho_ten, nd.email, nd.dien_thoai, nd.trang_thai, nd.ngay_tao";
      $kq = $this->db->query($sql);
      return $kq->fetch_assoc();
   }

   // 4. Lấy lịch sử đơn hàng của một khách hàng cụ thể
   function ListDonHangCuaKhach($id_khach_hang) {
      $id_khach_hang = (int)$id_khach_hang;
      $sql = "SELECT id_don_hang, ten_khach_hang, so_dien_thoai, dia_chi, tong_tien, trang_thai, ngay_dat
              FROM don_hang
              WHERE id_nguoi_dung = $id_khach_hang
              ORDER BY ngay_dat DESC, id_don_hang DESC";
      return $this->db->query($sql);
   }

   // 5. Cập nhật thông tin hồ sơ khách hàng (và đặt lại mật khẩu nếu Admin có nhập)
   function CapNhatKhachHang($id_khach_hang, $ho_ten, $email, $dien_thoai, $trang_thai, $mat_khau_moi = "") {
      $id_khach_hang = (int)$id_khach_hang;
      $trang_thai = ((int)$trang_thai === 1) ? 1 : 0;

      // Kiểm tra email có bị trùng với tài khoản khác không
      $stmt = $this->db->prepare("SELECT id_nguoi_dung FROM nguoi_dung WHERE email = ? AND id_nguoi_dung != ?");
      $stmt->bind_param("si", $email, $id_khach_hang);
      $stmt->execute();
      $stmt->store_result();
      if ($stmt->num_rows > 0) {
         $stmt->close();
         return "Email này đã được sử dụng bởi một tài khoản khác!";
      }
      $stmt->close();

      if ($mat_khau_moi !== "") {
         $mat_khau_ma_hoa = password_hash($mat_khau_moi, PASSWORD_DEFAULT);
         $stmt = $this->db->prepare(
            "UPDATE nguoi_dung
             SET ho_ten = ?, email = ?, dien_thoai = ?, trang_thai = ?, mat_khau = ?
             WHERE id_nguoi_dung = ? AND vai_tro = 'khach_hang'"
         );
         $stmt->bind_param("sssisi", $ho_ten, $email, $dien_thoai, $trang_thai, $mat_khau_ma_hoa, $id_khach_hang);
      } else {
         $stmt = $this->db->prepare(
            "UPDATE nguoi_dung
             SET ho_ten = ?, email = ?, dien_thoai = ?, trang_thai = ?
             WHERE id_nguoi_dung = ? AND vai_tro = 'khach_hang'"
         );
         $stmt->bind_param("sssii", $ho_ten, $email, $dien_thoai, $trang_thai, $id_khach_hang);
      }

      $ok = $stmt->execute();
      $stmt->close();
      return $ok ? true : "Có lỗi xảy ra khi cập nhật thông tin khách hàng!";
   }

   // 6. Khóa hoặc mở khóa nhanh tài khoản khách hàng
   function DoiTrangThaiKhachHang($id_khach_hang, $trang_thai) {
      $id_khach_hang = (int)$id_khach_hang;
      $trang_thai = ((int)$trang_thai === 1) ? 1 : 0;
      $stmt = $this->db->prepare(
         "UPDATE nguoi_dung SET trang_thai = ? WHERE id_nguoi_dung = ? AND vai_tro = 'khach_hang'"
      );
      $stmt->bind_param("ii", $trang_thai, $id_khach_hang);
      $ok = $stmt->execute();
      $stmt->close();
      return $ok;
   }

   // 7. Xóa tài khoản khách hàng (đơn hàng cũ vẫn giữ nguyên nhờ ON DELETE SET NULL)
   function XoaKhachHang($id_khach_hang) {
      $id_khach_hang = (int)$id_khach_hang;
      $stmt = $this->db->prepare("DELETE FROM nguoi_dung WHERE id_nguoi_dung = ? AND vai_tro = 'khach_hang'");
      $stmt->bind_param("i", $id_khach_hang);
      $ok = $stmt->execute();
      $stmt->close();
      return $ok;
   }
   // =========================================================================
   // === HẾT PHẦN QUẢN LÝ KHÁCH HÀNG ADMIN ===
   // =========================================================================

   // =========================================================================
   // === MỚI THÊM: CHỨC NĂNG QUẢN LÝ NHÂN VIÊN ADMIN ===
   // =========================================================================

   // 1. Thống kê tổng quan đội ngũ nhân viên & quản trị viên
   function ThongKeNhanVien() {
      $sql = "SELECT
                COUNT(*) AS tong_nv,
                SUM(CASE WHEN vai_tro = 'admin'    THEN 1 ELSE 0 END) AS so_admin,
                SUM(CASE WHEN vai_tro = 'thu_ngan' THEN 1 ELSE 0 END) AS so_thu_ngan,
                SUM(CASE WHEN trang_thai = 1       THEN 1 ELSE 0 END) AS dang_hoat_dong,
                SUM(CASE WHEN trang_thai = 0       THEN 1 ELSE 0 END) AS bi_khoa
              FROM nguoi_dung
              WHERE vai_tro IN ('admin', 'thu_ngan')";
      $kq = $this->db->query($sql);
      return $kq->fetch_assoc();
   }

   // 2. Lấy danh sách nhân viên (lọc theo vai trò, trạng thái và tìm kiếm từ khóa)
   function ListNhanVien($vai_tro = "", $trang_thai = "", $tukhoa = "") {
      $tukhoa_safe = $this->db->real_escape_string(trim($tukhoa));

      $sql = "SELECT id_nguoi_dung, ho_ten, email, dien_thoai, vai_tro, trang_thai, ngay_tao
              FROM nguoi_dung
              WHERE vai_tro IN ('admin', 'thu_ngan')";

      if (in_array($vai_tro, ['admin', 'thu_ngan'])) {
         $sql .= " AND vai_tro = '$vai_tro'";
      }

      if ($trang_thai === '1' || $trang_thai === '0') {
         $tt = (int)$trang_thai;
         $sql .= " AND trang_thai = $tt";
      }

      if ($tukhoa_safe !== "") {
         $id_tim = (int)str_replace('#', '', $tukhoa_safe);
         $sql .= " AND (id_nguoi_dung = $id_tim
                        OR ho_ten LIKE '%$tukhoa_safe%'
                        OR email LIKE '%$tukhoa_safe%'
                        OR dien_thoai LIKE '%$tukhoa_safe%')";
      }

      $sql .= " ORDER BY FIELD(vai_tro, 'admin', 'thu_ngan'), id_nguoi_dung DESC";
      return $this->db->query($sql);
   }

   // 3. Lấy thông tin chi tiết 1 nhân viên
   function ChiTietNhanVien($id_nv) {
      $id_nv = (int)$id_nv;
      $sql = "SELECT id_nguoi_dung, ho_ten, email, dien_thoai, vai_tro, trang_thai, ngay_tao
              FROM nguoi_dung
              WHERE id_nguoi_dung = $id_nv AND vai_tro IN ('admin', 'thu_ngan')";
      $kq = $this->db->query($sql);
      return $kq->fetch_assoc();
   }

   // 4. Đếm số lượng Quản trị viên (admin) đang hoạt động (tránh khóa/xóa nhầm admin cuối cùng)
   function DemSoAdminHoatDong() {
      $sql = "SELECT COUNT(*) AS tong FROM nguoi_dung WHERE vai_tro = 'admin' AND trang_thai = 1";
      $kq = $this->db->query($sql);
      $row = $kq->fetch_assoc();
      return (int)($row['tong'] ?? 0);
   }

   // 5. Thêm tài khoản nhân viên / quản trị viên mới
   function ThemNhanVien($ho_ten, $email, $dien_thoai, $mat_khau, $vai_tro, $trang_thai = 1) {
      if (!in_array($vai_tro, ['admin', 'thu_ngan'])) {
         return "Vai trò nhân viên không hợp lệ!";
      }
      $trang_thai = ((int)$trang_thai === 1) ? 1 : 0;

      // Kiểm tra email đã tồn tại trong bảng nguoi_dung chưa
      $stmt = $this->db->prepare("SELECT id_nguoi_dung FROM nguoi_dung WHERE email = ?");
      $stmt->bind_param("s", $email);
      $stmt->execute();
      $stmt->store_result();
      if ($stmt->num_rows > 0) {
         $stmt->close();
         return "Email này đã tồn tại trên hệ thống! Vui lòng dùng email khác.";
      }
      $stmt->close();

      $mat_khau_ma_hoa = password_hash($mat_khau, PASSWORD_DEFAULT);
      $stmt = $this->db->prepare(
         "INSERT INTO nguoi_dung (ho_ten, email, dien_thoai, mat_khau, vai_tro, trang_thai)
          VALUES (?, ?, ?, ?, ?, ?)"
      );
      $stmt->bind_param("sssssi", $ho_ten, $email, $dien_thoai, $mat_khau_ma_hoa, $vai_tro, $trang_thai);
      $ok = $stmt->execute();
      $stmt->close();

      return $ok ? true : "Có lỗi xảy ra khi tạo tài khoản nhân viên!";
   }

   // 6. Cập nhật thông tin hồ sơ, phân quyền & mật khẩu nhân viên
   function CapNhatNhanVien($id_nv, $ho_ten, $email, $dien_thoai, $vai_tro, $trang_thai, $mat_khau_moi = "") {
      $id_nv = (int)$id_nv;
      if (!in_array($vai_tro, ['admin', 'thu_ngan'])) {
         return "Vai trò nhân viên không hợp lệ!";
      }
      $trang_thai = ((int)$trang_thai === 1) ? 1 : 0;

      // Kiểm tra trùng email với tài khoản khác
      $stmt = $this->db->prepare("SELECT id_nguoi_dung FROM nguoi_dung WHERE email = ? AND id_nguoi_dung != ?");
      $stmt->bind_param("si", $email, $id_nv);
      $stmt->execute();
      $stmt->store_result();
      if ($stmt->num_rows > 0) {
         $stmt->close();
         return "Email này đã được sử dụng bởi một tài khoản khác!";
      }
      $stmt->close();

      if ($mat_khau_moi !== "") {
         $mat_khau_ma_hoa = password_hash($mat_khau_moi, PASSWORD_DEFAULT);
         $stmt = $this->db->prepare(
            "UPDATE nguoi_dung
             SET ho_ten = ?, email = ?, dien_thoai = ?, vai_tro = ?, trang_thai = ?, mat_khau = ?
             WHERE id_nguoi_dung = ? AND vai_tro IN ('admin', 'thu_ngan')"
         );
         $stmt->bind_param("ssssisi", $ho_ten, $email, $dien_thoai, $vai_tro, $trang_thai, $mat_khau_ma_hoa, $id_nv);
      } else {
         $stmt = $this->db->prepare(
            "UPDATE nguoi_dung
             SET ho_ten = ?, email = ?, dien_thoai = ?, vai_tro = ?, trang_thai = ?
             WHERE id_nguoi_dung = ? AND vai_tro IN ('admin', 'thu_ngan')"
         );
         $stmt->bind_param("ssssii", $ho_ten, $email, $dien_thoai, $vai_tro, $trang_thai, $id_nv);
      }

      $ok = $stmt->execute();
      $stmt->close();
      return $ok ? true : "Có lỗi xảy ra khi cập nhật thông tin nhân viên!";
   }

   // 7. Khóa hoặc mở khóa nhanh tài khoản nhân viên
   function DoiTrangThaiNhanVien($id_nv, $trang_thai) {
      $id_nv = (int)$id_nv;
      $trang_thai = ((int)$trang_thai === 1) ? 1 : 0;
      $stmt = $this->db->prepare(
         "UPDATE nguoi_dung SET trang_thai = ? WHERE id_nguoi_dung = ? AND vai_tro IN ('admin', 'thu_ngan')"
      );
      $stmt->bind_param("ii", $trang_thai, $id_nv);
      $ok = $stmt->execute();
      $stmt->close();
      return $ok;
   }

   // 8. Xóa tài khoản nhân viên
   function XoaNhanVien($id_nv) {
      $id_nv = (int)$id_nv;
      $stmt = $this->db->prepare("DELETE FROM nguoi_dung WHERE id_nguoi_dung = ? AND vai_tro IN ('admin', 'thu_ngan')");
      $stmt->bind_param("i", $id_nv);
      $ok = $stmt->execute();
      $stmt->close();
      return $ok;
   }
   // =========================================================================
   // === HẾT PHẦN QUẢN LÝ NHÂN VIÊN ADMIN ===
   // =========================================================================
   // =========================================================================
   // === MỚI THÊM: CÁC HÀM THỐNG KÊ CHO TRANG TỔNG QUAN (DASHBOARD) ADMIN ===
   // =========================================================================

   // 1. Lấy các chỉ số KPI tổng quan (đơn hàng, doanh thu, khách hàng, nhân viên, thực đơn)
   function ThongKeTongQuanDashboard() {
      $sql_don = "SELECT
                    COUNT(*) AS tong_don,
                    SUM(CASE WHEN trang_thai = 'cho_xac_nhan' THEN 1 ELSE 0 END) AS cho_xac_nhan,
                    SUM(CASE WHEN trang_thai = 'dang_pha_che' THEN 1 ELSE 0 END) AS dang_pha_che,
                    SUM(CASE WHEN trang_thai = 'hoan_thanh'   THEN 1 ELSE 0 END) AS hoan_thanh,
                    SUM(CASE WHEN trang_thai = 'da_huy'       THEN 1 ELSE 0 END) AS da_huy,
                    COALESCE(SUM(CASE WHEN trang_thai = 'hoan_thanh' THEN tong_tien ELSE 0 END), 0) AS tong_doanh_thu,
                    COALESCE(SUM(CASE WHEN trang_thai = 'hoan_thanh' AND DATE(ngay_dat) = CURDATE() THEN tong_tien ELSE 0 END), 0) AS doanh_thu_hom_nay
                  FROM don_hang";
      $kq_don = $this->db->query($sql_don)->fetch_assoc();

      $sql_user = "SELECT
                     SUM(CASE WHEN vai_tro = 'khach_hang' THEN 1 ELSE 0 END) AS tong_khach_hang,
                     SUM(CASE WHEN vai_tro IN ('admin', 'thu_ngan') THEN 1 ELSE 0 END) AS tong_nhan_vien
                   FROM nguoi_dung";
      $kq_user = $this->db->query($sql_user)->fetch_assoc();

      $sql_sp = "SELECT
                   (SELECT COUNT(*) FROM san_pham) AS tong_san_pham,
                   (SELECT COUNT(*) FROM danh_muc) AS tong_danh_muc";
      $kq_sp = $this->db->query($sql_sp)->fetch_assoc();

      return array_merge($kq_don, $kq_user, $kq_sp);
   }

   // 2. Lấy doanh thu 7 ngày gần nhất (tự điền 0đ cho ngày không phát sinh đơn)
   function DoanhThu7NgayGanNhat() {
      $sql = "SELECT DATE(ngay_dat) AS ngay,
                     COUNT(*) AS so_don,
                     COALESCE(SUM(tong_tien), 0) AS doanh_thu
              FROM don_hang
              WHERE trang_thai = 'hoan_thanh'
                AND DATE(ngay_dat) >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
              GROUP BY DATE(ngay_dat)";
      $kq = $this->db->query($sql);

      $map_ngay = [];
      while ($row = $kq->fetch_assoc()) {
         $map_ngay[$row['ngay']] = $row;
      }

      $ket_qua = [];
      for ($i = 6; $i >= 0; $i--) {
         $ts  = strtotime("-$i days");
         $key = date('Y-m-d', $ts);
         $ket_qua[] = [
            'ngay'          => $key,
            'ngay_hien_thi' => date('d/m', $ts),
            'so_don'        => isset($map_ngay[$key]) ? (int)$map_ngay[$key]['so_don'] : 0,
            'doanh_thu'     => isset($map_ngay[$key]) ? (float)$map_ngay[$key]['doanh_thu'] : 0
         ];
      }
      return $ket_qua;
   }

   // 3. Lấy top món bán chạy nhất (loại trừ đơn đã hủy)
   function TopSanPhamBanChay($limit = 5) {
      $limit = (int)$limit;
      $sql = "SELECT ct.ten_san_pham,
                     SUM(ct.so_luong) AS tong_ly,
                     SUM(ct.so_luong * ct.don_gia) AS tong_tien_mon
              FROM chi_tiet_don_hang ct
              INNER JOIN don_hang dh ON dh.id_don_hang = ct.id_don_hang
              WHERE dh.trang_thai != 'da_huy'
              GROUP BY ct.id_san_pham, ct.ten_san_pham
              ORDER BY tong_ly DESC, tong_tien_mon DESC
              LIMIT 0, $limit";
      return $this->db->query($sql);
   }

   // 4. Lấy danh sách đơn hàng mới nhất hiển thị nhanh trên Dashboard
   function DonHangMoiNhat($limit = 6) {
      $limit = (int)$limit;
      $sql = "SELECT id_don_hang, ten_khach_hang, tong_tien, trang_thai, ngay_dat
              FROM don_hang
              ORDER BY ngay_dat DESC, id_don_hang DESC
              LIMIT 0, $limit";
      return $this->db->query($sql);
   }
   // =========================================================================
   // === HẾT PHẦN THỐNG KÊ DASHBOARD ADMIN ===
   // =========================================================================
   // =========================================================================
   // === MỚI THÊM: CHỨC NĂNG QUẢN LÝ DANH MỤC (ADMIN) ===
   // =========================================================================

   // 1. Thống kê KPI danh mục
   function ThongKeDanhMucAdmin() {
      $sql = "SELECT
                COUNT(DISTINCT dm.id_danh_muc) AS tong_danh_muc,
                COUNT(DISTINCT CASE WHEN sp.id_san_pham IS NOT NULL THEN dm.id_danh_muc END) AS dm_co_mon,
                COUNT(DISTINCT CASE WHEN sp.id_san_pham IS NULL THEN dm.id_danh_muc END) AS dm_trong,
                COUNT(sp.id_san_pham) AS tong_san_pham
              FROM danh_muc dm
              LEFT JOIN san_pham sp ON sp.id_danh_muc = dm.id_danh_muc";
      $kq = $this->db->query($sql);
      return $kq->fetch_assoc();
   }

   // 2. Lấy danh sách danh mục kèm số lượng sản phẩm và hỗ trợ tìm kiếm
   function ListDanhMucAdmin($tukhoa = "") {
      $tukhoa_safe = $this->db->real_escape_string(trim($tukhoa));
      $sql = "SELECT dm.id_danh_muc, dm.ten_danh_muc, COUNT(sp.id_san_pham) AS so_sp
              FROM danh_muc dm
              LEFT JOIN san_pham sp ON sp.id_danh_muc = dm.id_danh_muc
              WHERE 1=1";

      if ($tukhoa_safe !== "") {
         $id_tim = (int)str_replace('#', '', $tukhoa_safe);
         $sql .= " AND (dm.id_danh_muc = $id_tim OR dm.ten_danh_muc LIKE '%$tukhoa_safe%')";
      }

      $sql .= " GROUP BY dm.id_danh_muc, dm.ten_danh_muc
                ORDER BY dm.id_danh_muc ASC";
      return $this->db->query($sql);
   }

   // 3. Thêm danh mục mới (kiểm tra trùng tên)
   function ThemDanhMuc($ten_danh_muc) {
      $stmt = $this->db->prepare("SELECT id_danh_muc FROM danh_muc WHERE LOWER(ten_danh_muc) = LOWER(?)");
      $stmt->bind_param("s", $ten_danh_muc);
      $stmt->execute();
      $stmt->store_result();
      if ($stmt->num_rows > 0) {
         $stmt->close();
         return "Tên danh mục \"$ten_danh_muc\" đã tồn tại!";
      }
      $stmt->close();

      $stmt = $this->db->prepare("INSERT INTO danh_muc (ten_danh_muc) VALUES (?)");
      $stmt->bind_param("s", $ten_danh_muc);
      $ok = $stmt->execute();
      $stmt->close();

      return $ok ? true : "Có lỗi xảy ra khi thêm danh mục mới!";
   }

   // 4. Cập nhật tên danh mục (kiểm tra trùng tên với danh mục khác)
   function CapNhatDanhMuc($id_danh_muc, $ten_danh_muc) {
      $id_danh_muc = (int)$id_danh_muc;
      $stmt = $this->db->prepare("SELECT id_danh_muc FROM danh_muc WHERE LOWER(ten_danh_muc) = LOWER(?) AND id_danh_muc != ?");
      $stmt->bind_param("si", $ten_danh_muc, $id_danh_muc);
      $stmt->execute();
      $stmt->store_result();
      if ($stmt->num_rows > 0) {
         $stmt->close();
         return "Tên danh mục \"$ten_danh_muc\" đã được sử dụng!";
      }
      $stmt->close();

      $stmt = $this->db->prepare("UPDATE danh_muc SET ten_danh_muc = ? WHERE id_danh_muc = ?");
      $stmt->bind_param("si", $ten_danh_muc, $id_danh_muc);
      $ok = $stmt->execute();
      $stmt->close();

      return $ok ? true : "Có lỗi xảy ra khi cập nhật danh mục!";
   }

   // 5. Xóa danh mục (chặn xóa nếu còn sản phẩm liên kết)
   function XoaDanhMuc($id_danh_muc) {
      $id_danh_muc = (int)$id_danh_muc;
      $stmt = $this->db->prepare("SELECT COUNT(*) AS tong FROM san_pham WHERE id_danh_muc = ?");
      $stmt->bind_param("i", $id_danh_muc);
      $stmt->execute();
      $row = $stmt->get_result()->fetch_assoc();
      $stmt->close();

      if ((int)($row['tong'] ?? 0) > 0) {
         return "Không thể xóa vì danh mục này đang có " . $row['tong'] . " sản phẩm!";
      }

      $stmt = $this->db->prepare("DELETE FROM danh_muc WHERE id_danh_muc = ?");
      $stmt->bind_param("i", $id_danh_muc);
      $ok = $stmt->execute();
      $stmt->close();

      return $ok ? true : "Có lỗi xảy ra khi xóa danh mục!";
   }
   // =========================================================================
   // === HẾT PHẦN QUẢN LÝ DANH MỤC (ADMIN) ===
   // =========================================================================
   // =========================================================================
   // === MỚI THÊM: CHỨC NĂNG QUẢN LÝ SẢN PHẨM (ADMIN) ===
   // =========================================================================

   // 1. Thống kê KPI thực đơn sản phẩm
   function ThongKeSanPhamAdmin() {
      $sql = "SELECT
                COUNT(*) AS tong_sp,
                SUM(CASE WHEN noi_bat = 1 THEN 1 ELSE 0 END) AS sp_noi_bat,
                COALESCE(AVG(gia), 0) AS gia_trung_binh,
                COALESCE(MIN(gia), 0) AS gia_thap_nhat,
                COALESCE(MAX(gia), 0) AS gia_cao_nhat
              FROM san_pham";
      $kq = $this->db->query($sql);
      return $kq->fetch_assoc();
   }

   // 2. Lấy danh sách sản phẩm cho trang Admin (lọc theo danh mục, nổi bật, từ khóa)
   function ListSanPhamAdmin($id_dm = 0, $noi_bat = "", $tukhoa = "") {
      $id_dm = (int)$id_dm;
      $tukhoa_safe = $this->db->real_escape_string(trim($tukhoa));

      $sql = "SELECT sp.id_san_pham, sp.ten_san_pham, sp.hinh_anh, sp.gia,
                     sp.id_danh_muc, sp.noi_bat, sp.mo_ta, dm.ten_danh_muc
              FROM san_pham sp
              LEFT JOIN danh_muc dm ON dm.id_danh_muc = sp.id_danh_muc
              WHERE 1=1";

      if ($id_dm > 0) {
         $sql .= " AND sp.id_danh_muc = $id_dm";
      }

      if ($noi_bat === '1' || $noi_bat === '0') {
         $nb = (int)$noi_bat;
         $sql .= " AND sp.noi_bat = $nb";
      }

      if ($tukhoa_safe !== "") {
         $id_tim = (int)str_replace('#', '', $tukhoa_safe);
         $sql .= " AND (sp.id_san_pham = $id_tim OR sp.ten_san_pham LIKE '%$tukhoa_safe%')";
      }

      $sql .= " ORDER BY sp.id_san_pham DESC";
      return $this->db->query($sql);
   }

   // 3. Lấy đầy đủ thông tin 1 sản phẩm (bao gồm cả cột noi_bat) để đổ lên form sửa Admin
   function ChiTietSanPhamAdmin($id_sp) {
      $id_sp = (int)$id_sp;
      $sql = "SELECT sp.*, dm.ten_danh_muc
              FROM san_pham sp
              LEFT JOIN danh_muc dm ON dm.id_danh_muc = sp.id_danh_muc
              WHERE sp.id_san_pham = $id_sp";
      $kq = $this->db->query($sql);
      return $kq->fetch_assoc();
   }

   // 4. Thêm sản phẩm mới vào thực đơn
   function ThemSanPham($ten_san_pham, $hinh_anh, $gia, $id_danh_muc, $noi_bat, $mo_ta) {
      $id_danh_muc = (int)$id_danh_muc;
      $noi_bat     = ((int)$noi_bat === 1) ? 1 : 0;
      $gia         = (float)$gia;

      $stmt = $this->db->prepare(
         "INSERT INTO san_pham (ten_san_pham, hinh_anh, gia, id_danh_muc, noi_bat, mo_ta)
          VALUES (?, ?, ?, ?, ?, ?)"
      );
      $stmt->bind_param("ssdiis", $ten_san_pham, $hinh_anh, $gia, $id_danh_muc, $noi_bat, $mo_ta);
      $ok = $stmt->execute();
      $stmt->close();

      return $ok ? true : "Có lỗi xảy ra khi thêm sản phẩm mới!";
   }

   // 5. Cập nhật thông tin sản phẩm
   function CapNhatSanPham($id_san_pham, $ten_san_pham, $hinh_anh, $gia, $id_danh_muc, $noi_bat, $mo_ta) {
      $id_san_pham = (int)$id_san_pham;
      $id_danh_muc = (int)$id_danh_muc;
      $noi_bat     = ((int)$noi_bat === 1) ? 1 : 0;
      $gia         = (float)$gia;

      $stmt = $this->db->prepare(
         "UPDATE san_pham
          SET ten_san_pham = ?, hinh_anh = ?, gia = ?, id_danh_muc = ?, noi_bat = ?, mo_ta = ?
          WHERE id_san_pham = ?"
      );
      $stmt->bind_param("ssdiisi", $ten_san_pham, $hinh_anh, $gia, $id_danh_muc, $noi_bat, $mo_ta, $id_san_pham);
      $ok = $stmt->execute();
      $stmt->close();

      return $ok ? true : "Có lỗi xảy ra khi cập nhật sản phẩm!";
   }

   // 6. Bật / tắt nhanh trạng thái nổi bật trang chủ
   function DoiTrangThaiNoiBat($id_san_pham, $noi_bat) {
      $id_san_pham = (int)$id_san_pham;
      $noi_bat     = ((int)$noi_bat === 1) ? 1 : 0;
      $stmt = $this->db->prepare("UPDATE san_pham SET noi_bat = ? WHERE id_san_pham = ?");
      $stmt->bind_param("ii", $noi_bat, $id_san_pham);
      $ok = $stmt->execute();
      $stmt->close();
      return $ok;
   }

   // 7. Xóa sản phẩm khỏi thực đơn
   function XoaSanPham($id_san_pham) {
      $id_san_pham = (int)$id_san_pham;
      $stmt = $this->db->prepare("DELETE FROM san_pham WHERE id_san_pham = ?");
      $stmt->bind_param("i", $id_san_pham);
      $ok = $stmt->execute();
      $stmt->close();
      return $ok;
   }
   // =========================================================================
   // === HẾT PHẦN QUẢN LÝ SẢN PHẨM (ADMIN) ===
   // =========================================================================

   // =========================================================================
   // === MỚI THÊM: TÀI KHOẢN KHÁCH HÀNG & THEO DÕI ĐƠN HÀNG ===
   // =========================================================================

   // Lấy thông tin chi tiết tài khoản đang đăng nhập kèm thống kê đơn hàng
   function ThongTinTaiKhoan($id_nguoi_dung) {
      $id_nguoi_dung = (int)$id_nguoi_dung;
      $stmt = $this->db->prepare(
         "SELECT nd.id_nguoi_dung, nd.ho_ten, nd.email, nd.dien_thoai,
                 nd.vai_tro, nd.trang_thai, nd.ngay_tao,
                 COUNT(dh.id_don_hang) AS tong_don,
                 SUM(CASE WHEN dh.trang_thai = 'hoan_thanh' THEN 1 ELSE 0 END) AS don_hoan_thanh,
                 COALESCE(SUM(CASE WHEN dh.trang_thai = 'hoan_thanh' THEN dh.tong_tien ELSE 0 END), 0) AS tong_chi_tieu
          FROM nguoi_dung nd
          LEFT JOIN don_hang dh ON dh.id_nguoi_dung = nd.id_nguoi_dung
          WHERE nd.id_nguoi_dung = ?
          GROUP BY nd.id_nguoi_dung, nd.ho_ten, nd.email, nd.dien_thoai, nd.vai_tro, nd.trang_thai, nd.ngay_tao"
      );
      $stmt->bind_param("i", $id_nguoi_dung);
      $stmt->execute();
      $row = $stmt->get_result()->fetch_assoc();
      $stmt->close();
      return $row;
   }

   // Khách hàng tự cập nhật họ tên và số điện thoại
   function CapNhatThongTinCaNhan($id_nguoi_dung, $ho_ten, $dien_thoai) {
      $id_nguoi_dung = (int)$id_nguoi_dung;
      $stmt = $this->db->prepare("UPDATE nguoi_dung SET ho_ten = ?, dien_thoai = ? WHERE id_nguoi_dung = ?");
      $stmt->bind_param("ssi", $ho_ten, $dien_thoai, $id_nguoi_dung);
      $ok = $stmt->execute();
      $stmt->close();
      return $ok;
   }

   // Khách hàng đổi mật khẩu tài khoản
   function DoiMatKhauCaNhan($id_nguoi_dung, $mat_khau_cu, $mat_khau_moi) {
      $id_nguoi_dung = (int)$id_nguoi_dung;
      $stmt = $this->db->prepare("SELECT mat_khau FROM nguoi_dung WHERE id_nguoi_dung = ?");
      $stmt->bind_param("i", $id_nguoi_dung);
      $stmt->execute();
      $row = $stmt->get_result()->fetch_assoc();
      $stmt->close();

      if (!$row || !password_verify($mat_khau_cu, $row['mat_khau'])) {
         return "Mật khẩu hiện tại không chính xác!";
      }

      $mat_khau_hash = password_hash($mat_khau_moi, PASSWORD_DEFAULT);
      $stmt = $this->db->prepare("UPDATE nguoi_dung SET mat_khau = ? WHERE id_nguoi_dung = ?");
      $stmt->bind_param("si", $mat_khau_hash, $id_nguoi_dung);
      $ok = $stmt->execute();
      $stmt->close();

      return $ok ? true : "Không thể đổi mật khẩu lúc này, vui lòng thử lại!";
   }

   // Tra cứu đơn hàng bằng Mã đơn + Số điện thoại (dành cho khách chưa đăng nhập)
   function TraCuuDonHang($id_don_hang, $so_dien_thoai) {
      $id_don_hang = (int)$id_don_hang;
      $sdt = trim($so_dien_thoai);
      if ($id_don_hang <= 0 || $sdt === '') {
         return null;
      }
      $stmt = $this->db->prepare(
         "SELECT dh.*, nd.email AS email_tai_khoan
          FROM don_hang dh
          LEFT JOIN nguoi_dung nd ON nd.id_nguoi_dung = dh.id_nguoi_dung
          WHERE dh.id_don_hang = ? AND TRIM(dh.so_dien_thoai) = ?"
      );
      $stmt->bind_param("is", $id_don_hang, $sdt);
      $stmt->execute();
      $row = $stmt->get_result()->fetch_assoc();
      $stmt->close();
      return $row;
   }

   // Đảm bảo bảng gio_hang tồn tại để lưu giỏ hàng riêng theo từng tài khoản
   function DamBaoBangGioHang() {
      $sql = "CREATE TABLE IF NOT EXISTS gio_hang (
                 id_gio_hang INT AUTO_INCREMENT PRIMARY KEY,
                 id_nguoi_dung INT NOT NULL,
                 id_san_pham INT NOT NULL,
                 so_luong INT NOT NULL DEFAULT 1,
                 ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                 UNIQUE KEY uniq_user_sp (id_nguoi_dung, id_san_pham)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
      $this->db->query($sql);
   }

   // Tải giỏ hàng đã lưu từ CSDL theo id_nguoi_dung
   function NapGioHangNguoiDung($id_nguoi_dung) {
      $this->DamBaoBangGioHang();
      $id_nguoi_dung = (int)$id_nguoi_dung;
      $stmt = $this->db->prepare(
         "SELECT gh.id_san_pham, sp.ten_san_pham, sp.hinh_anh, sp.gia, gh.so_luong
          FROM gio_hang gh
          INNER JOIN san_pham sp ON sp.id_san_pham = gh.id_san_pham
          WHERE gh.id_nguoi_dung = ?
          ORDER BY gh.id_gio_hang ASC"
      );
      if (!$stmt) {
         return [];
      }
      $stmt->bind_param("i", $id_nguoi_dung);
      $stmt->execute();
      $kq = $stmt->get_result();

      $giohang = [];
      while ($row = $kq->fetch_assoc()) {
         $id_sp = (int)$row['id_san_pham'];
         $giohang[$id_sp] = [
            'id_san_pham'  => $id_sp,
            'ten_san_pham' => $row['ten_san_pham'],
            'hinh_anh'     => $row['hinh_anh'],
            'gia'          => $row['gia'],
            'so_luong'     => max(1, (int)$row['so_luong'])
         ];
      }
      $stmt->close();
      return $giohang;
   }

   // Lưu toàn bộ giỏ hàng hiện tại của người dùng vào CSDL
   function LuuGioHangNguoiDung($id_nguoi_dung, $giohang) {
      $this->DamBaoBangGioHang();
      $id_nguoi_dung = (int)$id_nguoi_dung;
      if ($id_nguoi_dung <= 0) {
         return false;
      }

      $this->db->begin_transaction();
      try {
         $stmt_del = $this->db->prepare("DELETE FROM gio_hang WHERE id_nguoi_dung = ?");
         $stmt_del->bind_param("i", $id_nguoi_dung);
         $stmt_del->execute();
         $stmt_del->close();

         if (!empty($giohang) && is_array($giohang)) {
            $stmt_ins = $this->db->prepare(
               "INSERT INTO gio_hang (id_nguoi_dung, id_san_pham, so_luong) VALUES (?, ?, ?)"
            );
            foreach ($giohang as $item) {
               $id_sp = (int)($item['id_san_pham'] ?? 0);
               $sl    = max(1, (int)($item['so_luong'] ?? 1));
               if ($id_sp > 0) {
                  $stmt_ins->bind_param("iii", $id_nguoi_dung, $id_sp, $sl);
                  $stmt_ins->execute();
               }
            }
            $stmt_ins->close();
         }

         $this->db->commit();
         return true;
      } catch (Throwable $e) {
         $this->db->rollback();
         return false;
      }
   }

   // Đồng bộ giỏ hàng khi đăng nhập: khôi phục giỏ đã lưu (và gộp thêm món vừa chọn trước khi đăng nhập nếu có)
   function DongBoGioHangKhiDangNhap($id_nguoi_dung) {
      $gio_db = $this->NapGioHangNguoiDung($id_nguoi_dung);
      $gio_tam = isset($_SESSION['giohang']) && is_array($_SESSION['giohang'])
                 ? $_SESSION['giohang']
                 : [];

      foreach ($gio_tam as $id_sp => $item) {
         $id_sp = (int)$id_sp;
         if ($id_sp <= 0) continue;
         if (isset($gio_db[$id_sp])) {
            $gio_db[$id_sp]['so_luong'] += max(1, (int)$item['so_luong']);
         } else {
            $gio_db[$id_sp] = $item;
         }
      }

      $_SESSION['giohang'] = $gio_db;
      $this->LuuGioHangNguoiDung($id_nguoi_dung, $gio_db);
   }
   // =========================================================================
   // === HẾT PHẦN TÀI KHOẢN & THEO DÕI ĐƠN HÀNG ===
   // =========================================================================
} //class caphe
?>
