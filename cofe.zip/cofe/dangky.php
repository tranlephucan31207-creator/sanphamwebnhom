<?php
require_once "caphe.php";
$cf = new caphe;

// Nếu đã đăng nhập rồi thì chuyển về trang chủ
if (isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

$loi = "";
$ho_ten = "";
$email = "";
$dien_thoai = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ho_ten = trim($_POST['ho_ten'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $dien_thoai = trim($_POST['dien_thoai'] ?? '');
    $mat_khau = $_POST['mat_khau'] ?? '';
    $nhap_lai = $_POST['nhap_lai_mat_khau'] ?? '';

    if ($ho_ten === "" || $email === "" || $mat_khau === "") {
        $loi = "Vui lòng nhập đầy đủ Họ tên, Email và Mật khẩu!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $loi = "Địa chỉ Email không hợp lệ!";
    } elseif (strlen($mat_khau) < 6) {
        $loi = "Mật khẩu phải có ít nhất 6 ký tự!";
    } elseif ($mat_khau !== $nhap_lai) {
        $loi = "Mật khẩu nhập lại không khớp!";
    } else {
        $ketqua = $cf->DangKy($ho_ten, $email, $dien_thoai, $mat_khau);
        if ($ketqua === true) {
            $_SESSION['thongbao_auth'] = "Đăng ký tài khoản thành công! Vui lòng đăng nhập.";
            header("Location: dangnhap.php");
            exit;
        } else {
            $loi = $ketqua; // Thông báo lỗi (ví dụ: Email đã tồn tại)
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Coffee House - Đăng ký tài khoản</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <!-- HEADER (giữ nguyên cấu trúc các trang khác) -->
  <header>
    <div class="container">
      <div class="header-left">
        <div class="logo">☕ Coffee House</div>
        <nav>
          <ul>
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="danhmuc.php">Danh mục</a></li>
            <li><a href="products.php">Sản phẩm</a></li>
            <li><a href="theodoi_donhang.php">Theo dõi đơn</a></li>
            <li><a href="index.php#about">Giới thiệu</a></li>
            <li><a href="index.php#footer">Liên hệ</a></li>
          </ul>
        </nav>
      </div>

      <div class="header-right">
        <a href="giohang.php">🛒 Giỏ hàng (<?= $cf->TongSoLuongGioHang() ?>)</a>
        <?php if (isset($_SESSION['user'])) { ?>
          <a href="taikhoan.php">👤 <?= htmlspecialchars($_SESSION['user']['ho_ten']) ?></a>
          <a href="dangxuat.php">Đăng xuất</a>
        <?php } else { ?>
          <a href="dangnhap.php">Đăng nhập</a>
          <a href="dangky.php">Đăng ký</a>
        <?php } ?>
      </div>
    </div>
  </header>

  <!-- TIÊU ĐỀ -->
  <div class="page-title">
    <h1>Đăng ký tài khoản</h1>
  </div>

  <!-- KHUNG FORM ĐĂNG KÝ -->
  <div class="auth-wrapper">
    <div class="auth-box">
      <?php if ($loi !== "") { ?>
        <div class="auth-alert auth-alert-error"><?= htmlspecialchars($loi) ?></div>
      <?php } ?>

      <form method="post" action="dangky.php">
        <div class="form-group">
          <label for="ho_ten">Họ và tên *</label>
          <input type="text" id="ho_ten" name="ho_ten" placeholder="Nhập họ và tên..."
                 value="<?= htmlspecialchars($ho_ten) ?>" required>
        </div>

        <div class="form-group">
          <label for="email">Email *</label>
          <input type="email" id="email" name="email" placeholder="Nhập địa chỉ email..."
                 value="<?= htmlspecialchars($email) ?>" required>
        </div>

        <div class="form-group">
          <label for="dien_thoai">Số điện thoại</label>
          <input type="text" id="dien_thoai" name="dien_thoai" placeholder="Nhập số điện thoại..."
                 value="<?= htmlspecialchars($dien_thoai) ?>">
        </div>

        <div class="form-group">
          <label for="mat_khau">Mật khẩu * (tối thiểu 6 ký tự)</label>
          <input type="password" id="mat_khau" name="mat_khau" placeholder="Nhập mật khẩu..." required>
        </div>

        <div class="form-group">
          <label for="nhap_lai_mat_khau">Nhập lại mật khẩu *</label>
          <input type="password" id="nhap_lai_mat_khau" name="nhap_lai_mat_khau" placeholder="Nhập lại mật khẩu..." required>
        </div>

        <button type="submit" class="btn auth-btn">Đăng ký</button>
      </form>

      <p class="auth-links">
        Đã có tài khoản? <a href="dangnhap.php">Đăng nhập ngay</a>
      </p>
    </div>
  </div>

  <!-- FOOTER (giữ nguyên cấu trúc các trang khác) -->
  <footer id="footer">
    <div class="footer-container">
      <div class="footer-col">
        <h3>☕ Coffee House</h3>
        <p>Thương hiệu cà phê chất lượng, mang tới hương vị đậm đà nguyên bản từ những hạt cà phê hảo hạng.</p>
      </div>
      <div class="footer-col">
        <h3>Thông Tin Liên Hệ</h3>
        <p>📍 Địa chỉ: 123 Đường Nguyễn Trãi, Quận 1, TP.HCM</p>
        <p>📞 Điện thoại: 0909 123 456</p>
        <p>✉️ Email: contact@coffeehouse.vn</p>
        <p>⏰ Giờ mở cửa: 07:00 - 22:30 hàng ngày</p>
      </div>
      <div class="footer-col">
        <h3>Liên Kết Nhanh</h3>
        <ul>
          <li><a href="index.php">Trang chủ</a></li>
          <li><a href="danhmuc.php">Danh mục</a></li>
          <li><a href="products.php">Sản phẩm</a></li>
          <li><a href="giohang.php">Giỏ hàng</a></li>
        </ul>
      </div>
    </div>
    <div class="copyright">
      <p>&copy; Coffee House. Tất cả quyền được bảo lưu.</p>
    </div>
  </footer>

</body>
</html>