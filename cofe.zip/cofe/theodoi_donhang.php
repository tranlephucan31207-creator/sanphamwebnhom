<?php
require_once "caphe.php";
$cf = new caphe;

function thongTinTrangThai($tt) {
    switch ($tt) {
        case 'cho_xac_nhan':
            return [
                'nhan'  => 'Chờ xác nhận',
                'class' => 'status-warning',
                'mo_ta' => 'Đơn hàng đã được gửi tới quầy. Nhân viên sẽ tiếp nhận ngay trong giây lát.'
            ];
        case 'dang_pha_che':
            return [
                'nhan'  => 'Đang pha chế',
                'class' => 'status-info',
                'mo_ta' => 'Quán đã xác nhận và đang pha chế món cho bạn!'
            ];
        case 'hoan_thanh':
            return [
                'nhan'  => 'Hoàn thành',
                'class' => 'status-success',
                'mo_ta' => 'Đơn hàng đã hoàn tất. Chúc bạn thưởng thức ngon miệng!'
            ];
        case 'da_huy':
            return [
                'nhan'  => 'Đã hủy',
                'class' => 'status-danger',
                'mo_ta' => 'Đơn hàng này đã bị hủy. Vui lòng liên hệ quán nếu cần hỗ trợ.'
            ];
        default:
            return [
                'nhan'  => $tt,
                'class' => 'status-secondary',
                'mo_ta' => ''
            ];
    }
}

function coQuyenXemDon($don) {
    if (!$don) {
        return false;
    }
    $id_don = (int)$don['id_don_hang'];
    $don_session = isset($_SESSION['don_vua_dat']) && is_array($_SESSION['don_vua_dat'])
                   ? $_SESSION['don_vua_dat']
                   : [];
    if (in_array($id_don, $don_session, true)) {
        return true;
    }
    if (isset($_SESSION['user']['id_nguoi_dung']) && $don['id_nguoi_dung'] !== null) {
        return (int)$don['id_nguoi_dung'] === (int)$_SESSION['user']['id_nguoi_dung'];
    }
    return false;
}

// Endpoint JSON phục vụ tự động cập nhật trạng thái đơn hàng theo thời gian thực
if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store, no-cache, must-revalidate');

    $id_ajax = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $don_ajax = $id_ajax > 0 ? $cf->ChiTietDonHang($id_ajax) : null;

    if (!coQuyenXemDon($don_ajax)) {
        echo json_encode(['ok' => false]);
        exit;
    }

    $info = thongTinTrangThai($don_ajax['trang_thai']);
    echo json_encode([
        'ok'           => true,
        'id_don_hang'  => (int)$don_ajax['id_don_hang'],
        'trang_thai'   => $don_ajax['trang_thai'],
        'nhan'         => $info['nhan'],
        'badge_class'  => $info['class'],
        'mo_ta'        => $info['mo_ta'],
        'cap_nhat_luc' => date('H:i:s')
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$thongbao = isset($_SESSION['thongbao']) ? $_SESSION['thongbao'] : "";
unset($_SESSION['thongbao']);

$loi_tracuu = "";
$ma_don_nhap = "";
$sdt_nhap = "";

// Xử lý tra cứu thủ công bằng Mã đơn + Số điện thoại
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tra_cuu'])) {
    $ma_don_nhap = trim($_POST['ma_don'] ?? '');
    $sdt_nhap    = trim($_POST['so_dien_thoai'] ?? '');
    $id_tim = (int)str_replace('#', '', $ma_don_nhap);

    if ($id_tim <= 0 || $sdt_nhap === '') {
        $loi_tracuu = "Vui lòng nhập đầy đủ Mã đơn hàng và Số điện thoại đặt hàng!";
    } else {
        $don_tim = $cf->TraCuuDonHang($id_tim, $sdt_nhap);
        if ($don_tim) {
            if (!isset($_SESSION['don_vua_dat']) || !is_array($_SESSION['don_vua_dat'])) {
                $_SESSION['don_vua_dat'] = [];
            }
            if (!in_array((int)$don_tim['id_don_hang'], $_SESSION['don_vua_dat'], true)) {
                $_SESSION['don_vua_dat'][] = (int)$don_tim['id_don_hang'];
            }
            header("Location: theodoi_donhang.php?id=" . (int)$don_tim['id_don_hang']);
            exit;
        } else {
            $loi_tracuu = "Không tìm thấy đơn hàng #" . $id_tim . " khớp với số điện thoại đã nhập!";
        }
    }
}

$id_don = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id_don <= 0 && !empty($_SESSION['don_vua_dat']) && is_array($_SESSION['don_vua_dat'])) {
    $id_don = (int)end($_SESSION['don_vua_dat']);
}

$don_hien_tai = $id_don > 0 ? $cf->ChiTietDonHang($id_don) : null;
$duoc_xem = coQuyenXemDon($don_hien_tai);
if (!$duoc_xem) {
    if ($id_don > 0 && $loi_tracuu === "") {
        $ma_don_nhap = (string)$id_don;
        $loi_tracuu = "Vui lòng nhập Số điện thoại đặt hàng để xem chi tiết đơn #" . $id_don . ".";
    }
    $don_hien_tai = null;
}

$ds_mon = $don_hien_tai ? $cf->ListSanPhamTrongDon((int)$don_hien_tai['id_don_hang']) : null;
$ds_don_user = isset($_SESSION['user']['id_nguoi_dung'])
               ? $cf->ListDonHangCuaKhach((int)$_SESSION['user']['id_nguoi_dung'])
               : null;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Coffee House - Theo dõi đơn hàng</title>
  <link rel="stylesheet" href="style.css?v=4">
</head>
<body class="account-page">

  <header>
    <div class="container">
      <div class="header-left">
        <div class="logo">☕ Coffee House</div>
        <nav>
          <ul>
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="danhmuc.php">Danh mục</a></li>
            <li><a href="products.php">Sản phẩm</a></li>
            <li><a href="theodoi_donhang.php">Theo dõi đơn</a></li>
            <li><a href="index.php#footer">Liên hệ</a></li>
          </ul>
        </nav>
      </div>

      <div class="header-right">
        <a href="giohang.php">🛒 Giỏ hàng (<?= $cf->TongSoLuongGioHang() ?>)</a>
        <?php if (isset($_SESSION['user'])) { ?>
          <a href="taikhoan.php">👤 <?= htmlspecialchars($_SESSION['user']['ho_ten']) ?></a>
          <a href="dangxuat.php">Đăng xuất</a>
        <?php } else { ?>
          <a href="dangnhap.php">Đăng nhập</a>
          <a href="dangky.php">Đăng ký</a>
        <?php } ?>
      </div>
    </div>
  </header>

  <div class="page-title">
    <h1>Theo dõi tình trạng đơn hàng</h1>
  </div>

  <div class="account-wrapper">
    <!-- Banner giới thiệu theo dõi đơn -->
    <section class="account-hero track-hero">
      <div class="account-hero-left">
        <div class="account-avatar track-hero-icon">☕</div>
        <div class="account-hero-meta">
          <div class="account-hero-badges">
            <span class="hero-member-tag">Cập nhật tự động mỗi 4 giây</span>
          </div>
          <h2>Hành trình đơn hàng của bạn</h2>
          <p>Theo dõi trực tiếp tiến trình từ lúc quầy tiếp nhận đến khi pha chế hoàn tất.</p>
        </div>
      </div>
      <div class="account-hero-actions">
        <a href="products.php" class="hero-btn-light">🛍️ Đặt thêm món</a>
        <?php if (isset($_SESSION['user'])) { ?>
          <a href="taikhoan.php" class="hero-btn-outline">👤 Tài khoản</a>
        <?php } ?>
      </div>
    </section>

    <?php if ($thongbao !== "") { ?>
      <div class="auth-alert auth-alert-success"><?= htmlspecialchars($thongbao) ?></div>
    <?php } ?>

    <?php if ($loi_tracuu !== "") { ?>
      <div class="auth-alert auth-alert-error"><?= htmlspecialchars($loi_tracuu) ?></div>
    <?php } ?>

    <!-- Khung tra cứu nhanh bằng Mã đơn + SĐT -->
    <section class="account-card track-search-card">
      <div class="account-section-title">
        <span class="section-icon">🔍</span>
        <h3>Tra cứu nhanh đơn hàng</h3>
      </div>
      <form method="post" action="theodoi_donhang.php" class="track-search-form">
        <input type="hidden" name="tra_cuu" value="1">
        <input type="text" name="ma_don" placeholder="Nhập mã đơn (VD: 12 hoặc #12)"
               value="<?= htmlspecialchars($ma_don_nhap) ?>" required>
        <input type="text" name="so_dien_thoai" placeholder="Nhập số điện thoại đặt hàng"
               value="<?= htmlspecialchars($sdt_nhap) ?>" required>
        <button type="submit" class="btn track-submit-btn">Kiểm tra đơn</button>
      </form>
    </section>

    <?php if ($don_hien_tai) {
      $tt_hien_tai = $don_hien_tai['trang_thai'];
      $info_tt = thongTinTrangThai($tt_hien_tai);
      $buoc_hien_tai = 1;
      if ($tt_hien_tai === 'dang_pha_che') $buoc_hien_tai = 2;
      elseif ($tt_hien_tai === 'hoan_thanh') $buoc_hien_tai = 3;
    ?>
      <section class="account-card track-main-card" style="margin-top: 22px;" id="order-tracker"
               data-order-id="<?= (int)$don_hien_tai['id_don_hang'] ?>"
               data-status="<?= htmlspecialchars($tt_hien_tai) ?>">

        <div class="account-card-head track-order-head">
          <div>
            <span class="track-order-code">Đơn hàng #<?= (int)$don_hien_tai['id_don_hang'] ?></span>
            <div class="track-time">🕒 Đặt lúc: <?= date('d/m/Y H:i:s', strtotime($don_hien_tai['ngay_dat'])) ?></div>
          </div>
          <span id="live-status-badge" class="order-status-pill order-status-lg <?= $info_tt['class'] ?>">
            <?= htmlspecialchars($info_tt['nhan']) ?>
          </span>
        </div>

        <div class="track-desc-box">
          <span class="track-desc-icon">💬</span>
          <p id="live-status-desc" class="track-desc"><?= htmlspecialchars($info_tt['mo_ta']) ?></p>
        </div>

        <div id="live-update-notice" class="auth-alert auth-alert-success" style="display: none;"></div>

        <!-- Thanh tiến trình 3 bước -->
        <div id="track-stepper" class="track-stepper <?= $tt_hien_tai === 'da_huy' ? 'is-cancelled' : '' ?>">
          <div class="track-step <?= ($tt_hien_tai !== 'da_huy' && $buoc_hien_tai >= 1) ? 'done' : '' ?> <?= $tt_hien_tai === 'cho_xac_nhan' ? 'current' : '' ?>" data-step="1">
            <div class="step-dot">📝</div>
            <div class="step-label">Chờ xác nhận</div>
            <div class="step-sub">Quầy tiếp nhận</div>
          </div>
          <div class="track-line <?= ($tt_hien_tai !== 'da_huy' && $buoc_hien_tai >= 2) ? 'done' : '' ?>" data-line="1"></div>
          <div class="track-step <?= ($tt_hien_tai !== 'da_huy' && $buoc_hien_tai >= 2) ? 'done' : '' ?> <?= $tt_hien_tai === 'dang_pha_che' ? 'current' : '' ?>" data-step="2">
            <div class="step-dot">☕</div>
            <div class="step-label">Đang pha chế</div>
            <div class="step-sub">Đang chuẩn bị món</div>
          </div>
          <div class="track-line <?= ($tt_hien_tai !== 'da_huy' && $buoc_hien_tai >= 3) ? 'done' : '' ?>" data-line="2"></div>
          <div class="track-step <?= ($tt_hien_tai !== 'da_huy' && $buoc_hien_tai >= 3) ? 'done' : '' ?> <?= $tt_hien_tai === 'hoan_thanh' ? 'current' : '' ?>" data-step="3">
            <div class="step-dot">✅</div>
            <div class="step-label">Hoàn thành</div>
            <div class="step-sub">Sẵn sàng phục vụ</div>
          </div>
        </div>

        <div id="cancelled-banner" class="auth-alert auth-alert-error" style="<?= $tt_hien_tai === 'da_huy' ? '' : 'display:none;' ?>">
          Đơn hàng này đã bị hủy.
        </div>

        <div class="track-sync-row">
          <span id="live-sync-label" class="track-sync-pill <?= ($tt_hien_tai === 'cho_xac_nhan' || $tt_hien_tai === 'dang_pha_che') ? 'is-live' : '' ?>">
            <?= ($tt_hien_tai === 'cho_xac_nhan' || $tt_hien_tai === 'dang_pha_che')
                ? '🔄 Đang tự động cập nhật trạng thái từ quán mỗi 4 giây...'
                : '✔ Đơn hàng đã ở trạng thái cuối.' ?>
          </span>
        </div>

        <!-- Thông tin giao nhận dạng lưới thẻ -->
        <div class="track-info-grid">
          <div class="track-info-item">
            <span class="info-label">👤 Người nhận</span>
            <strong><?= htmlspecialchars($don_hien_tai['ten_khach_hang']) ?></strong>
          </div>
          <div class="track-info-item">
            <span class="info-label">📞 Số điện thoại</span>
            <strong><?= htmlspecialchars($don_hien_tai['so_dien_thoai']) ?></strong>
          </div>
          <div class="track-info-item">
            <span class="info-label">📍 Địa chỉ / Hình thức</span>
            <strong><?= htmlspecialchars($don_hien_tai['dia_chi']) ?></strong>
          </div>
          <?php if (!empty($don_hien_tai['ghi_chu'])) { ?>
            <div class="track-info-item track-info-full">
              <span class="info-label">📝 Ghi chú</span>
              <strong><em><?= htmlspecialchars($don_hien_tai['ghi_chu']) ?></em></strong>
            </div>
          <?php } ?>
        </div>

        <!-- Chi tiết các món trong đơn -->
        <div class="table-scroll" style="margin-top: 20px;">
          <table class="cart-table track-items-table">
            <thead>
              <tr>
                <th>Món đã đặt</th>
                <th>Đơn giá</th>
                <th>Số lượng</th>
                <th>Thành tiền</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($ds_mon) {
                while ($mon = $ds_mon->fetch_assoc()) {
                  $tt_mon = $mon['don_gia'] * $mon['so_luong'];
              ?>
                <tr>
                  <td><strong><?= htmlspecialchars($mon['ten_san_pham']) ?></strong></td>
                  <td><?= $cf->DinhDangGia($mon['don_gia']) ?></td>
                  <td><span class="track-qty-pill">x<?= (int)$mon['so_luong'] ?></span></td>
                  <td class="price"><?= $cf->DinhDangGia($tt_mon) ?></td>
                </tr>
              <?php } } ?>
            </tbody>
            <tfoot>
              <tr class="track-total-row">
                <td colspan="3" style="text-align: right;"><strong>Tổng thanh toán:</strong></td>
                <td class="price" style="font-size: 19px;"><?= $cf->DinhDangGia($don_hien_tai['tong_tien']) ?></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </section>
    <?php } ?>

    <!-- Danh sách đơn của tài khoản (nếu đã đăng nhập) -->
    <?php if ($ds_don_user && $ds_don_user->num_rows > 0) { ?>
      <section class="account-card" style="margin-top: 25px;">
        <div class="account-card-head">
          <div style="display:flex; align-items:center; gap:10px;">
            <span class="section-icon">📋</span>
            <h3>Các đơn hàng gần đây của bạn</h3>
          </div>
          <a href="taikhoan.php" class="track-account-link">Xem trang tài khoản →</a>
        </div>
        <div class="table-scroll">
          <table class="cart-table">
            <thead>
              <tr>
                <th>Mã đơn</th>
                <th>Thời gian đặt</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($d = $ds_don_user->fetch_assoc()) {
                $d_info = thongTinTrangThai($d['trang_thai']);
              ?>
                <tr>
                  <td><strong>#<?= (int)$d['id_don_hang'] ?></strong></td>
                  <td><?= date('d/m/Y H:i', strtotime($d['ngay_dat'])) ?></td>
                  <td class="price"><?= $cf->DinhDangGia($d['tong_tien']) ?></td>
                  <td><span class="order-status-pill <?= $d_info['class'] ?>"><?= htmlspecialchars($d_info['nhan']) ?></span></td>
                  <td>
                    <a href="theodoi_donhang.php?id=<?= (int)$d['id_don_hang'] ?>" class="btn btn-sm-track">Theo dõi</a>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </section>
    <?php } ?>
  </div>

  <footer id="footer">
    <div class="footer-container">
      <div class="footer-col">
        <h3>☕ Coffee House</h3>
        <p>Thương hiệu cà phê chất lượng, mang tới hương vị đậm đà nguyên bản từ những hạt cà phê hảo hạng.</p>
      </div>
      <div class="footer-col">
        <h3>Thông Tin Liên Hệ</h3>
        <p>📍 Địa chỉ: 123 Đường Nguyễn Trãi, Quận 1, TP.HCM</p>
        <p>📞 Điện thoại: 0909 123 456</p>
        <p>✉️ Email: contact@coffeehouse.vn</p>
        <p>⏰ Giờ mở cửa: 07:00 - 22:30 hàng ngày</p>
      </div>
      <div class="footer-col">
        <h3>Liên Kết Nhanh</h3>
        <ul>
          <li><a href="index.php">Trang chủ</a></li>
          <li><a href="danhmuc.php">Danh mục</a></li>
          <li><a href="products.php">Sản phẩm</a></li>
          <li><a href="giohang.php">Giỏ hàng</a></li>
        </ul>
      </div>
    </div>
    <div class="copyright">
      <p>&copy; Coffee House. Tất cả quyền được bảo lưu.</p>
    </div>
  </footer>

  <?php if ($don_hien_tai) { ?>
  <script>
    (function () {
      var tracker = document.getElementById('order-tracker');
      if (!tracker) return;

      var orderId = tracker.getAttribute('data-order-id');
      var currentStatus = tracker.getAttribute('data-status');
      var badgeEl = document.getElementById('live-status-badge');
      var descEl = document.getElementById('live-status-desc');
      var noticeEl = document.getElementById('live-update-notice');
      var stepperEl = document.getElementById('track-stepper');
      var cancelledEl = document.getElementById('cancelled-banner');
      var syncEl = document.getElementById('live-sync-label');

      function applyStepper(status) {
        var stepNum = 1;
        if (status === 'dang_pha_che') stepNum = 2;
        else if (status === 'hoan_thanh') stepNum = 3;

        if (status === 'da_huy') {
          stepperEl.classList.add('is-cancelled');
          cancelledEl.style.display = '';
        } else {
          stepperEl.classList.remove('is-cancelled');
          cancelledEl.style.display = 'none';
        }

        stepperEl.querySelectorAll('.track-step').forEach(function (el) {
          var s = parseInt(el.getAttribute('data-step'), 10);
          el.classList.remove('done', 'current');
          if (status !== 'da_huy') {
            if (stepNum >= s) el.classList.add('done');
            if (stepNum === s) el.classList.add('current');
          }
        });

        stepperEl.querySelectorAll('.track-line').forEach(function (el) {
          var l = parseInt(el.getAttribute('data-line'), 10);
          el.classList.toggle('done', status !== 'da_huy' && stepNum > l);
        });
      }

      if (currentStatus === 'hoan_thanh' || currentStatus === 'da_huy') {
        return;
      }

      var timer = setInterval(function () {
        fetch('theodoi_donhang.php?ajax=1&id=' + encodeURIComponent(orderId), { cache: 'no-store' })
          .then(function (res) { return res.json(); })
          .then(function (data) {
            if (!data || !data.ok) return;

            if (data.trang_thai !== currentStatus) {
              currentStatus = data.trang_thai;
              badgeEl.textContent = data.nhan;
              badgeEl.className = 'order-status-pill order-status-lg ' + data.badge_class;
              descEl.textContent = data.mo_ta;
              applyStepper(currentStatus);

              noticeEl.textContent = 'Trạng thái đơn hàng vừa được cập nhật thành "' + data.nhan + '" lúc ' + data.cap_nhat_luc + '!';
              noticeEl.style.display = '';

              if (currentStatus === 'hoan_thanh' || currentStatus === 'da_huy') {
                syncEl.textContent = '✔ Đơn hàng đã ở trạng thái cuối.';
                syncEl.classList.remove('is-live');
                clearInterval(timer);
              }
            } else {
              syncEl.textContent = '🔄 Đang tự động theo dõi trạng thái (kiểm tra lúc ' + data.cap_nhat_luc + ')';
            }
          })
          .catch(function () {});
      }, 4000);
    })();
  </script>
  <?php } ?>

</body>
</html>
